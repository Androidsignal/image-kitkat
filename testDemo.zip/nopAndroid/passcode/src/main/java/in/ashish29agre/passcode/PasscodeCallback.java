package in.ashish29agre.passcode;

/**
 * Created by Ashish on 26/12/15.
 */
public interface PasscodeCallback {
    public void onComplete(CharSequence sequence);
}
