package com.testDemo.helper;

import org.json.JSONException;

public interface OnAsyncLoader {
  public void OnResult(String result) throws JSONException;
//  void onResult(String result) throws JSONException;
}