package com.testDemo.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AddressModel {

    String addressId;
    String addressUserName;
    String addressUserEmail;
    String addressUserPhoneNumber;
    String addressUserAddress1;
    String addressUserAddress2;
    String addressUserCity;
    String addressUserCountry;
    String addressUserPinCode;
    boolean CountyEnabled;
    boolean CityEnabled;
    boolean ZipPostalCodeEnabled;
    boolean PhoneEnabled;
    boolean StreetAddressEnabled;
    boolean StreetAddress2Enabled;
    String formattedCustomAddressAttributes;
    String addressUserCounty;
    String addressUserState;


    public String getAddressUserAddress2() {
        return addressUserAddress2;
    }

    public void setAddressUserAddress2(String addressUserAddress2) {
        this.addressUserAddress2 = addressUserAddress2;
    }

    public boolean isCountyEnabled() {
        return CountyEnabled;
    }

    public void setCountyEnabled(boolean countyEnabled) {
        CountyEnabled = countyEnabled;
    }

    public boolean isCityEnabled() {
        return CityEnabled;
    }

    public void setCityEnabled(boolean cityEnabled) {
        CityEnabled = cityEnabled;
    }

    public boolean isZipPostalCodeEnabled() {
        return ZipPostalCodeEnabled;
    }

    public void setZipPostalCodeEnabled(boolean zipPostalCodeEnabled) {
        ZipPostalCodeEnabled = zipPostalCodeEnabled;
    }

    public boolean isPhoneEnabled() {
        return PhoneEnabled;
    }

    public void setPhoneEnabled(boolean phoneEnabled) {
        PhoneEnabled = phoneEnabled;
    }

    public boolean isStreetAddressEnabled() {
        return StreetAddressEnabled;
    }

    public void setStreetAddressEnabled(boolean streetAddressEnabled) {
        StreetAddressEnabled = streetAddressEnabled;
    }

    public boolean isStreetAddress2Enabled() {
        return StreetAddress2Enabled;
    }

    public void setStreetAddress2Enabled(boolean streetAddress2Enabled) {
        StreetAddress2Enabled = streetAddress2Enabled;
    }


    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public String getAddressUserName() {
        return addressUserName;
    }

    public void setAddressUserName(String addressUserName) {
        this.addressUserName = addressUserName;
    }

    public String getAddressUserEmail() {
        return addressUserEmail;
    }

    public void setAddressUserEmail(String addressUserEmail) {
        this.addressUserEmail = addressUserEmail;
    }

    public String getAddressUserPhoneNumber() {
        return addressUserPhoneNumber;
    }

    public void setAddressUserPhoneNumber(String addressUserPhoneNumber) {
        this.addressUserPhoneNumber = addressUserPhoneNumber;
    }

    public String getAddressUserAddress1() {
        return addressUserAddress1;
    }

    public void setAddressUserAddress1(String addressUserAddress1) {
        this.addressUserAddress1 = addressUserAddress1;
    }

    public String getAddressUserCity() {
        return addressUserCity;
    }

    public void setAddressUserCity(String addressUserCity) {
        this.addressUserCity = addressUserCity;
    }

    public String getAddressUserCountry() {
        return addressUserCountry;
    }

    public void setAddressUserCountry(String addressUserCountry) {
        this.addressUserCountry = addressUserCountry;
    }

    public String getAddressUserPinCode() {
        return addressUserPinCode;
    }

    public void setAddressUserPinCode(String addressUserPinCode) {
        this.addressUserPinCode = addressUserPinCode;
    }

    public String getFormattedCustomAddressAttributes() {
        return formattedCustomAddressAttributes;
    }

    public void setFormattedCustomAddressAttributes(String formattedCustomAddressAttributes) {
        this.formattedCustomAddressAttributes = formattedCustomAddressAttributes;
    }

    public String getAddressUserCounty() {
        return addressUserCounty;
    }

    public void setAddressUserCounty(String addressUserCounty) {
        this.addressUserCounty = addressUserCounty;
    }

    public String getAddressUserState() {
        return addressUserState;
    }

    public void setAddressUserState(String addressUserState) {
        this.addressUserState = addressUserState;
    }

    public void parseForAddress(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("Id") && !jsonObject.isNull("Id")) {
            addressId = jsonObject.getString("Id");
        }
        if (jsonObject.has("FirstName") && !jsonObject.isNull("FirstName")) {
            addressUserName = jsonObject.getString("FirstName");
        }
        if (jsonObject.has("LastName") && !jsonObject.isNull("LastName")) {
            addressUserName = addressUserName + " " + jsonObject.getString("LastName");
        }

        if (jsonObject.has("Email") && !jsonObject.isNull("Email")) {
            addressUserEmail = jsonObject.getString("Email");
        }
        if (jsonObject.has("PhoneNumber") && !jsonObject.isNull("PhoneNumber")) {
            addressUserPhoneNumber = jsonObject.getString("PhoneNumber");
        }
        if (jsonObject.has("City") && !jsonObject.isNull("City")) {
            addressUserCity = jsonObject.getString("City");
        }
        if (jsonObject.has("Address1") && !jsonObject.isNull("Address1")) {
            addressUserAddress1 = jsonObject.getString("Address1");
        }
        if (jsonObject.has("Address2") && !jsonObject.isNull("Address2")) {
            addressUserAddress2 = jsonObject.getString("Address2");
        }
        if (jsonObject.has("County") && !jsonObject.isNull("County")) {
            addressUserCounty = jsonObject.getString("County");
        }
        if (jsonObject.has("CountryName") && !jsonObject.isNull("CountryName")) {
            addressUserCountry = jsonObject.getString("CountryName");
        }
        if (jsonObject.has("StateProvinceName") && !jsonObject.isNull("StateProvinceName")) {
            addressUserState = jsonObject.getString("StateProvinceName");
        }
        if (jsonObject.has("ZipPostalCode") && !jsonObject.isNull("ZipPostalCode")) {
            addressUserPinCode = jsonObject.getString("ZipPostalCode");
        }

        if (jsonObject.has("CountyEnabled") && !jsonObject.isNull("CountyEnabled")) {
            CountyEnabled = jsonObject.getBoolean("CountyEnabled");
        }

        if (jsonObject.has("CityEnabled") && !jsonObject.isNull("CityEnabled")) {
            CityEnabled = jsonObject.getBoolean("CityEnabled");
        }

        if (jsonObject.has("StreetAddressEnabled") && !jsonObject.isNull("StreetAddressEnabled")) {
            StreetAddressEnabled = jsonObject.getBoolean("StreetAddressEnabled");
        }
        if (jsonObject.has("formattedCustomAddressAttributes") && !jsonObject.isNull("formattedCustomAddressAttributes")) {
            formattedCustomAddressAttributes = jsonObject.getString("formattedCustomAddressAttributes");
        }
        if (jsonObject.has("FormattedCustomAddressAttributes") && !jsonObject.isNull("FormattedCustomAddressAttributes")) {
            formattedCustomAddressAttributes = jsonObject.getString("FormattedCustomAddressAttributes");
        }

        if (jsonObject.has("StreetAddress2Enabled") && !jsonObject.isNull("StreetAddress2Enabled")) {
            StreetAddress2Enabled = jsonObject.getBoolean("StreetAddress2Enabled");
        }

        if (jsonObject.has("ZipPostalCodeEnabled") && !jsonObject.isNull("ZipPostalCodeEnabled")) {
            ZipPostalCodeEnabled = jsonObject.getBoolean("ZipPostalCodeEnabled");
        }

        if (jsonObject.has("PhoneEnabled") && !jsonObject.isNull("PhoneEnabled")) {
            PhoneEnabled = jsonObject.getBoolean("PhoneEnabled");
        }

    }
}
