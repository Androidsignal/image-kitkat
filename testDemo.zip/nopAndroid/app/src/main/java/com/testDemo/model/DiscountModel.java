package com.testDemo.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DiscountModel {

    String productId;
    String imageUrl;
    String productName;
    String productDiscount;
    String productOldPrice;
    String productPrice;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDiscount() {
        return productDiscount;
    }

    public void setProductDiscount(String productDiscount) {
        this.productDiscount = productDiscount;
    }

    public String getProductOldPrice() {
        return productOldPrice;
    }

    public void setProductOldPrice(String productOldPrice) {
        this.productOldPrice = productOldPrice;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void DiscountModel(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("product_id") && !jsonObject.isNull("product_id")) {
            productId = jsonObject.getString("product_id");
        }


    }

}
