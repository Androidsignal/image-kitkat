package com.testDemo.activites;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.testDemo.R;
import com.testDemo.adapter.OrderDetailAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.OrderModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class OrderDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int PERMISSION_REQUEST_CODE = 200;

    Toolbar toolbar;
    LinearLayout layoutNoInternet, ll_main_layout, layoutLoading, ll_re_order;
    ArrayList<OrderModel> orderInfoList;
    RecyclerView rcv_product_list;
    Button btnReload, btn_pdf_invoice;
    TextView tv_order_number, tv_order_status,
            tv_order_date, tv_order_total,
            tv_payment_method, tv_payment_status,
            tv_shipping_method, tv_shipping_status, tv_shipping_total,
            tv_sub_total, tv_tax,
            tv_total,
            tv_billing_name,
            tv_billing_email,
            tv_billing_phone_number,
            tv_billing_fax,
            tv_billing_address_1,
            tv_billing_city_pin,
            tv_billing_country,
            tv_shipping_name,
            tv_shipping_email,
            tv_shipping_phone_number,
            tv_shipping_fax,
            tv_shipping_address_1,
            tv_shipping_city_pin,
            tv_shipping_country;
    String orderId;
    private long downloadID;
    String currencyId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        registerReceiver(onDownloadComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        findViewById();
        toolbarInit();
        callApi();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(onDownloadComplete);
    }


    private void callApi() {
        if (Constants.isCheckInternetCon(OrderDetailActivity.this)) {
            ll_main_layout.setVisibility(View.GONE);
            ll_re_order.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            currencyId = SharedPrefsUtils.getStringPreference(OrderDetailActivity.this, Constants.PREF_SELECTED_CURRENCY);
            callApiForData();
        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            ll_main_layout.setVisibility(View.GONE);
            ll_re_order.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);

        }
    }


    private void findViewById() {
        orderId = getIntent().getStringExtra(Constants.ORDER_ID);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        tv_order_status = findViewById(R.id.tv_order_status);
        tv_payment_method = findViewById(R.id.tv_payment_method);
        tv_order_total = findViewById(R.id.tv_order_total);
        tv_order_date = findViewById(R.id.tv_order_date);
        tv_order_number = findViewById(R.id.tv_order_number);
        ll_main_layout = findViewById(R.id.ll_main_layout);
        tv_tax = findViewById(R.id.tv_tax);
        rcv_product_list = findViewById(R.id.rcv_product_list);
        tv_payment_status = findViewById(R.id.tv_payment_status);
        layoutLoading = findViewById(R.id.layoutLoading);
        tv_total = findViewById(R.id.tv_total);
        btnReload = findViewById(R.id.btnReload);
        btn_pdf_invoice = findViewById(R.id.btn_pdf_invoice);
        ll_re_order = findViewById(R.id.ll_re_order);
        tv_shipping_total = findViewById(R.id.tv_shipping_total);
        tv_shipping_method = findViewById(R.id.tv_shipping_method);
        tv_shipping_status = findViewById(R.id.tv_shipping_status);
        tv_sub_total = findViewById(R.id.tv_sub_total);

        tv_billing_name = findViewById(R.id.tv_billing_name);
        tv_billing_email = findViewById(R.id.tv_billing_email);
        tv_billing_phone_number = findViewById(R.id.tv_billing_phone_number);
        tv_billing_fax = findViewById(R.id.tv_billing_fax);
        tv_billing_address_1 = findViewById(R.id.tv_billing_address_1);
        tv_billing_city_pin = findViewById(R.id.tv_billing_city_pin);
        tv_billing_country = findViewById(R.id.tv_billing_country);

        tv_shipping_name = findViewById(R.id.tv_shipping_name);
        tv_shipping_email = findViewById(R.id.tv_shipping_email);
        tv_shipping_phone_number = findViewById(R.id.tv_shipping_phone_number);
        tv_shipping_fax = findViewById(R.id.tv_shipping_fax);
        tv_shipping_address_1 = findViewById(R.id.tv_shipping_address_1);
        tv_shipping_city_pin = findViewById(R.id.tv_shipping_city_pin);
        tv_shipping_country = findViewById(R.id.tv_shipping_country);

        btnReload.setOnClickListener(this);
        ll_re_order.setOnClickListener(this);
        btn_pdf_invoice.setOnClickListener(this);
    }

    private void toolbarInit() {
        toolbar.setTitle("Order Detail");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void callApiForData() {
        JSONHelper jsonHelper = new JSONHelper(this, Config.BASE_URL + "orders/" + orderId + "?Cid=" + currencyId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty() && result != "") {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("orders") && !jsonObject.isNull("orders")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("orders");
                        orderInfoList = new ArrayList<OrderModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            OrderModel orderModel = new OrderModel();
                            orderModel.parseForOrderInfo(obj);
                            orderInfoList.add(orderModel);
                        }
                    }
                }
                setUpAdapter();
            }
        }, false);
        jsonHelper.execute();
    }

    private void callApiForReorder() {
        String userId = SharedPrefsUtils.getStringPreference(this, Constants.PREF_USER_ID);
        JSONHelper jsonHelper = new JSONHelper(this, Config.BASE_URL + "orders/reorder?orderId=" + orderId +
                "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty() && result != "") {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success")) {
                        if (jsonObject.getString("Success").equals("0")) {
                            Toast.makeText(OrderDetailActivity.this, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(OrderDetailActivity.this, CartScreen.class));
                        } else {
                            Toast.makeText(OrderDetailActivity.this, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        }, false);
        jsonHelper.execute();
    }


    private void setUpAdapter() {
        layoutLoading.setVisibility(View.GONE);
        ll_main_layout.setVisibility(View.VISIBLE);
        ll_re_order.setVisibility(View.VISIBLE);

        if (orderInfoList.get(0).getOrderId() != null && orderInfoList.get(0).getOrderId() != "") {
            tv_order_number.setText("Order Number: " + orderInfoList.get(0).getOrderId());
        } else {
            tv_order_number.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getOrderStatus() != null && !orderInfoList.get(0).getOrderStatus().equals("")) {
            tv_order_status.setText("Order Status: " + orderInfoList.get(0).getOrderStatus());
        } else {
            tv_order_status.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getOrderDate() != null && !orderInfoList.get(0).getOrderDate().equals("")) {
            tv_order_date.setText("Order Date: " + orderInfoList.get(0).getOrderDate());
        } else {
            tv_order_date.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getOrderTotal() != null && !orderInfoList.get(0).getOrderTotal().equals("")) {
            tv_order_total.setText(orderInfoList.get(0).getOrderTotal());
        } else {
            tv_order_total.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getPaymentMethod() != null && orderInfoList.get(0).getPaymentMethod() != "") {
            tv_payment_method.setText("Payment Method: " + orderInfoList.get(0).getPaymentMethod());
        } else {
            tv_payment_method.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getPaymentStatus() != null && !orderInfoList.get(0).getPaymentStatus().equals("")) {
            tv_payment_status.setText("Payment Status: " + orderInfoList.get(0).getPaymentStatus());
        } else {
            tv_payment_status.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getShippingMethod() != null && !orderInfoList.get(0).getShippingMethod().equals("")) {
            tv_shipping_method.setText("Shipping Method: " + orderInfoList.get(0).getShippingMethod());
        } else {
            tv_shipping_method.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getShippingStatus() != null && !orderInfoList.get(0).getShippingStatus().equals("")) {
            tv_shipping_status.setText("Shipping Status: " + orderInfoList.get(0).getShippingStatus());
        } else {
            tv_shipping_status.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getOrderShippingTotal() != null && !orderInfoList.get(0).getOrderShippingTotal().equals("")) {
            tv_shipping_total.setText(orderInfoList.get(0).getCurrency() + orderInfoList.get(0).getOrderShippingTotal());
        } else {
            tv_shipping_total.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getOrderSubTotal() != null && !orderInfoList.get(0).getOrderSubTotal().equals("")) {
            tv_sub_total.setText(orderInfoList.get(0).getCurrency() + orderInfoList.get(0).getOrderSubTotal());
        } else {
            tv_sub_total.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getOrderTex() != null && !orderInfoList.get(0).getOrderTex().equals("")) {
            tv_tax.setText(orderInfoList.get(0).getCurrency() + orderInfoList.get(0).getOrderTex());
        } else {
            tv_tax.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getOrderTotal() != null && !orderInfoList.get(0).getOrderTotal().equals("")) {
            tv_total.setText(orderInfoList.get(0).getOrderTotal());
        } else {
            tv_total.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getBillingName() != null && !orderInfoList.get(0).getBillingName().equals("")) {
            tv_billing_name.setText(orderInfoList.get(0).getBillingName());
        } else {
            tv_billing_name.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getBillingEmail() != null && !orderInfoList.get(0).getBillingEmail().equals("")) {
            tv_billing_email.setText("Email: " + orderInfoList.get(0).getBillingEmail());
        } else {
            tv_billing_email.setVisibility(View.GONE);
        }


        if (orderInfoList.get(0).getBillingPhoneNumber() != null && !orderInfoList.get(0).getBillingPhoneNumber().equals("")) {
            tv_billing_phone_number.setText("Phone: " + orderInfoList.get(0).getBillingPhoneNumber());
        } else {
            tv_billing_phone_number.setVisibility(View.GONE);
        }


        if (orderInfoList.get(0).getBillingFax() != null && !orderInfoList.get(0).getBillingFax().equals("")) {
            tv_billing_fax.setText("Fax: " + orderInfoList.get(0).getBillingFax());
        } else {
            tv_billing_fax.setVisibility(View.GONE);
        }


        if (orderInfoList.get(0).getBillingAddress1() != null && !orderInfoList.get(0).getBillingAddress1().equals("")) {
            tv_billing_address_1.setText(orderInfoList.get(0).getBillingAddress1());
        } else {
            tv_billing_address_1.setVisibility(View.GONE);
        }

        tv_billing_city_pin.setText(orderInfoList.get(0).getBillingCity() + ", " + orderInfoList.get(0).getBillingZipCode());


        if (orderInfoList.get(0).getBillingCountry() != null && !orderInfoList.get(0).getBillingCountry().equals("")) {
            tv_billing_country.setText(orderInfoList.get(0).getBillingCountry());
        } else {
            tv_billing_country.setVisibility(View.GONE);
        }


        if (orderInfoList.get(0).getShippingName() != null && !orderInfoList.get(0).getShippingName().equals("")) {
            tv_shipping_name.setText(orderInfoList.get(0).getShippingName());
        } else {
            tv_shipping_name.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getShippingEmail() != null && !orderInfoList.get(0).getShippingEmail().equals("")) {
            tv_shipping_email.setText("Email: " + orderInfoList.get(0).getShippingEmail());
        } else {
            tv_shipping_email.setVisibility(View.GONE);
        }


        if (orderInfoList.get(0).getShippingPhoneNumber() != null && !orderInfoList.get(0).getShippingPhoneNumber().equals("")) {
            tv_shipping_phone_number.setText("Phone: " + orderInfoList.get(0).getShippingPhoneNumber());
        } else {
            tv_shipping_phone_number.setVisibility(View.GONE);
        }


        if (orderInfoList.get(0).getShippingFax() != null && !orderInfoList.get(0).getShippingFax().equals("")) {
            tv_shipping_fax.setText("Fax: " + orderInfoList.get(0).getShippingFax());
        } else {
            tv_shipping_fax.setVisibility(View.GONE);
        }


        if (orderInfoList.get(0).getShippingAddress1() != null && !orderInfoList.get(0).getShippingAddress1().equals("")) {
            tv_shipping_address_1.setText(orderInfoList.get(0).getShippingAddress1());
        } else {
            tv_shipping_address_1.setVisibility(View.GONE);
        }

        if (orderInfoList.get(0).getShippingCity() != null && !orderInfoList.get(0).getShippingCity().equals("")) {
            tv_shipping_city_pin.setText(orderInfoList.get(0).getShippingCity() + ", " + orderInfoList.get(0).getShippingZipCode());
        } else {
            tv_shipping_city_pin.setVisibility(View.GONE);
        }


        if (orderInfoList.get(0).getShippingCountry() != null && orderInfoList.get(0).getShippingCountry() != "") {
            tv_shipping_country.setText(orderInfoList.get(0).getShippingCountry());
        } else {
            tv_shipping_country.setVisibility(View.GONE);
        }


        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this);
        linearLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        rcv_product_list.setLayoutManager(linearLayoutManager2);

        if (orderInfoList.get(0).productModelList != null && orderInfoList.get(0).productModelList.size() > 0) {
            OrderDetailAdapter topTrendsListAdapter = new OrderDetailAdapter(this, orderInfoList.get(0).productModelList);
            rcv_product_list.setAdapter(topTrendsListAdapter);
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnReload:
                callApi();
                break;
            case R.id.ll_re_order:
                callApiForReorder();
                break;
            case R.id.btn_pdf_invoice:
                if (!checkPermission()) {
                    requestPermission();
                } else {
                    beginDownload(orderInfoList.get(0).getOrderId(), orderInfoList.get(0).getPdfInvoiceLink());
                }
                break;
        }
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }


    private void requestPermission() {

        ActivityCompat.requestPermissions(this, new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);

    }


    private void beginDownload(String orderId, String pdfInvoiceLink) {
        try {
            File file = new File(getExternalFilesDir(null), "testDemo");
            File direct = new File(Environment.getExternalStorageDirectory()
                    + "/testDemo");

            if (!direct.exists()) {
                direct.mkdirs();
            }


            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(pdfInvoiceLink))
                    .setTitle("Order_" + orderId)// Title of the Download Notification
                    .setDescription("Downloading")// Description of the Download Notification
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)// Visibility of the download Notification
                    .setDestinationUri(Uri.fromFile(file))// Uri
                    .setDestinationInExternalPublicDir("/testDemo", "Order_" + orderId + ".pdf")// of the destination file
                    .setRequiresCharging(false)// Set if charging is required to begin the download
                    .setAllowedOverMetered(true)// Set if download is allowed on Mobile network
                    .setAllowedOverRoaming(true);// Set if download is allowed on roaming network
            DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            downloadID = downloadManager.enqueue(request);// enqueue puts the download request in the queue.
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    BroadcastReceiver onDownloadComplete = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            //Fetching the download id received with the broadcast
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            //Checking if the received broadcast is for our enqueued download by matching download id
            if (downloadID == id) {
                Toast.makeText(OrderDetailActivity.this, "Download Completed", Toast.LENGTH_SHORT).show();
            }
        }
    };


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean cameraAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (locationAccepted && cameraAccepted)
                        beginDownload(orderInfoList.get(0).getOrderId(), orderInfoList.get(0).getPdfInvoiceLink());

                    else {
                        beginDownload(orderInfoList.get(0).getOrderId(), orderInfoList.get(0).getPdfInvoiceLink());

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(ACCESS_FINE_LOCATION)) {
                                showMessageOKCancel("You need to allow access to both the permissions",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(new String[]{READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
                                                }
                                            }
                                        });
                                return;
                            }
                        }
                    }
                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(OrderDetailActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }
}
