package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.SubCategoryActivity;
import com.testDemo.activites.SubCategoryRelatedActivity;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.ProductModel;

import java.util.ArrayList;

public class HolidaySaleListAdapter extends RecyclerView.Adapter<HolidaySaleListAdapter.ViewHolder> {
    Context context;
    ArrayList<CategoryModel> designerCollection;

    public HolidaySaleListAdapter(Context context, ArrayList<CategoryModel> designerCollection) {
        this.context = context;
        this.designerCollection = designerCollection;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.holiday_sale_product_row_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final CategoryModel myListData = designerCollection.get(position);
        Glide.with(holder.itemView)
                .load(myListData.getImage())
                .into(holder.iv_product_image);
        holder.tv_product_name.setText(myListData.getName());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((SubCategoryActivity) context).onClick(position);
            }
        });
    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_product_image;
        TextView tv_product_name;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            iv_product_image = (ImageView) itemView.findViewById(R.id.iv_product_image);
            tv_product_name = (TextView) itemView.findViewById(R.id.tv_product_name);

        }
    }
}