package com.testDemo.adapter;

public interface ListItemClickListener{
    void onItemClick(int position, String s);
}

