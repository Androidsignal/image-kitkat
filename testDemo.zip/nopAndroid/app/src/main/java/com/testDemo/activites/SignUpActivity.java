package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.UserModel;
import com.scottyab.showhidepasswordedittext.ShowHidePasswordEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;


public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {


    Activity context = SignUpActivity.this;

    AppCompatEditText editTextName;
    AppCompatEditText editTextEmail;
    ShowHidePasswordEditText editTextPassword;
    Button btnsignUp;
    Button btn_login_facebook;

    LinearLayout layoutMain;
    LinearLayout layoutError;
    LinearLayout layoutNoInternet;
    Button btnReload;
    TextView tv_login;
    ImageView iv_back;

    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String userId = "";
    String storeId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        findViewById();
        Glide.with(this)
                .load(R.drawable.back_full)
                .centerInside().into(iv_back);

        if (!Constants.isCheckInternetCon(context)) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
            storeId = SharedPrefsUtils.getStringPreference(SignUpActivity.this,Constants.PREF_SELECTED_STORE);
        } else {
            layoutMain.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
        }
    }

    public void findViewById() {

        editTextName = findViewById(R.id.et_Name);
        iv_back = findViewById(R.id.iv_back);
        editTextEmail = findViewById(R.id.et_userName);
        editTextPassword = findViewById(R.id.et_passWord);
        tv_login = findViewById(R.id.tv_login);


        layoutMain = findViewById(R.id.layoutMain);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutError = findViewById(R.id.layoutError);

        btnsignUp = findViewById(R.id.btn_signUp);
        btn_login_facebook = findViewById(R.id.btn_login_facebook);
        btnReload = findViewById(R.id.btnReload);

        btnsignUp.setOnClickListener(this);
        btnReload.setOnClickListener(this);
        btn_login_facebook.setOnClickListener(this);
        tv_login.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_signUp:
                if (validateForm()) {
                    callApiForRegistration();
                }
                break;
            case R.id.btn_login_facebook:
                startActivity(new Intent(SignUpActivity.this, SignUpActivity.class));
                break;
            case R.id.btnReload:
                recreate();
                break;
            case R.id.tv_login:
                finish();
                break;
        }
    }

    boolean validateForm() {
        if (!editTextName.getText().toString().isEmpty()) {
            if (!editTextEmail.getText().toString().isEmpty()) {
                if (!editTextPassword.getText().toString().isEmpty()) {
                    if (editTextEmail.getText().toString().matches(emailPattern)) {
                        return true;
                    } else {
//                    input_layout_email.setErrorEnabled(true);
                        editTextEmail.setError(getResources().getString(R.string.strErrorInvalidEmail));
                    }
                } else {
//                input_layout_password.setErrorEnabled(true);
                    editTextPassword.setError(getResources().getString(R.string.strErrorEmptyPassword));
                }
            } else {
//            input_layout_email.setErrorEnabled(true);
                editTextEmail.setError(getResources().getString(R.string.strErrorEmptyEmail));
            }
        } else {
            editTextName.setError(getResources().getString(R.string.strErrorEmptyName));
        }

        return false;
    }

    void callApiForRegistration() {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("firstName", editTextName.getText().toString());
        hashMap.put("emailId", editTextEmail.getText().toString());
        hashMap.put("password", editTextPassword.getText().toString());
        JSONHelper jsonHelper = new JSONHelper(SignUpActivity.this, Config.BASE_URL + "customers/register?storeid="+storeId, hashMap, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {
                        if (jsonObject.has("CustomerId") && !jsonObject.isNull("CustomerId")) {
                            userId = jsonObject.getString("CustomerId");
                            UserModel user = new UserModel();
                            if (jsonObject.has("id") && jsonObject.isNull("id")) {
                                user.setId(jsonObject.getString("id"));
                            }
                            if (jsonObject.has("first_name") && jsonObject.isNull("first_name")) {
                                user.setName(jsonObject.getString("first_name"));
                            }
                            if (jsonObject.has("email") && jsonObject.isNull("email")) {
                                user.setEmail(jsonObject.getString("email"));
                            }
                            if (jsonObject.has("password") && jsonObject.isNull("password")) {
                                user.setPassword(jsonObject.getString("password"));
                            }

                            if (user.getId() != null && !user.getId().isEmpty()) {
                                SharedPrefsUtils.setStringPreference(context, Constants.PREF_USER_ID, user.getId());
                            }
                            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                                SharedPrefsUtils.setStringPreference(context, Constants.PREF_USER_PASSWORD, user.getPassword());
                            }
                            if (user.getEmail() != null && !user.getEmail().isEmpty()) {
                                SharedPrefsUtils.setStringPreference(context, Constants.PREF_USER_EMAIL, user.getEmail());
                            }
                            if (user.getName() != null && !user.getName().isEmpty()) {
                                SharedPrefsUtils.setStringPreference(context, Constants.PREF_USER_NAME, user.getName());
                            }
                            SharedPrefsUtils.setStringPreference(context, Constants.PREF_USER_ID, userId);
                            startActivity(new Intent(context, HomeActivity.class));
                            finish();
                        }

                    } else {
                        Toast.makeText(getApplicationContext(), "SignUp Failed", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(context, "SignUp Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }, true);
        jsonHelper.execute();
    }

}





