package com.testDemo.config;

public class Config {
    public static String BASE_URL = "";
}
