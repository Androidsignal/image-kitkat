package com.testDemo.fragment;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.testDemo.R;
import com.testDemo.activites.CartScreen;
import com.testDemo.activites.CategoryActivity;
import com.testDemo.activites.HomeActivity;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.activites.ProductListActivity;
import com.testDemo.activites.ResetPasswordActivity;
import com.testDemo.activites.ResetPasswordDoneActivity;
import com.testDemo.activites.SearchAutoCompleteActivity;
import com.testDemo.adapter.BestSellerListAdapter;
import com.testDemo.adapter.DesignerCollectionListAdapter;
import com.testDemo.adapter.SliderAdapterExample;
import com.testDemo.adapter.TopTrendsListAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.DiscountModel;
import com.testDemo.model.ImageSliderModel;
import com.testDemo.model.ProductModel;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.IndicatorView.draw.controller.DrawController;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

import static com.smarteist.autoimageslider.IndicatorView.utils.DensityUtils.pxToDp;

/**
 * A simple {@link Fragment} subclass.
 */
public class ShopFragment extends Fragment implements View.OnClickListener {


    public static ShopFragment newInstance() {
        return new ShopFragment();
    }

    SliderView sliderView;
    RecyclerView rcv_designer_collection, rcv_designer_collection2, rcv_designer_collection3;
    SliderAdapterExample adapter;
    ImageSliderModel imageSliderModel;
    ArrayList<ProductModel> designerCollection;
    ArrayList<ProductModel> bestSeller;
    ArrayList<ProductModel> topTrendList;
    DesignerCollectionListAdapter designerCollectionListAdapter;
    TopTrendsListAdapter topTrendsListAdapter;
    BestSellerListAdapter bestSellerListAdapter;
    ProductModel productModel;
    CardView cv_slider;
    LinearLayout layoutLoading;
    LinearLayout layoutMain;
    LinearLayout layoutNoInternet;
    ImageView iv_toolbar_btn_cart,iv_toolbar_search_button;
    SwipeRefreshLayout swipeRefresh;
    String userId, currencyId, storeID;
    HomeActivity homeActivity;
    TextView show_all_designer, show_all_top_trends, show_all_best_seller;

    public ShopFragment() {
    }

    public ShopFragment(HomeActivity homeActivity) {
        this.homeActivity = homeActivity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shop, container, false);
        findViewById(view);
        userId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_USER_ID);
        currencyId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_SELECTED_CURRENCY);
        storeID = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_SELECTED_STORE);
        if (Constants.isCheckInternetCon(getActivity())) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            callApiForImageSlider();

        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefresh.setRefreshing(true);
                callApiForImageSlider();
            }
        });

        return view;
    }

    private void initView(DiscountModel discountModel) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); //
        rcv_designer_collection.setLayoutManager(linearLayoutManager);// s

        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(getActivity());
        linearLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        rcv_designer_collection2.setLayoutManager(linearLayoutManager2);

        rcv_designer_collection3.setLayoutManager(new GridLayoutManager(getActivity(), 1));

        setDataInList(discountModel);

    }


    public void callApiForImageSlider() {
        JSONHelper jsonHelper = new JSONHelper(getActivity(), Config.BASE_URL + "orders/nivosliderimage", null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty() && result != "") {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {
                        if (jsonObject.has("NivoSliderImages") && !jsonObject.isNull("NivoSliderImages")) {
                            JSONObject object = jsonObject.getJSONObject("NivoSliderImages");
                            imageSliderModel = new ImageSliderModel();
                            imageSliderModel.parse(object);
                        }
                    } else {
                        Toast.makeText(getActivity(), "ImageSliding Failed", Toast.LENGTH_SHORT).show();
                        /*layoutMain.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);*/
                    }
                } else {
                    Toast.makeText(getActivity(), "ImageSliding Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }
                callApiForNewProductList();
            }
        }, false);
        jsonHelper.execute();
    }

    public void callApiForNewProductList() {
        JSONHelper jsonHelper = new JSONHelper(getActivity(), Config.BASE_URL + "products/newarrivalproducts?Cid=" + currencyId + "&storeid=" + storeID + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty() && result != "") {
                    JSONObject jsonObject = new JSONObject(result);

                    if (jsonObject.has("NewArrivalProducts") && !jsonObject.isNull("NewArrivalProducts")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("NewArrivalProducts");
                        designerCollection = new ArrayList<ProductModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            productModel = new ProductModel();
                            productModel.parseForNewArrival(obj);
                            designerCollection.add(productModel);
//                            Log.d(TAG, "OnResult: ");
                        }

                    }

                } else {
                    Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }
                callApiForTopTrend();
            }
        }, false);
        jsonHelper.execute();
    }

    public void callApiForTopTrend() {
        JSONHelper jsonHelper = new JSONHelper(getActivity(), Config.BASE_URL + "products/featuredproducts?Cid=" + currencyId + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty() && result != "") {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("FeaturedProducts") && !jsonObject.isNull("FeaturedProducts")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("FeaturedProducts");
                        topTrendList = new ArrayList<ProductModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            productModel = new ProductModel();
                            productModel.parseForNewArrival(obj);
                            topTrendList.add(productModel);
                        }
                    }

                } else {
                    Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();

                }
                callApiForBestSeller();
            }

        }, false);
        jsonHelper.execute();

    }

    public void callApiForBestSeller() {
        JSONHelper jsonHelper = new JSONHelper(getActivity(), Config.BASE_URL + "products/bestsellersproduct?Cid=" + currencyId + "&storeid=" + storeID + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty() && result != "") {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("BestSellerProducts") && !jsonObject.isNull("BestSellerProducts")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("BestSellerProducts");
                        bestSeller = new ArrayList<ProductModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            productModel = new ProductModel();
                            productModel.parseForNewArrival(obj);
                            bestSeller.add(productModel);
                        }
                    }

                } else {
                    Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                }

                callApiForDialogOffer();

            }
        }, false);
        jsonHelper.execute();

    }

    public void callApiForDialogOffer() {
        JSONHelper jsonHelper = new JSONHelper(getActivity(), Config.BASE_URL + "products/homepagediscountproduct?Cid=" + currencyId + "&storeid=" + storeID, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                DiscountModel discountModel = new DiscountModel();
                if (result != null && !result.isEmpty() && result != "") {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("ProductDiscount") && !jsonObject.isNull("ProductDiscount")) {
                        JSONObject jsonArray = jsonObject.getJSONObject("ProductDiscount");
                        jsonArray.getString("id");
                        discountModel.setProductId(jsonArray.getString("id"));
                        jsonArray.getString("name");
                        discountModel.setProductName(jsonArray.getString("name"));
                        JSONObject jsonObjectImage = jsonArray.getJSONObject("images");
                        jsonObjectImage.getString("ImageUrl");
                        discountModel.setImageUrl(jsonObjectImage.getString("ImageUrl"));

                        JSONObject jsonObjectDiscount = jsonArray.getJSONObject("discount");
                        jsonObjectDiscount.getString("Name");
                        discountModel.setProductDiscount(jsonObjectDiscount.getString("Name"));

                        JSONObject jsonObjectProductPrice = jsonArray.getJSONObject("ProductPrice");
                        jsonObjectProductPrice.getString("OldPrice");
                        discountModel.setProductOldPrice(jsonObjectProductPrice.getString("OldPrice"));
                        jsonObjectProductPrice.getString("Price");
                        discountModel.setProductPrice(jsonObjectProductPrice.getString("Price"));

                    }
                } else {
                    Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                }

                setDataForSlider();
                initView(discountModel);
                swipeRefresh.setRefreshing(false);
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
            }
        }, false);
        jsonHelper.execute();

    }


    void setDataForSlider() {
        if (imageSliderModel != null) {
            Glide.with(this)
                    .asBitmap()
                    .load(imageSliderModel.getSliderImageUrl().get(0))
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            Log.w("TAGIMAGE", "Width -- >" + pxToDp(resource.getWidth()) + " Hight -- >" + pxToDp(resource.getHeight()));
                            sliderView.getLayoutParams().height = resource.getHeight();
                            sliderView.requestLayout();
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }
                    });
            adapter = new SliderAdapterExample(getActivity(), imageSliderModel.getSliderImageUrl());
            sliderView.setSliderAdapter(adapter);
            sliderView.setIndicatorAnimation(IndicatorAnimations.WORM);
            sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
            sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
            sliderView.setScrollTimeInSec(4); //set scroll delay in seconds :
            sliderView.startAutoCycle();
        }
    }

    private void setDataInList(DiscountModel discountModel) {

        if (designerCollection != null && designerCollection.size() > 0) {
            designerCollectionListAdapter = new DesignerCollectionListAdapter(getActivity(), designerCollection, this);
            rcv_designer_collection.setAdapter(designerCollectionListAdapter);
        }

        if (topTrendList != null && topTrendList.size() > 0) {
            topTrendsListAdapter = new TopTrendsListAdapter(getActivity(), topTrendList, this);
            rcv_designer_collection2.setAdapter(topTrendsListAdapter);
        }

        if (bestSeller != null && bestSeller.size() > 0) {
            bestSellerListAdapter = new BestSellerListAdapter(getActivity(), bestSeller, this);
            rcv_designer_collection3.setAdapter(bestSellerListAdapter);
        }

        if (homeActivity != null && discountModel.getProductId() != null && !discountModel.getProductId().isEmpty()) {
            homeActivity.dialogShow(discountModel);
        }
    }

    private void findViewById(View view) {
        sliderView = view.findViewById(R.id.imageSlider);
        show_all_designer = view.findViewById(R.id.show_all_designer);
        show_all_top_trends = view.findViewById(R.id.show_all_top_trends);
        iv_toolbar_btn_cart = view.findViewById(R.id.iv_toolbar_btn_cart);
        iv_toolbar_search_button = view.findViewById(R.id.iv_toolbar_search_button);
        show_all_best_seller = view.findViewById(R.id.show_all_best_seller);
        iv_toolbar_btn_cart.setOnClickListener(this);
        iv_toolbar_search_button.setOnClickListener(this);
        show_all_designer.setOnClickListener(this);
        show_all_top_trends.setOnClickListener(this);
        show_all_best_seller.setOnClickListener(this);
        rcv_designer_collection = view.findViewById(R.id.rcv_designer_collection);
        rcv_designer_collection2 = view.findViewById(R.id.rcv_designer_collection2);
        rcv_designer_collection3 = view.findViewById(R.id.rcv_designer_collection3);
        cv_slider = view.findViewById(R.id.cv_slider);
        layoutLoading = view.findViewById(R.id.layoutLoading);
        layoutMain = view.findViewById(R.id.ll_shop);
        layoutNoInternet = view.findViewById(R.id.layoutNoInternet);
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_toolbar_btn_cart:
                startActivity(new Intent(getActivity(), CartScreen.class));
                break;
            case R.id.show_all_designer:
                startActivity(new Intent(getActivity(), ProductListActivity.class).putExtra(Constants.IF_DESIGNER_COLLECTION, true));
                break;
            case R.id.show_all_top_trends:
                startActivity(new Intent(getActivity(), ProductListActivity.class).putExtra(Constants.IF_TOP_TREND, true));
                break;
            case R.id.show_all_best_seller:
                startActivity(new Intent(getActivity(), ProductListActivity.class).putExtra(Constants.IF_BESTSELLER, true));
                break;
            case R.id.iv_toolbar_search_button:
                startActivity(new Intent(getActivity(), SearchAutoCompleteActivity.class));
                break;
        }
    }

    public void favoriteOnclick(int position) {
        callApiForAddToCart(position);
    }

    public void onclickDesignerCollectionItem(int position) {
        Intent i = new Intent(getActivity(), ProductDetailActivity.class);
        if (designerCollection.size() > 0 && designerCollection.get(position) != null && designerCollection.get(position).getProductId() != null) {
            i.putExtra(Constants.INTENT_PRODUCT_ID, designerCollection.get(position).getProductId().toString());
        }
        startActivity(i);
    }


    public void onclickTopTrendsItem(int position) {
        Intent i = new Intent(getActivity(), ProductDetailActivity.class);
        if (topTrendList.size() > 0 && topTrendList.get(position) != null && topTrendList.get(position).getProductId() != null) {
            i.putExtra(Constants.INTENT_PRODUCT_ID, topTrendList.get(position).getProductId().toString());
        }
        startActivity(i);
    }

    public void onclickBestSellerItem(int position) {
        Intent i = new Intent(getActivity(), ProductDetailActivity.class);
        if (bestSeller.size() > 0 && bestSeller.get(position) != null && bestSeller.get(position).getProductId() != null) {
            i.putExtra(Constants.INTENT_PRODUCT_ID, bestSeller.get(position).getProductId().toString());
        }
        startActivity(i);
    }


    public void callApiForAddToCart(int position) {
        JSONHelper jsonHelper = new JSONHelper(getActivity(), Config.BASE_URL + "shopping_cart_items/addproducttoshoppingcart?customerId=" + userId + "&productId=" + designerCollection.get(position).getProductId() + "&shoppingCartTypeId=2&quantity=" + designerCollection.get(position).getItemQuantity() + "&attributeControlIds=0&rentalStartDate=null&rentalEndDate=null", null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getBoolean(jsonObject.getString("Success"))) {
                        String msg = jsonObject.getString("Message");
                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();

                    } else {
                        String msg = jsonObject.getString("Message");
                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }
            }
        }, true);
        jsonHelper.execute();
    }
}
