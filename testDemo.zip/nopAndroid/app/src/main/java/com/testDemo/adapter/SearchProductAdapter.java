package com.testDemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.SearchAutoCompleteActivity;
import com.testDemo.model.ProductModel;
import com.testDemo.model.TestModel;

import java.util.ArrayList;

public class SearchProductAdapter extends RecyclerView.Adapter<SearchProductAdapter.MyViewHolder> {

    Context context;
    ArrayList<ProductModel> arrayList;
    LayoutInflater layoutInflater;
    SearchAutoCompleteActivity searchAutoCompleteActivity;

    public SearchProductAdapter(Context context, ArrayList<ProductModel> arrayList, SearchAutoCompleteActivity searchAutoCompleteActivity) {

        this.context = context;
        this.arrayList = arrayList;
        this.searchAutoCompleteActivity = searchAutoCompleteActivity;
        layoutInflater = layoutInflater.from(context);

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.search_item,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        Glide.with(holder.itemView).load(arrayList.get(position).getProductImage()).into(holder.searchProductImage);
        holder.searchProductName.setText(arrayList.get(position).getProductName());
        holder.searchProductPrice.setText(arrayList.get(position).getProductPrice());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchAutoCompleteActivity.onClickProduct(arrayList.get(position).getProductId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView searchProductImage;
        TextView searchProductName, searchProductPrice;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            searchProductImage = itemView.findViewById(R.id.searchProductImage);
            searchProductName = itemView.findViewById(R.id.searchProductName);
            searchProductPrice = itemView.findViewById(R.id.searchProductPrice);

        }
    }
}
