package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.adapter.BestSellerListAdapter;
import com.testDemo.adapter.CategoryListAdapter;
import com.testDemo.adapter.HolidaySaleListAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.ProductModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Random;

public class SubCategoryActivity extends AppCompatActivity {

    Toolbar toolbar;
    RecyclerView rcv_holiday_sale;
    ArrayList<CategoryModel> subCategory;
    ArrayList<ProductModel> relatedCategory = new ArrayList<>();
    LinearLayout layoutMain, layoutLoading, layoutNoInternet, layoutError;
    HolidaySaleListAdapter holidaySaleListAdapter;
    ImageView iv_poster, iv_toolbar_btn_cart,iv_toolbar_search_button;
    String parentCategoryID;
    TextView tv_product_name, tv_product_price, tv_category_name;
    int random;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_category);
        findViewById();
        toolbarInit();
        if (Constants.isCheckInternetCon(SubCategoryActivity.this)) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            getSubCategory();
            getRelatedCategory();

        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }
    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("Cart");
        toolbar.setNavigationIcon(R.drawable.back_rounded);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void findViewById() {
        parentCategoryID = getIntent().getStringExtra(Constants.PARENT_CATEGORY_ID);
        tv_category_name = findViewById(R.id.tv_category_name);
        iv_toolbar_btn_cart = findViewById(R.id.iv_toolbar_btn_cart);
        iv_toolbar_search_button = findViewById(R.id.iv_toolbar_search_button);
        tv_product_name = findViewById(R.id.tv_product_name);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tv_product_price = findViewById(R.id.tv_product_price);
        layoutError = findViewById(R.id.layoutError);
        rcv_holiday_sale = findViewById(R.id.rcv_holiday_sale);
        layoutMain = findViewById(R.id.layoutMain);
        iv_poster = findViewById(R.id.iv_poster);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutLoading = findViewById(R.id.layoutLoading);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); //
        rcv_holiday_sale.setLayoutManager(linearLayoutManager);

        iv_toolbar_btn_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SubCategoryActivity.this, CartScreen.class));
            }
        });
        iv_toolbar_search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SubCategoryActivity.this, SearchAutoCompleteActivity.class));
            }
        });
    }

    public void getSubCategory() {
        subCategory = new ArrayList<>();
        subCategory = (ArrayList<CategoryModel>) getIntent().getSerializableExtra(Constants.CATEGORY_LIST);
        holidaySaleListAdapter = new HolidaySaleListAdapter(SubCategoryActivity.this, subCategory);
        rcv_holiday_sale.setAdapter(holidaySaleListAdapter);
    }


    private void getRelatedCategory() {
        try {
            JSONHelper helper = new JSONHelper(this, Config.BASE_URL + "categories/IncludeProductsFromSubcategories?CategoryId=" + parentCategoryID, null, new OnAsyncLoader() {
                @Override
                public void OnResult(String result) throws JSONException {
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        relatedCategory = new ArrayList<>();
                        if (jsonObject.has("ProductsFromParentcategory") && !jsonObject.isNull("ProductsFromParentcategory")) {
                            JSONArray jsonArray = jsonObject.getJSONArray("ProductsFromParentcategory");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                ProductModel model = new ProductModel();
                                model.parseForNewArrival(obj);
                                relatedCategory.add(model);
                            }


                        } else {
                            layoutLoading.setVisibility(View.GONE);
                            layoutError.setVisibility(View.VISIBLE);
                        }
                    } else {
                        layoutLoading.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);
                    }
                    setDataInPoster(random);
                }
            }, false);
            helper.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setDataInPoster(int random) {
        final int min = 0;
        int max = 0;
        if (relatedCategory.size() > 0) {
            max = relatedCategory.size() - 1;
        } else {
            max = 0;
        }
        random = new Random().nextInt((max - min) + 1) + min;

        layoutMain.setVisibility(View.VISIBLE);
        layoutLoading.setVisibility(View.GONE);
        try {
            if (relatedCategory != null && relatedCategory.size() > 0) {
                Glide.with(SubCategoryActivity.this)
                        .load(relatedCategory.get(random).getProductImage())
                        .placeholder(R.drawable.noimage)
                        .into(iv_poster);
                final int finalRandom = random;
                iv_poster.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (relatedCategory != null && relatedCategory.size() > 0) {
                            Intent i = new Intent(SubCategoryActivity.this, ProductDetailActivity.class);
                            i.putExtra(Constants.INTENT_PRODUCT_ID, relatedCategory.get(finalRandom).getProductId());
                            startActivity(i);
                        }
                    }
                });
                tv_product_name.setText(relatedCategory.get(random).getProductName());
                tv_product_price.setText(relatedCategory.get(random).getProductPrice());
                tv_category_name.setText(getIntent().getStringExtra(Constants.CATEGORY_NAME));
                random = 0;
            } else {
                Glide.with(SubCategoryActivity.this)
                        .load("https://image.freepik.com/free-vector/laptop-packages-with-bags_24877-56032.jpg")
                        .placeholder(R.drawable.noimage)
                        .into(iv_poster);
                tv_product_name.setVisibility(View.GONE);
                tv_product_price.setVisibility(View.GONE);
                tv_category_name.setText(getIntent().getStringExtra(Constants.CATEGORY_NAME));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void onClick(int position) {
        Intent intent = new Intent(SubCategoryActivity.this, SubCategoryRelatedActivityExample.class);
        intent.putExtra(Constants.CATEGORY_ID, subCategory.get(position).getId());
        intent.putExtra(Constants.POSITION, position);
        intent.putExtra(Constants.CATEGORY_NAME, subCategory.get(position).getName());
        intent.putExtra(Constants.CATEGORY_LIST, subCategory);
        startActivity(intent);
    }
}
