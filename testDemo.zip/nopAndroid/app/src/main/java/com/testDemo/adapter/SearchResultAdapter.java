package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.CartScreen;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.activites.SearchResultActivity;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.ViewHolder> {

    Context context;
    LayoutInflater layoutInflater;
    ArrayList<ProductModel> searchList;

    public SearchResultAdapter(Context context, ArrayList<ProductModel> searchList) {
        this.context = context;
        this.searchList = searchList;
        layoutInflater = layoutInflater.from(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.search_result_item,null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        Glide.with(holder.itemView)
                .load(searchList.get(position).getProductImage())
                .into(holder.iv_product_image);

        holder.tv_product_price.setText(searchList.get(position).getProductPrice());
        holder.tv_product_name.setText(searchList.get(position).getProductName());

        if (searchList.get(position).getOld_price().equals("$0.00"))
        {
            holder.tv_product_old_price.setVisibility(View.GONE);
        }
        else
        {
            holder.tv_product_old_price.setText(searchList.get(position).getOld_price());
            holder.tv_product_old_price.setPaintFlags(holder.tv_product_old_price.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
        holder.tv_product_rating.setRating(Float.parseFloat(searchList.get(position).getApproved_rating_sum()));


        final ProductModel myListData = searchList.get(position);

        if (myListData.isGetProductInShoppingCart()) {
            holder.iv_cart_not_added.setVisibility(View.GONE);
            holder.iv_cart_added.setVisibility(View.VISIBLE);
        } else {
            holder.iv_cart_not_added.setVisibility(View.VISIBLE);
            holder.iv_cart_added.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, ProductDetailActivity.class);
                i.putExtra(Constants.INTENT_PRODUCT_ID, myListData.getProductId().toString());
                context.startActivity(i);

            }
        });

        holder.iv_cart_not_added.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myListData.getAttributeModelArrayList() != null && myListData.getAttributeModelArrayList().size() > 0) {
                    Intent i = new Intent(context, ProductDetailActivity.class);
                    i.putExtra(Constants.INTENT_PRODUCT_ID, myListData.getProductId().toString());
                    context.startActivity(i);
                } else {
                    callApiForAddToCart(myListData, holder);
                }
            }
        });

        holder.iv_cart_added.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, CartScreen.class));
            }
        });
    }

    @Override
    public int getItemCount() {
        return searchList.size();
    }

    public void upDateArrayList(ArrayList<ProductModel> searchList) {
        this.searchList = searchList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_product_image;
        TextView tv_product_name, tv_product_price,tv_product_old_price;
        RatingBar tv_product_rating;
        CardView cardView;
        ImageView iv_cart_not_added, iv_cart_added;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            iv_cart_not_added = (ImageView) itemView.findViewById(R.id.iv_cart_not_added);
            iv_cart_added = (ImageView) itemView.findViewById(R.id.iv_cart_added);
            iv_product_image = (ImageView) itemView.findViewById(R.id.iv_product_image);
            tv_product_name = (TextView) itemView.findViewById(R.id.tv_product_name);
            tv_product_price = (TextView) itemView.findViewById(R.id.tv_product_price);
            tv_product_old_price = (TextView) itemView.findViewById(R.id.tv_product_old_price);
            tv_product_rating = (RatingBar) itemView.findViewById(R.id.tv_product_rating);
        }
    }

    void callApiForAddToCart(final ProductModel myListData, final ViewHolder viewHolder) {
        String userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);
        String storeId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_STORE);
        String url = Config.BASE_URL +
                "shopping_cart_items/addproducttoshoppingcart?customerId=" + userId +
                "&productId=" + myListData.getProductId() +
                "&shoppingCartTypeId=1&quantity=1&attributeControlIds=&rentalStartDate=null&rentalEndDate=null" + "&storeid=" + storeId;
        new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success")) {
                        if (jsonObject.getBoolean("Success")) {
                            if (jsonObject.has("Message") && !jsonObject.isNull("Message")) {
                                String message = jsonObject.getString("Message");
                                Toast.makeText(context, "" + Html.fromHtml(message), Toast.LENGTH_SHORT).show();
                                myListData.setProductInShoppingCart(true);
                                viewHolder.iv_cart_not_added.setVisibility(View.GONE);
                                viewHolder.iv_cart_added.setVisibility(View.VISIBLE);
                                notifyDataSetChanged();
                            }
                        } else {
                            if (jsonObject.has("message") && !jsonObject.isNull("message")) {
                                String message = jsonObject.getString("message");
                                Toast.makeText(context, "" + Html.fromHtml(message), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        }, true).execute();
    }
}
