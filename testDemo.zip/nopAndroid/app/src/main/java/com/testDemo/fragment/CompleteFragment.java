package com.testDemo.fragment;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.testDemo.R;
import com.testDemo.activites.HomeActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class CompleteFragment extends Fragment implements View.OnClickListener {


    public CompleteFragment() {
        // Required empty public constructor
    }


    Button btn_continue_shopping;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_complete, container, false);
        findViewById(view);
        return view;
    }

    private void findViewById(View view) {
        btn_continue_shopping=view.findViewById(R.id.btn_continue_shopping);
        btn_continue_shopping.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_continue_shopping:
                getActivity().startActivity(new Intent(getContext(), HomeActivity.class));
                getActivity().finish();
                break;
        }
    }
}
