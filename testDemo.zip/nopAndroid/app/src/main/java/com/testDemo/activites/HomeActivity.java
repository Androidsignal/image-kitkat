package com.testDemo.activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.app.Dialog;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.FacebookSdk;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.testDemo.R;
import com.testDemo.fragment.BrandFragment;
import com.testDemo.fragment.ExploreFragment;
import com.testDemo.fragment.ProfileFragment;
import com.testDemo.fragment.ShopFragment;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.model.DiscountModel;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    private BottomNavigationView mBottomNavigationView;
    private Toast exitToast;
    Button btn_offer_shop_now;
    ImageView iv_close_dialog;
    Toolbar toolbar;
    Dialog dialog;
    Button btnReload;

    DiscountModel discountModel;
    final Fragment shopFragment = new ShopFragment(HomeActivity.this);
    final Fragment exploreFragment = new ExploreFragment();
    final Fragment brandFragment = new BrandFragment();
    final Fragment profileFragment = new ProfileFragment();

    final FragmentManager fm = getSupportFragmentManager();
    Fragment active = shopFragment;

    LinearLayout layoutNoInternet, layoutMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_home);

        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutMain = findViewById(R.id.layoutMain);
        btnReload = findViewById(R.id.btnReload);
        btnReload.setOnClickListener(this);
        onCallApi();
    }

    public void dialogShow(DiscountModel discountModel) {
        if (SharedPrefsUtils.getBooleanPreference(HomeActivity.this, Constants.IN_APP_ONLY_ONE_TIME, false)) {
            SharedPrefsUtils.setBooleanPreference(HomeActivity.this, Constants.IN_APP_ONLY_ONE_TIME, false);
            showOfferDialog(discountModel);
        }
    }

    private void onCallApi() {
        if (Constants.isCheckInternetCon(this)) {
            layoutMain.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);

            setupBottomNavigation();


            fm.beginTransaction().add(R.id.fragment_frame, shopFragment, "1").commit();
            fm.beginTransaction().add(R.id.fragment_frame, exploreFragment, "2").hide(exploreFragment).commit();
            fm.beginTransaction().add(R.id.fragment_frame, brandFragment, "3").hide(brandFragment).commit();
            fm.beginTransaction().add(R.id.fragment_frame, profileFragment, "4").hide(profileFragment).commit();

            mBottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    switch (menuItem.getItemId()) {
                        case R.id.action_shop:
                            fm.beginTransaction().hide(active).show(shopFragment).commit();
                            active = shopFragment;
                            return true;
                        case R.id.action_explore:
                            fm.beginTransaction().hide(active).show(exploreFragment).commit();
                            active = exploreFragment;
                            return true;
                        case R.id.action_brand:
                            fm.beginTransaction().hide(active).show(brandFragment).commit();
                            active = brandFragment;
                            return true;
                        case R.id.action_profile:
                            fm.beginTransaction().hide(active).show(profileFragment).commit();
                            active = profileFragment;
                            return true;
                    }
                    return false;
                }
            });

        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
        }
    }


    private void showOfferDialog(DiscountModel discountModel) {
        this.discountModel = discountModel;
        dialog = new Dialog(HomeActivity.this);
        dialog.setContentView(R.layout.offer_dialog);
        iv_close_dialog = dialog.findViewById(R.id.iv_close_dialog);

        ImageView iv_offer = dialog.findViewById(R.id.iv_offer);
        TextView tv_discount = dialog.findViewById(R.id.tv_discount);
        TextView tv_product_name = dialog.findViewById(R.id.tv_product_name);
        TextView tv_price = dialog.findViewById(R.id.tv_price);
        TextView tv_old_price = dialog.findViewById(R.id.tv_old_price);


        Glide.with(this)
                .load(discountModel.getImageUrl())
                .into(iv_offer);

        tv_discount.setText(discountModel.getProductDiscount());
        tv_product_name.setText(discountModel.getProductName());
        tv_price.setText(discountModel.getProductPrice());
        tv_old_price.setText(discountModel.getProductOldPrice());
        tv_old_price.setPaintFlags(tv_old_price.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);


        btn_offer_shop_now = dialog.findViewById(R.id.btn_offer_shop_now);
        btn_offer_shop_now.setOnClickListener(this);
        iv_close_dialog.setOnClickListener(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.menu, menu);
//        return true;
//    }

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.menu_item_add_cart:
//                startActivity(new Intent(HomeActivity.this, CartScreen.class));
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }

    private void setupBottomNavigation() {

        mBottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);


    }

    @Override
    public void onBackPressed() {
        if (exitToast == null || exitToast.getView() == null || exitToast.getView().getWindowToken() == null) {
            exitToast = Toast.makeText(this, "Press again to exit", Toast.LENGTH_LONG);
            exitToast.show();
        } else {
            exitToast.cancel();
            finishAffinity();
            finish();
            super.onBackPressed();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_offer_shop_now:
                dialog.dismiss();
                dialog.cancel();
                Intent i = new Intent(this, ProductDetailActivity.class);
                i.putExtra(Constants.INTENT_PRODUCT_ID, discountModel.getProductId());
                startActivity(i);
                break;
            case R.id.iv_close_dialog:
                dialog.dismiss();
                dialog.cancel();
                break;
            case R.id.btnReload:
                onCallApi();
                break;
        }
    }

}
