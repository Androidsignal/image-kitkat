package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

public class CurrencyModel {

    String id;
    String name;
    String baseUrl;

    public CurrencyModel(String id, String name, String baseUrl) {
        this.id = id;
        this.name = name;
        this.baseUrl = baseUrl;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    @Override
    public String toString() {
        return "CurrencyModel{" +
                "name='" + name + '\'' +
                ", id='" + id + '\'' +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void parseForCurrency(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("Id") && !jsonObject.isNull("Id")) {
            id = jsonObject.getString("Id");
        }
        if (jsonObject.has("Name") && !jsonObject.isNull("Name")) {
            name = jsonObject.getString("Name");
        }

    }

}
