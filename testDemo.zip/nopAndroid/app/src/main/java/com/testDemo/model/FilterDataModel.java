package com.testDemo.model;

import java.util.ArrayList;

public class FilterDataModel {
    //region data which get from api

    String minimumValue = "";
    String maximumValue = "";

    ArrayList<SpecificationForFilterModel> specificationModelList = new ArrayList<>();
    ArrayList<CategoryModel> categoryModelList = new ArrayList<>();
    ArrayList<ManufacturerModel> manufacturerModelList = new ArrayList<>();
    ArrayList<AttributeModel> attributeModelList = new ArrayList<>();

    //endregion

    //region filter data which get from user
    String selectedMinimumValue = "";
    String selectedMaximumValue = "";

    String selectedManufactures = "";
    String selectedCategories = "";
    String selectedSpecificationAttributeString = "";
    String selectedProductAttributeString = "";
    //endregion


    public String getMinimumValue() {
        return minimumValue;
    }

    public void setMinimumValue(String minimumValue) {
        this.minimumValue = minimumValue;
    }

    public String getMaximumValue() {
        return maximumValue;
    }

    public void setMaximumValue(String maximumValue) {
        this.maximumValue = maximumValue;
    }

    public ArrayList<SpecificationForFilterModel> getSpecificationModelList() {
        return specificationModelList;
    }

    public void setSpecificationModelList(ArrayList<SpecificationForFilterModel> specificationModelList) {
        this.specificationModelList = specificationModelList;
    }

    public ArrayList<CategoryModel> getCategoryModelList() {
        return categoryModelList;
    }

    public void setCategoryModelList(ArrayList<CategoryModel> categoryModelList) {
        this.categoryModelList = categoryModelList;
    }

    public ArrayList<ManufacturerModel> getManufacturerModelList() {
        return manufacturerModelList;
    }

    public void setManufacturerModelList(ArrayList<ManufacturerModel> manufacturerModelList) {
        this.manufacturerModelList = manufacturerModelList;
    }

    public ArrayList<AttributeModel> getAttributeModelList() {
        return attributeModelList;
    }

    public void setAttributeModelList(ArrayList<AttributeModel> attributeModelList) {
        this.attributeModelList = attributeModelList;
    }

    public String getSelectedMinimumValue() {
        return selectedMinimumValue;
    }

    public void setSelectedMinimumValue(String selectedMinimumValue) {
        this.selectedMinimumValue = selectedMinimumValue;
    }

    public String getSelectedMaximumValue() {
        return selectedMaximumValue;
    }

    public void setSelectedMaximumValue(String selectedMaximumValue) {
        this.selectedMaximumValue = selectedMaximumValue;
    }

    public String getSelectedManufactures() {
        return selectedManufactures;
    }

    public void setSelectedManufactures(String selectedManufactures) {
        this.selectedManufactures = selectedManufactures;
    }

    public String getSelectedCategories() {
        return selectedCategories;
    }

    public void setSelectedCategories(String selectedCategories) {
        this.selectedCategories = selectedCategories;
    }

    public String getSelectedSpecificationAttributeString() {
        return selectedSpecificationAttributeString;
    }

    public void setSelectedSpecificationAttributeString(String selectedSpecificationAttributeString) {
        this.selectedSpecificationAttributeString = selectedSpecificationAttributeString;
    }

    public String getSelectedProductAttributeString() {
        return selectedProductAttributeString;
    }

    public void setSelectedProductAttributeString(String selectedProductAttributeString) {
        this.selectedProductAttributeString = selectedProductAttributeString;
    }

    @Override
    public String toString() {
        return "FilterDataModel{" +
                "minimumValue='" + minimumValue + '\'' +
                ", maximumValue='" + maximumValue + '\'' +
                ", specificationModelList=" + specificationModelList +
                ", categoryModelList=" + categoryModelList +
                ", manufacturerModelList=" + manufacturerModelList +
                ", attributeModelList=" + attributeModelList +
                ", selectedMinimumValue='" + selectedMinimumValue + '\'' +
                ", selectedMaximumValue='" + selectedMaximumValue + '\'' +
                ", selectedManufactures='" + selectedManufactures + '\'' +
                ", selectedCategories='" + selectedCategories + '\'' +
                ", selectedSpecificationAttributeString='" + selectedSpecificationAttributeString + '\'' +
                ", selectedProductAttributeString='" + selectedProductAttributeString + '\'' +
                '}';
    }
}
