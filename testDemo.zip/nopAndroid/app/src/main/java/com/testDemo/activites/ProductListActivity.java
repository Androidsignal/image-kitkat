package com.testDemo.activites;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.crystal.crystalrangeseekbar.interfaces.OnRangeSeekbarChangeListener;
import com.crystal.crystalrangeseekbar.widgets.CrystalRangeSeekbar;
import com.testDemo.R;
import com.testDemo.adapter.AttributeListAdapter;
import com.testDemo.adapter.FilterCategoryListAdapter;
import com.testDemo.adapter.ProductListAdapter;
import com.testDemo.adapter.SpecificationForFilterAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.PaginationScrollListener;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.ManufacturerModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.SpecificationForFilterModel;
import com.testDemo.model.SpecificationValueModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ProductListActivity extends AppCompatActivity implements View.OnClickListener {

    String TAG = getClass().getSimpleName();
    Activity context = ProductListActivity.this;


    boolean isFromBrand = false;
    boolean isFromDesignerCollection = false;
    boolean isFromTopTrend = false;
    boolean isFromBestSeller = false;
    boolean isLastPage = false;
    boolean isLoading = false;
    boolean isFilterOpen = false;
    boolean isFilterApplied = false;

    LinearLayout layoutMain;
    LinearLayout layoutLoading;
    LinearLayout layoutNoInternet;
    LinearLayout layoutError;
    LinearLayout layoutNoDataFound;
    LinearLayout layoutFilter;

    Button btnReload;

    RecyclerView recyclerViewForProduct;
    RecyclerView recyclerViewAttribute;

    TextView txtTitle;
    TextView txtTotalCount;

    ImageView imgFilterBtn;
    Toolbar toolbar;

    //region filter
    LinearLayout layoutPriceRange;
    TextView txtMinValue;
    TextView txtMaxValue;
    CrystalRangeSeekbar priceSeekBar;
    RecyclerView recyclerViewForSpecificationAttribute;
    RecyclerView recyclerViewForBrandOrCategory;
    ImageView imgCloseFilter;
    TextView txtListName;
    TextView txtSelectedAll;
    LinearLayout layoutCategoryOrBrandList;
    Button btnApply;
    Button btnClear;
    //endregion

    String minimumValue = "";
    String maximumValue = "";

    ArrayList<SpecificationForFilterModel> specificationModelList = new ArrayList<>();
    ArrayList<CategoryModel> categoryModelList = new ArrayList<>();
    ArrayList<ManufacturerModel> manufacturerModelList = new ArrayList<>();
    ArrayList<AttributeModel> attributeModelList = new ArrayList<>();

    String selectedMinimumValue = "";
    String selectedMaximumValue = "";

    String selectedManufactures = "";
    String selectedCategories = "";

    String selectedSpecificationAttributeString = "";
    String selectedProductAttributeString = "";

    int totalProductCount;

    int page = 1;

    String idFromIntent = "0";

    ArrayList<ProductModel> productList = new ArrayList<>();

    ProductListAdapter productListAdapter;
    ImageView iv_toolbar_btn_cart,iv_toolbar_search_button;

    String currencyId;
    String userId;
    GridLayoutManager gridLayoutManager;
    FilterCategoryListAdapter filterCategoryListAdapter;
    SpecificationForFilterAdapter specificationForFilterAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        currencyId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_CURRENCY);

        findViewById();

        getIntentData();

        setUpToolbar();

        if (Constants.isCheckInternetCon(context)) {
            layoutNoInternet.setVisibility(View.GONE);
            layoutMain.setVisibility(View.VISIBLE);
            layoutLoading.setVisibility(View.VISIBLE);
            recyclerViewForProduct.setVisibility(View.GONE);
            // TODO: 18/10/2019 callApiHere
            callApiToGetProducts();
        } else {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        }
    }

    void findViewById() {
        toolbar = findViewById(R.id.toolbar);

        iv_toolbar_btn_cart = findViewById(R.id.iv_toolbar_btn_cart);
        iv_toolbar_search_button = findViewById(R.id.iv_toolbar_search_button);
        layoutMain = findViewById(R.id.layoutMain);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutError = findViewById(R.id.layoutError);
        layoutNoDataFound = findViewById(R.id.layoutNoDataFound);
        layoutFilter = findViewById(R.id.layoutFilter);
        txtSelectedAll = findViewById(R.id.selectedAll);
        recyclerViewAttribute = findViewById(R.id.recyclerViewAttribute);

        txtTitle = findViewById(R.id.txtTitle);

        txtTotalCount = findViewById(R.id.txtTotalItem);
        imgFilterBtn = findViewById(R.id.imgFilterBtn);
        imgFilterBtn.setOnClickListener(this);

        recyclerViewForProduct = findViewById(R.id.recyclerViewForProduct);
        gridLayoutManager = new GridLayoutManager(context, 1);
        recyclerViewForProduct.setLayoutManager(gridLayoutManager);
        btnReload = findViewById(R.id.btnReload);

        btnReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.isCheckInternetCon(context)) {
                    layoutNoInternet.setVisibility(View.GONE);
                    layoutMain.setVisibility(View.VISIBLE);
                    layoutLoading.setVisibility(View.VISIBLE);
                    recyclerViewForProduct.setVisibility(View.GONE);
                    callApiToGetProducts();
                }
            }
        });

        iv_toolbar_btn_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProductListActivity.this, CartScreen.class));
            }
        });

        iv_toolbar_search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProductListActivity.this, SearchAutoCompleteActivity.class));
            }
        });


        txtMinValue = findViewById(R.id.minValue);
        txtMaxValue = findViewById(R.id.maxValue);
        priceSeekBar = findViewById(R.id.rangeSeekBar);
        recyclerViewForSpecificationAttribute = findViewById(R.id.recyclerViewForSpecificationAttribute);
        recyclerViewForBrandOrCategory = findViewById(R.id.rcv_brand);
        imgCloseFilter = findViewById(R.id.iv_cancel);
        layoutPriceRange = findViewById(R.id.layoutPriceRange);
        txtListName = findViewById(R.id.txtListName);
        layoutCategoryOrBrandList = findViewById(R.id.layoutCategoryOrBrandList);
        btnApply = findViewById(R.id.btn_apply);
        btnClear = findViewById(R.id.btn_clear);


        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickClear();
            }
        });

        btnApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickApply();
            }
        });

        imgCloseFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFilterOpen = false;
                layoutFilter.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
            }
        });
    }

    void setUpToolbar() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    void getIntentData() {
        if (getIntent().getStringExtra(Constants.INTENT_FOR_TITLE) != null) {
            txtTitle.setText(getIntent().getStringExtra(Constants.INTENT_FOR_TITLE));
        }
        if (getIntent().getStringExtra(Constants.INTENT_FOR_ID) != null) {
            idFromIntent = getIntent().getStringExtra(Constants.INTENT_FOR_ID);
        }

        userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);
        isFromBrand = getIntent().getBooleanExtra(Constants.IF_FROM_BRAND_LIST, false);
        isFromDesignerCollection = getIntent().getBooleanExtra(Constants.IF_DESIGNER_COLLECTION, false);
        isFromTopTrend = getIntent().getBooleanExtra(Constants.IF_TOP_TREND, false);
        isFromBestSeller = getIntent().getBooleanExtra(Constants.IF_BESTSELLER, false);
    }

    void callApiToGetProducts() {
        if (isFromBrand) {
            callApiForBrandsProduct();
        } else if (isFromDesignerCollection) {
            txtTitle.setText("Designer Collection");
            txtTotalCount.setVisibility(View.GONE);
            imgFilterBtn.setVisibility(View.GONE);
            callApiForDesignerCollection();
        } else if (isFromTopTrend) {
            txtTitle.setText("Top Trends");
            txtTotalCount.setVisibility(View.GONE);
            imgFilterBtn.setVisibility(View.GONE);
            callApiForTopTrends();
        } else if (isFromBestSeller) {
            txtTitle.setText("Best Seller");
            txtTotalCount.setVisibility(View.GONE);
            imgFilterBtn.setVisibility(View.GONE);
            callApiForBestSeller();
        } else {
            callApiForCategoriesProduct();
        }
    }

    void callApiForBrandsProduct() {
        if (page == 1) {
            if (selectedCategories.length() > 1) {
                selectedCategories = selectedCategories.substring(0, selectedCategories.length() - 1);
            }
            if (selectedSpecificationAttributeString.length() > 1) {
                selectedSpecificationAttributeString = selectedSpecificationAttributeString.substring(0, selectedSpecificationAttributeString.length() - 1);
            }
            if (selectedProductAttributeString.length() > 1) {
                selectedProductAttributeString = selectedProductAttributeString.substring(0, selectedProductAttributeString.length() - 1);
            }
        }
        String url = Config.BASE_URL +
                "categories/getproductbycategoriesIds?" +
                "menufectureId=" + idFromIntent +
                "&categoryIds=" + selectedCategories +
                "&page=" + page +
                "&pagesize=4" +
                "&orderby=0" +
                "&MinPrice=" + selectedMinimumValue +
                "&MaxPrice=" + selectedMaximumValue +
                "&spec=" + selectedSpecificationAttributeString +
                "&productValueid=" + selectedProductAttributeString +
                "&Cid=" + currencyId + "&customerId=" + userId;
        Log.i(TAG, "callApiForBrandsProduct: " + url);
        JSONHelper helper = new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Count") && !jsonObject.isNull("Count")) {
                        txtTotalCount.setText(jsonObject.getString("Count") + " Items");
                    }
                    if (jsonObject.has("ProductList") && !jsonObject.isNull("ProductList")) {
                        productList = new ArrayList<>();
                        JSONArray jsonArray = jsonObject.getJSONArray("ProductList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            ProductModel model = new ProductModel();
                            model.parseForNewArrival(obj);
                            productList.add(model);
                        }
                        if (jsonArray.length() < 1) {
                            isLastPage = true;
                        } else {
                            isLastPage = false;
                        }

                        if (page == 1) {
                            callApiToGetFilterAttributes();
                        } else {
                            setDataForRecyclerView();
                        }
                    } else {
                        layoutError.setVisibility(View.VISIBLE);
                        layoutMain.setVisibility(View.GONE);
                    }
                } else {
                    layoutError.setVisibility(View.VISIBLE);
                    layoutMain.setVisibility(View.GONE);
                }
            }
        }, false);
        helper.execute();
    }

    void callApiForCategoriesProduct() {
        if (page == 1) {
            if (selectedSpecificationAttributeString.length() > 1) {
                selectedSpecificationAttributeString = selectedSpecificationAttributeString.substring(0, selectedSpecificationAttributeString.length() - 1);
            }
            if (selectedManufactures.length() > 1) {
                selectedManufactures = selectedManufactures.substring(0, selectedManufactures.length() - 1);
            }
            if (selectedProductAttributeString.length() > 1) {
                selectedProductAttributeString = selectedProductAttributeString.substring(0, selectedProductAttributeString.length() - 1);
            }
        }
        String url = Config.BASE_URL + "categories/IncludeProductsFromSubcategories1?" +
                "CategoryId=" + idFromIntent +
                "&orderBy=0" +
                "&manufectureIds=" + selectedManufactures +
                "&page=" + page +
                "&pageSize=4" +
                "&MinPrice=" + selectedMinimumValue +
                "&MaxPrice=" + selectedMaximumValue +
                "&spec=" + selectedSpecificationAttributeString +
                "&productValueid=" + selectedProductAttributeString +
                "&Cid=" + currencyId + "&customerId=" + userId;
        Log.i(TAG, "callApiForCategoriesProduct: " + url);
        JSONHelper helper = new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Count") && !jsonObject.isNull("Count")) {
                        txtTotalCount.setText(jsonObject.getString("Count") + " Items");
                    }
                    if (jsonObject.has("ProductsFromParentcategory") && !jsonObject.isNull("ProductsFromParentcategory")) {
                        productList = new ArrayList<>();
                        JSONArray jsonArray = jsonObject.getJSONArray("ProductsFromParentcategory");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            ProductModel productModel = new ProductModel();
                            productModel.parseForRelatedProduct(obj);
                            productList.add(productModel);
                        }
                        if (jsonArray.length() < 1) {
                            isLastPage = true;
                        } else {
                            isLastPage = false;
                        }
                        if (page == 1) {
                            callApiToGetFilterAttributes();
                        } else {
                            setDataForRecyclerView();
                        }
                    } else {
                        layoutError.setVisibility(View.VISIBLE);
                        layoutMain.setVisibility(View.GONE);
                    }
                } else {
                    layoutError.setVisibility(View.VISIBLE);
                    layoutMain.setVisibility(View.GONE);
                }
            }
        }, false);
        helper.execute();
    }

    void callApiForDesignerCollection() {
        String storeId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_STORE);

        currencyId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_CURRENCY);
        JSONHelper jsonHelper = new JSONHelper(context, Config.BASE_URL + "products/newarrivalproducts?Cid=" + currencyId + "&storeid=" + storeId + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Count") && !jsonObject.isNull("Count")) {
                        txtTotalCount.setText(jsonObject.getString("Count") + " Items");
                    }
                    if (jsonObject.has("NewArrivalProducts") && !jsonObject.isNull("NewArrivalProducts")) {
                        productList = new ArrayList<>();
                        JSONArray jsonArray = jsonObject.getJSONArray("NewArrivalProducts");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            ProductModel productModel = new ProductModel();
                            productModel.parseForRelatedProduct(obj);
                            productList.add(productModel);
                        }
                        if (jsonArray.length() < 1) {
                            isLastPage = true;
                        } else {
                            isLastPage = false;
                        }
                        setDataForRecyclerView();

                    } else {
                        layoutError.setVisibility(View.VISIBLE);
                        layoutMain.setVisibility(View.GONE);
                    }
                } else {
                    layoutError.setVisibility(View.VISIBLE);
                    layoutMain.setVisibility(View.GONE);
                }
            }
        }, false);
        jsonHelper.execute();
    }

    void callApiForTopTrends() {
        String storeId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_STORE);
        currencyId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_CURRENCY);
        JSONHelper jsonHelper = new JSONHelper(context, Config.BASE_URL + "products/featuredproducts?Cid=" + currencyId + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Count") && !jsonObject.isNull("Count")) {
                        txtTotalCount.setText(jsonObject.getString("Count") + " Items");
                    }
                    if (jsonObject.has("FeaturedProducts") && !jsonObject.isNull("FeaturedProducts")) {
                        productList = new ArrayList<>();
                        JSONArray jsonArray = jsonObject.getJSONArray("FeaturedProducts");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            ProductModel productModel = new ProductModel();
                            productModel.parseForNewArrival(obj);
                            productList.add(productModel);
                        }
                        if (jsonArray.length() < 1) {
                            isLastPage = true;
                        } else {
                            isLastPage = false;
                        }
                        setDataForRecyclerView();

                    } else {
                        layoutError.setVisibility(View.VISIBLE);
                        layoutMain.setVisibility(View.GONE);
                    }
                } else {
                    layoutError.setVisibility(View.VISIBLE);
                    layoutMain.setVisibility(View.GONE);
                }
            }
        }, false);
        jsonHelper.execute();
    }

    void callApiForBestSeller() {
        String storeId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_STORE);
        currencyId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_CURRENCY);
        JSONHelper jsonHelper = new JSONHelper(context, Config.BASE_URL + "products/bestsellersproduct?Cid=" + currencyId + "&storeid=" + storeId + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Count") && !jsonObject.isNull("Count")) {
                        txtTotalCount.setText(jsonObject.getString("Count") + " Items");
                    }
                    if (jsonObject.has("BestSellerProducts") && !jsonObject.isNull("BestSellerProducts")) {
                        productList = new ArrayList<>();
                        JSONArray jsonArray = jsonObject.getJSONArray("BestSellerProducts");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            ProductModel productModel = new ProductModel();
                            productModel.parseForNewArrival(obj);
                            productList.add(productModel);
                        }
                        if (jsonArray.length() < 1) {
                            isLastPage = true;
                        } else {
                            isLastPage = false;
                        }
                        setDataForRecyclerView();

                    } else {
                        layoutError.setVisibility(View.VISIBLE);
                        layoutMain.setVisibility(View.GONE);
                    }
                } else {
                    layoutError.setVisibility(View.VISIBLE);
                    layoutMain.setVisibility(View.GONE);
                }
            }
        }, false);
        jsonHelper.execute();
    }

    void callApiToGetFilterAttributes() {
        if (isFilterApplied) {
            setDataForRecyclerView();
            return;
        }
        String url = Config.BASE_URL;
        if (isFromBrand) {
            url = url + "categories/manufecturefilter?menufectureId=" + idFromIntent;
        } else {
            url = url + "categories/categoryfilter?categoryId=" + idFromIntent;
        }

        JSONHelper helper = new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Maximumprice") && !jsonObject.isNull("Maximumprice")) {
                        maximumValue = jsonObject.getString("Maximumprice");
                    }
                    if (jsonObject.has("MiniMumPrice") && !jsonObject.isNull("MiniMumPrice")) {
                        minimumValue = jsonObject.getString("MiniMumPrice");
                    }
                    if (jsonObject.has("Categories") && !jsonObject.isNull("Categories")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("Categories");
                        categoryModelList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            CategoryModel model = new CategoryModel();
                            model.parse(object);
                            categoryModelList.add(model);
                        }
                    }
                    if (jsonObject.has("Manufacturers") && !jsonObject.isNull("Manufacturers")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("Manufacturers");
                        manufacturerModelList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            ManufacturerModel model = new ManufacturerModel();
                            model.parse(object);
                            manufacturerModelList.add(model);
                        }
                    }
                    if (jsonObject.has("productAttribute") && !jsonObject.isNull("productAttribute")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("productAttribute");
                        specificationModelList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            SpecificationForFilterModel model = new SpecificationForFilterModel();
                            model.parse(object);
                            specificationModelList.add(model);
                        }
                    }
                    if (jsonObject.has("customProductAttribute") && !jsonObject.isNull("customProductAttribute")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("customProductAttribute");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            AttributeModel model = new AttributeModel();
                            model.parse(object);
                            if (model.getAttributeType() == 1 || model.getAttributeType() == 2 || model.getAttributeType() == 40 || model.getAttributeType() == 45 || model.getAttributeType() == 3) {
                                attributeModelList.add(model);
                            }
                        }
                    }
                    setDataForFilterScreen();
                } else {
                    imgFilterBtn.setVisibility(View.GONE);
                    setDataForRecyclerView();
                }
            }
        }, false);
        helper.execute();
    }

    void setDataForRecyclerView() {

        if (productListAdapter != null) {
            isLoading = false;
            productListAdapter.removeLoadingFooter();
            productListAdapter.addItems(productList);
//            productListAdapter.notifyDataSetChanged();
        }
        layoutLoading.setVisibility(View.GONE);
        recyclerViewForProduct.setVisibility(View.VISIBLE);
        if (productList.size() == 0 && page == 1) {
            layoutLoading.setVisibility(View.GONE);
            recyclerViewForProduct.setVisibility(View.GONE);
            layoutNoDataFound.setVisibility(View.VISIBLE);
        }

        if (productListAdapter == null) {
            productListAdapter = new ProductListAdapter(context, productList, new ProductListScreen.OnClickProduct() {
                @Override
                public void OnClickProduct(int position) {
                    Intent i = new Intent(context, ProductDetailActivity.class);
                    if (productList.size() > 0 && productList.get(position) != null && productList.get(position).getProductId() != null) {
                        i.putExtra(Constants.INTENT_PRODUCT_ID, productList.get(position).getProductId());
                    }
                    startActivity(i);

                }
            }, null);
            recyclerViewForProduct.setAdapter(productListAdapter);
        }

        recyclerViewForProduct.addOnScrollListener(new PaginationScrollListener(gridLayoutManager) {
            @Override
            protected void loadMoreItems() {
                if (!isFromDesignerCollection && !isFromTopTrend && !isFromBestSeller) {
                    isLoading = true;
                    if (!isLastPage) {
                        page = page + 1;
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                productListAdapter.addLoadingFooter();
                                callApiToGetProducts();
                            }
                        }, 1000);
                    }
                }

            }

            @Override
            public boolean isLastPage() {
                return isLastPage;
            }

            @Override
            public boolean isLoading() {
                return isLoading;
            }
        });

    }

    void setDataForFilterScreen() {
        if (minimumValue != null && maximumValue != null && !minimumValue.isEmpty() && !maximumValue.isEmpty()) {

            selectedMinimumValue = minimumValue;
            selectedMaximumValue = maximumValue;

            txtMinValue.setText(minimumValue);
            txtMaxValue.setText(maximumValue);

            priceSeekBar.setMinValue(Float.parseFloat(minimumValue));
            priceSeekBar.setMaxValue(Float.parseFloat(maximumValue));
            priceSeekBar.setMinStartValue(Float.parseFloat(minimumValue)).setMaxStartValue(Float.parseFloat(maximumValue)).apply();

            priceSeekBar.setOnRangeSeekbarChangeListener(new OnRangeSeekbarChangeListener() {
                @Override
                public void valueChanged(Number min, Number max) {
                    txtMinValue.setText(String.valueOf(min));
                    txtMaxValue.setText(String.valueOf(max));
                }
            });

        } else {
            layoutPriceRange.setVisibility(View.VISIBLE);
        }

        if (attributeModelList.size() == 0) {
            recyclerViewAttribute.setVisibility(View.GONE);
        } else {
            LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(this);
            linearLayoutManager1.setOrientation(RecyclerView.VERTICAL);
            recyclerViewAttribute.setLayoutManager(linearLayoutManager1);
            AttributeListAdapter attributeListAdapter = new AttributeListAdapter(context, attributeModelList, null, new ArrayList<Integer>(), null);
            recyclerViewAttribute.setAdapter(attributeListAdapter);
        }

        if (manufacturerModelList.size() > 0 || categoryModelList.size() > 0) {

            if (isFromBrand) {
                txtListName.setText("Categories");
            } else {
                txtListName.setText("Brands");
            }

            if (isFromBrand) {
                filterCategoryListAdapter = new FilterCategoryListAdapter(context, categoryModelList);
            } else {
                filterCategoryListAdapter = new FilterCategoryListAdapter(context, new ArrayList<CategoryModel>(), manufacturerModelList);
            }
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
            recyclerViewForBrandOrCategory.setLayoutManager(linearLayoutManager);
            recyclerViewForBrandOrCategory.setAdapter(filterCategoryListAdapter);

            specificationForFilterAdapter = new SpecificationForFilterAdapter(context, specificationModelList);
            LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(this);
            linearLayoutManager1.setOrientation(RecyclerView.VERTICAL);
            recyclerViewForSpecificationAttribute.setLayoutManager(linearLayoutManager1);
            recyclerViewForSpecificationAttribute.setAdapter(specificationForFilterAdapter);

            txtSelectedAll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filterCategoryListAdapter.selectAll();
                }
            });
        } else {
            txtListName.setVisibility(View.GONE);
            txtSelectedAll.setVisibility(View.GONE);
        }
        setDataForRecyclerView();
    }

    void onClickFilter() {
        isFilterOpen = true;
        layoutMain.setVisibility(View.GONE);
        toolbar.setVisibility(View.GONE);
        layoutFilter.setVisibility(View.VISIBLE);
    }

    void onClickApply() {

        isFilterOpen = false;
        productListAdapter = null;
        page = 1;
        isLastPage = false;
        isFilterApplied = true;

        selectedSpecificationAttributeString = "";
        selectedCategories = "";
        selectedManufactures = "";
        selectedMinimumValue = String.valueOf(priceSeekBar.getSelectedMinValue());
        selectedMaximumValue = String.valueOf(priceSeekBar.getSelectedMaxValue());
        for (int i = 0; i < categoryModelList.size(); i++) {
            CategoryModel model = categoryModelList.get(i);
            if (model.isSelected()) {
                selectedCategories = selectedCategories + model.getId() + ",";
            }
        }
        for (int i = 0; i < manufacturerModelList.size(); i++) {
            ManufacturerModel model = manufacturerModelList.get(i);
            if (model.isSelected()) {
                selectedManufactures = selectedManufactures + model.getId() + ",";
            }
        }
        for (int i = 0; i < specificationModelList.size(); i++) {
            SpecificationForFilterModel specification = specificationModelList.get(i);
            for (int j = 0; j < specification.getSpecificationValueModelList().size(); j++) {
                SpecificationValueModel value = specification.getSpecificationValueModelList().get(j);
                if (value.isSelected()) {
                    selectedSpecificationAttributeString = selectedSpecificationAttributeString + value.getId() + ",";
                }
            }
        }
        for (int i = 0; i < attributeModelList.size(); i++) {
            AttributeModel model = attributeModelList.get(i);
            if (model.getAttributeType() == 1 || model.getAttributeType() == 2 || model.getAttributeType() == 40 || model.getAttributeType() == 45) {
                if (model.getCurrentValueModel() != null) {
                    selectedProductAttributeString = selectedProductAttributeString + model.getCurrentValueModel().getId() + ",";
                }
            } else if (model.getAttributeType() == 3 || model.getAttributeType() == 50) {
                if (model.getSelectedValueModelList() != null) {
                    for (int j = 0; j < model.getSelectedValueModelList().size(); j++) {
                        if (model.getSelectedValueModelList().get(j) != null) {
                            selectedProductAttributeString = selectedProductAttributeString + model.getSelectedValueModelList().get(j).getId() + ",";
                        }
                    }
                }
            }
        }
        recyclerViewForProduct.setVisibility(View.GONE);
        layoutLoading.setVisibility(View.VISIBLE);
        layoutFilter.setVisibility(View.GONE);
        layoutMain.setVisibility(View.VISIBLE);
        toolbar.setVisibility(View.VISIBLE);

        callApiToGetProducts();
    }

    void onClickClear() {

        specificationModelList = new ArrayList<>();
        categoryModelList = new ArrayList<>();
        manufacturerModelList = new ArrayList<>();
        attributeModelList = new ArrayList<>();


        page = 1;
        isLastPage = false;
        isFilterApplied = false;
        productListAdapter = null;
        selectedSpecificationAttributeString = "";
        selectedProductAttributeString = "";
        selectedCategories = "";
        selectedMinimumValue = "";
        selectedMaximumValue = "";
        selectedCategories = "";
        selectedManufactures = "";

        isFilterOpen = false;
        recyclerViewForProduct.setVisibility(View.GONE);
        layoutLoading.setVisibility(View.VISIBLE);
        layoutFilter.setVisibility(View.GONE);
        layoutMain.setVisibility(View.VISIBLE);
        toolbar.setVisibility(View.VISIBLE);
        callApiToGetProducts();
    }

    @Override
    public void onBackPressed() {
        if (!isFilterOpen) {
            super.onBackPressed();
        } else {
            isFilterOpen = false;
            layoutMain.setVisibility(View.VISIBLE);
            layoutFilter.setVisibility(View.GONE);
            toolbar.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.imgFilterBtn) {
            onClickFilter();
        }
    }
}
