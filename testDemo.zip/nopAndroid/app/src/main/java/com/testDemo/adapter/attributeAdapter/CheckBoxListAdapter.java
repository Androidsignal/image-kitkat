package com.testDemo.adapter.attributeAdapter;

import android.content.Context;
import android.text.Html;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputLayout;
import com.testDemo.R;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.adapter.AttributeListAdapter;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.AttributeValueModel;

import java.util.ArrayList;

public class CheckBoxListAdapter extends RecyclerView.Adapter<CheckBoxListAdapter.ViewHolder>{
    Context context;
    ArrayList<AttributeValueModel> valueModelArrayList ;
    AttributeModel attributeModel;
    boolean isReadOnly = false;
    AttributeListAdapter attributeListAdapter;
    ProductDetailActivity productDetailActivity;


    public CheckBoxListAdapter(Context context, ArrayList<AttributeValueModel> valueModelArrayList, AttributeModel attributeModel,boolean isReadOnly,AttributeListAdapter attributeListAdapter1,ProductDetailActivity productDetailActivity) {
        this.context = context;
        this.valueModelArrayList = valueModelArrayList;
        this.attributeModel = attributeModel;
        this.isReadOnly = isReadOnly;
        this.attributeListAdapter = attributeListAdapter1;
        this.productDetailActivity = productDetailActivity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.checkbox_list_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final AttributeValueModel model = valueModelArrayList.get(position);
        holder.title.setText(model.getName());
        if(isReadOnly){
            holder.checkbox.setEnabled(false);
            holder.layoutMain.setEnabled(false);
            holder.layoutMain.setClickable(false);
        }
        if(attributeModel.getSelectedValueModelList().contains(model)){
            holder.checkbox.setChecked(true);
        }
        holder.layoutMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(attributeModel.getSelectedValueModelList().contains(model)){
                    holder.checkbox.setChecked(false);
                }else{
                    holder.checkbox.setChecked(true);
                }
            }
        });
        holder.checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    attributeModel.getSelectedValueModelList().add(model);
                    if(attributeModel.getSelectedValueModelList().size()>0){
                        attributeModel.setError(null);
                    }
                }else{
                    attributeModel.getSelectedValueModelList().remove(model);
                    if(attributeModel.getSelectedValueModelList().size()>0){
                        attributeModel.setError(null);
                    }
                }
                if(productDetailActivity != null) {
                    productDetailActivity.callApiForHideAttributeIds(true);
                }else{
                    notifyDataSetChanged();
                    attributeListAdapter.notifyDataSetChanged();
                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return valueModelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        LinearLayout layoutMain;
        CheckBox checkbox;
        TextView title;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);

            layoutMain = itemView.findViewById(R.id.layoutMain);
            checkbox = itemView.findViewById(R.id.checkbox);
            title = itemView.findViewById(R.id.title);
        }
    }
}