package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.testDemo.R;
import com.testDemo.adapter.AddressAdapter;
import com.testDemo.adapter.ProductListAdapter;
import com.testDemo.adapter.SizeAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AddressModel;
import com.testDemo.model.AddressModels.AddressAttributeModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.SizeModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class ShippingAddressesActivity extends AppCompatActivity implements View.OnClickListener {
    Toolbar toolbar;
    RecyclerView rcv_shipping_addresses;
    ArrayList<AddressModel> addressList = new ArrayList<AddressModel>();
    AddressModel addressModel;
    AddressAdapter addressAdapter;
    LinearLayout layoutMain, layoutLoading, layoutNoInternet, empty_location;
    Button btn_newAddress, btnReload;
    String userId;
    ImageView imgButtonAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipping_addresses);
        findViewById();
        toolbarInit();
        callApi();

    }

    private void ifLocationIsEmpty() {
        if (addressList != null && addressList.size() > 0) {
            empty_location.setVisibility(View.GONE);
            layoutMain.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.GONE);
            empty_location.setVisibility(View.VISIBLE);
        }
    }

    private void findViewById() {

        layoutMain = findViewById(R.id.layoutMain);
        layoutLoading = findViewById(R.id.layoutLoading);
        empty_location = findViewById(R.id.empty_location);
        imgButtonAdd = findViewById(R.id.iv_toolbar_btn_address);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        btn_newAddress = findViewById(R.id.btn_newAddress);
        btnReload = findViewById(R.id.btnReload);
        userId = SharedPrefsUtils.getStringPreference(ShippingAddressesActivity.this, Constants.PREF_USER_ID);
        rcv_shipping_addresses = findViewById(R.id.rcv_shipping_addresses);
        LinearLayoutManager linear_rcv_brand = new LinearLayoutManager(this);
        linear_rcv_brand.setOrientation(RecyclerView.VERTICAL); // set Horizontal Orientation
        rcv_shipping_addresses.setLayoutManager(linear_rcv_brand);
        btn_newAddress.setOnClickListener(this);
        imgButtonAdd.setOnClickListener(this);
        btnReload.setOnClickListener(this);
    }

    private void toolbarInit() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    public void callApi() {
        if (Constants.isCheckInternetCon(ShippingAddressesActivity.this)) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            callApiForAddress();

        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }

    }

    private void callApiForAddress() {

        JSONHelper jsonHelper = new JSONHelper(ShippingAddressesActivity.this, Config.BASE_URL + "customers/customersaddresses?customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    Constants.isLoadingForAddress = false;
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Addresses") && !jsonObject.isNull("Addresses")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("Addresses");
                        addressList = new ArrayList<AddressModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            addressModel = new AddressModel();
                            addressModel.parseForAddress(obj);
                            addressList.add(addressModel);
                        }
                    }
                } else {
                    Toast.makeText(ShippingAddressesActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
                ifLocationIsEmpty();
                addressAdapter = new AddressAdapter(ShippingAddressesActivity.this, addressList, userId, new OnDelete() {
                    @Override
                    public void OnDelete(int position) throws JSONException {
                        deleteShippingAddress(addressList.get(position).getAddressId(), position);
                    }
                }, ShippingAddressesActivity.this);
                rcv_shipping_addresses.setAdapter(addressAdapter);

            }
        }, false);
        jsonHelper.execute();
    }

    private void deleteShippingAddress(final String addressId, final int position) {
        try {
            new SweetAlertDialog(this, SweetAlertDialog.CUSTOM_IMAGE_TYPE)
                    .setTitleText("Are you sure want to Delete Address?")
                    .setConfirmText("Yes!")
                    .setCustomImage(R.mipmap.ic_launcher)
                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            sDialog.dismissWithAnimation();
                            deleteAddressCallApi(addressId, position);

                        }
                    })
                    .setCancelButton("No", new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            sDialog.dismissWithAnimation();
                        }
                    })
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteAddressCallApi(String addressId, final int position) {

        JSONHelper jsonHelper = new JSONHelper(this, Config.BASE_URL + "customers/deletecustomeraddress?addressId=" +
                addressId.toString() + "&customerId=" + userId.toString(), null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    String errorCode = jsonObject.getString("errorcode");
                    if (errorCode.equals("0")) {
                        addressList.remove(position);
                        addressAdapter.notifyItemRemoved(position);
                        addressAdapter.notifyItemRangeChanged(position, addressList.size());
                        addressAdapter.notifyDataSetChanged();
                        ifLocationIsEmpty();
                        Toast.makeText(ShippingAddressesActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(ShippingAddressesActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, false);
        jsonHelper.execute();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_toolbar_btn_address:
                onClickAddAddress();
                break;

            case R.id.btn_newAddress:
                onClickAddAddress();
                break;
            case R.id.btnReload:
                callApi();
                break;

        }
    }

    void onClickAddAddress() {
        Intent i = new Intent(ShippingAddressesActivity.this, AddAddressScreen.class);
        startActivity(i);
    }

    public void onClickEditAddress(int position) {
        Intent i = new Intent(ShippingAddressesActivity.this, AddAddressScreen.class);
        i.putExtra(Constants.INTENT_ADDRESS_MODEL, addressList.get(position).getAddressId());
        startActivity(i);
    }

    public interface OnDelete {
        public void OnDelete(int position) throws JSONException;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Constants.isLoadingForAddress) {
            if (Constants.isCheckInternetCon(ShippingAddressesActivity.this)) {
                layoutMain.setVisibility(View.GONE);
                layoutLoading.setVisibility(View.VISIBLE);
                callApiForAddress();
            }
        }
    }
}

