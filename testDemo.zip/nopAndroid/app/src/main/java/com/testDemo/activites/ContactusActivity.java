package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.regex.Pattern;

public class ContactusActivity extends AppCompatActivity implements View.OnClickListener {

    Toolbar toolbar;
    EditText contactFullname;
    EditText contactEmail;
    EditText contactEnquiry;
    Button submitContact;

    String TAG = getClass().getSimpleName();
    Activity context = ContactusActivity.this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactus);

        findViewById();

        toolbarInit();
    }

    void findViewById()
    {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        contactFullname = findViewById(R.id.contactFullname);
        contactEmail = findViewById(R.id.contactEmail);
        contactEnquiry = findViewById(R.id.contactEnquiry);
        submitContact = findViewById(R.id.submitContact);
        submitContact.setOnClickListener(this);


    }

    private void toolbarInit() {

        toolbar.setBackground(null);
        toolbar.setTitle("Contactus");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private boolean isValidMail(String email) {

        String EMAIL_STRING = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        return Pattern.compile(EMAIL_STRING).matcher(email).matches();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.submitContact:
                callApiForSubmitContact();
                break;
        }
    }

    private void callApiForSubmitContact() {

        String contactFullNameHolder = contactFullname.getText().toString();
        String contactEmailHolder = contactEmail.getText().toString();
        String contactEnquiryHolder = contactEnquiry.getText().toString();


        if (contactFullNameHolder.isEmpty())
        {
            contactFullname.setError("Email is Empty");
        }
        else if (!isValidMail(contactEmailHolder))
        {
            contactEmail.setError("Invalid Email");
        }
        else if (contactEnquiryHolder.isEmpty())
        {
            contactEnquiry.setError("Enquiry is Empty");
        }
        else {

            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("Email",contactEmailHolder);
            hashMap.put("Enquiry",contactEnquiryHolder);
            hashMap.put("FullName",contactFullNameHolder);

            String url = Config.BASE_URL+"customers/contactussend";

            JSONHelper jsonHelper = new JSONHelper(context, url, hashMap, new OnAsyncLoader() {
                @Override
                public void OnResult(String result) throws JSONException {

                    if (result != null && !result.isEmpty())
                    {
                        Log.d(TAG,result);

                        JSONObject jsonObject=new JSONObject(result);

                        if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0"))
                        {
                            if (jsonObject.has("ContacUsModel") && !jsonObject.isNull("ContacUsModel"))
                            {

                                JSONObject jsonObject1 = jsonObject.getJSONObject("ContacUsModel");

                                String resultToast = jsonObject1.getString("Result");

                                Toast.makeText(context, resultToast, Toast.LENGTH_SHORT).show();
                                finish();

                            }
                            else {
                                Toast.makeText(getApplicationContext(), "Sending Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Sending Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Sending Failed", Toast.LENGTH_SHORT).show();
                    }

                }
            },true);

            jsonHelper.execute();

        }
    }


}
