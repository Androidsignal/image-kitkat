package com.testDemo.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Attr;

import java.util.ArrayList;

public class ProductDetailModel {
    private int id;
    private String name = "";
    private String shortDescription = "";
    private String longDescription = "";
    private String price;
    private String oldPrice;
    private String sku;

    private int rating;
    private int reviews;


    private ArrayList<ImageListModel> imageList = new ArrayList<>();
    private ArrayList<AttributeModel> attributeModelArrayList = new ArrayList<>();
    private ArrayList<ProductSpecificationModel> specificationModelArrayList = new ArrayList<>();
    private ArrayList<Integer> associatedProductIdList = new ArrayList<>();
    private ArrayList<ProductDetailModel> associatedProductList = new ArrayList<>();

    //todo quantity dynamic
    private int selectedQuantity = 1;

    boolean isGiftCard = false;
    String giftCardType;
    String productType = "";

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getOldPrice() {
        return oldPrice;
    }

    public void setOldPrice(String oldPrice) {
        this.oldPrice = oldPrice;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public ArrayList<ImageListModel> getImageList() {
        return imageList;
    }

    public void setImageList(ArrayList<ImageListModel> imageList) {
        this.imageList = imageList;
    }

    public ArrayList<AttributeModel> getAttributeModelArrayList() {
        return attributeModelArrayList;
    }

    public void setAttributeModelArrayList(ArrayList<AttributeModel> attributeModelArrayList) {
        this.attributeModelArrayList = attributeModelArrayList;
    }

    public int getSelectedQuantity() {
        return selectedQuantity;
    }

    public void setSelectedQuantity(int selectedQuantity) {
        this.selectedQuantity = selectedQuantity;
    }

    public ArrayList<ProductSpecificationModel> getSpecificationModelArrayList() {
        return specificationModelArrayList;
    }

    public void setSpecificationModelArrayList(ArrayList<ProductSpecificationModel> specificationModelArrayList) {
        this.specificationModelArrayList = specificationModelArrayList;
    }

    public boolean isGiftCard() {
        return isGiftCard;
    }

    public void setGiftCard(boolean giftCard) {
        isGiftCard = giftCard;
    }

    public String getGiftCardType() {
        return giftCardType;
    }

    public void setGiftCardType(String giftCardType) {
        this.giftCardType = giftCardType;
    }

    public ArrayList<Integer> getAssociatedProductIdList() {
        return associatedProductIdList;
    }

    public void setAssociatedProductIdList(ArrayList<Integer> associatedProductIdList) {
        this.associatedProductIdList = associatedProductIdList;
    }

    public ArrayList<ProductDetailModel> getAssociatedProductList() {
        return associatedProductList;
    }

    public void setAssociatedProductList(ArrayList<ProductDetailModel> associatedProductList) {
        this.associatedProductList = associatedProductList;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }


    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public int getReviews() {
        return reviews;
    }

    public void setReviews(int reviews) {
        this.reviews = reviews;
    }

    @Override
    public String toString() {
        return "ProductDetailModel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", shortDescription='" + shortDescription + '\'' +
                ", longDescription='" + longDescription + '\'' +
                ", price='" + price + '\'' +
                ", oldPrice='" + oldPrice + '\'' +
                ", sku='" + sku + '\'' +
                ", imageList=" + imageList +
                ", attributeModelArrayList=" + attributeModelArrayList +
                ", specificationModelArrayList=" + specificationModelArrayList +
                ", selectedQuantity=" + selectedQuantity +
                ", isGiftCard=" + isGiftCard +
                ", giftCardType='" + giftCardType + '\'' +


                '}';
    }






    public void parse(JSONObject object) throws JSONException {
        if (object != null) {
            if (checkForNull("id", object)) {
                id = object.getInt("id");
            }
            if (checkForNull("name", object)) {
                name = object.getString("name");
            }
            if (checkForNull("short_description", object)) {
                shortDescription = object.getString("short_description");
            }
            if (checkForNull("full_description", object)) {
                longDescription = object.getString("full_description");
            }
            if (checkForNull("price", object)) {
                price = object.getString("price");
            }
            if (checkForNull("old_price", object)) {
                oldPrice = object.getString("old_price");
            }
            if (checkForNull("sku", object)) {
                sku = object.getString("sku");
            }
            if (checkForNull("product_type", object)) {
                productType = object.getString("product_type");
            }
            if (checkForNull("approved_rating_sum", object)) {
                rating = object.getInt("approved_rating_sum");
            }
            if (checkForNull("approved_total_reviews", object)) {
                reviews = object.getInt("approved_total_reviews");
            }
            if (checkForNull("images", object)) {
                JSONArray images = object.getJSONArray("images");
                imageList = new ArrayList<>();
                for (int i = 0; i < images.length(); i++) {
                    JSONObject imageJson = images.getJSONObject(i);
                    ImageListModel model = new ImageListModel();
                    model.parse(imageJson);
                    imageList.add(model);
                }
            }

            if (checkForNull("attributes", object)) {
                JSONArray attributes = object.getJSONArray("attributes");
                attributeModelArrayList = new ArrayList<>();
                for (int i = 0; i < attributes.length(); i++) {
                    JSONObject jsonObject = attributes.getJSONObject(i);
                    AttributeModel model = new AttributeModel();
                    model.parse(jsonObject);
                    attributeModelArrayList.add(model);
                }
            }

            if (checkForNull("ProductSpecifications", object)) {
                JSONArray jsonArray = object.getJSONArray("ProductSpecifications");
                specificationModelArrayList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    ProductSpecificationModel model = new ProductSpecificationModel();
                    model.parse(jsonObject);
                    specificationModelArrayList.add(model);
                }
            }

            if(checkForNull("GiftCardType",object)){
                giftCardType = object.getString("GiftCardType");
            }
            if(checkForNull("is_gift_card",object)){
                isGiftCard = object.getBoolean("is_gift_card");
            }
            if(checkForNull("order_minimum_quantity",object)){
                selectedQuantity = object.getInt("order_minimum_quantity");
            }

            if(checkForNull("associated_product_ids",object)){
                JSONArray jsonArray = object.getJSONArray("associated_product_ids");
                for (int i = 0; i < jsonArray.length(); i++) {
                    associatedProductIdList.add(jsonArray.getInt(i));
                }
            }
        }

    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }
}
