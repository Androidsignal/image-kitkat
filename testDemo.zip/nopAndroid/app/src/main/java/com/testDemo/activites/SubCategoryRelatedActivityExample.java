package com.testDemo.activites;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.crystal.crystalrangeseekbar.interfaces.OnRangeSeekbarChangeListener;
import com.crystal.crystalrangeseekbar.widgets.CrystalRangeSeekbar;
import com.google.android.material.appbar.AppBarLayout;
import com.testDemo.R;
import com.testDemo.adapter.ActivityListItemClickListener;
import com.testDemo.adapter.AttributeListAdapter;
import com.testDemo.adapter.FilterCategoryListAdapter;
import com.testDemo.adapter.SpecificationForFilterAdapter;
import com.testDemo.adapter.SubCategorySliderAdapter;
import com.testDemo.adapter.TabViewAdapter;
import com.testDemo.config.Config;
import com.testDemo.fragment.DynamicFragment;
import com.testDemo.fragment.SubCategoryProductListFragment;
import com.testDemo.global.Constants;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.FilterDataModel;
import com.testDemo.model.ManufacturerModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.SliderModel;
import com.testDemo.model.SpecificationForFilterModel;
import com.testDemo.model.SpecificationValueModel;
import com.ogaclejapan.smarttablayout.SmartTabLayout;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SubCategoryRelatedActivityExample extends AppCompatActivity implements View.OnClickListener, ActivityListItemClickListener {

    LinearLayout layoutLoading, layoutNoInternet, ll_filter, ll_brand, empty_list, ll_productList, layoutMain, layoutError;
    RecyclerView rcv_product_list, rcv_categoryList, rcv_brand;
    FrameLayout framLayout;

    Toolbar toolbar;
    AppBarLayout appBar;

    ImageView iv_option_more, iv_cancel, iv_toolbar_btn_cart;
    SubCategorySliderAdapter subCategorySliderAdapter;
    SliderView sliderView;

    ArrayList<ProductModel> subCategory = new ArrayList<>();
    ArrayList<SliderModel> sliderModelArrayList = new ArrayList<>();
    public static ArrayList<CategoryModel> subDisplayCategory;
    ArrayList<String> tabTitle = new ArrayList<>();

    NestedScrollView scroll_layout;

    Button btn_clear, btn_apply, btnReload;
    boolean isFilterOpen = false;


    TextView minValue, maxValue, selectedAll, tv_item_total, tv_category_name;

    SmartTabLayout tabLayout;
    public ViewPager viewPager;
    String currencyId, storeId;
    int position;


    DynamicFragment fragmentClick;

    //region filter
    //region filter views
    LinearLayout layoutPriceRange;
    LinearLayout btnLayout;
    LinearLayout layoutCategoryOrBrandList;
    TextView txtMinValue;
    TextView txtMaxValue;
    CrystalRangeSeekbar rangeSeekBar;
    RecyclerView recyclerViewForSpecificationAttribute;
    RecyclerView recyclerViewAttribute;
    RecyclerView recyclerViewForBrands;
    TextView txtListName;
    TextView txtSelectedAll;
    Button btnClear;
    Button btnApply;
    //endregion


    public static ArrayList<FilterDataModel> filterDataModelList = new ArrayList<>();
    public static ArrayList<View> viewList = new ArrayList<>();

    SpecificationForFilterAdapter specificationForFilterAdapter;
    FilterCategoryListAdapter filterCategoryListAdapter;

    Context context = SubCategoryRelatedActivityExample.this;

    //endregion

    public static Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        activity = SubCategoryRelatedActivityExample.this;

        setContentView(R.layout.activity_sub_category_related_example);
        findViewById();
        toolbarInit();
        initView();
        //callAPi();
    }

    private void initView() {
        filterDataModelList = new ArrayList<>();
        tv_category_name.setText(getIntent().getStringExtra(Constants.CATEGORY_NAME));
        position = getIntent().getIntExtra(Constants.POSITION, 0);
        subDisplayCategory = new ArrayList<CategoryModel>();
        subDisplayCategory = (ArrayList<CategoryModel>) getIntent().getSerializableExtra(Constants.CATEGORY_LIST);

        getDataForSlider();


    }

    private void getDataForSlider() {
        currencyId = getIntent().getStringExtra(Constants.CATEGORY_ID);
        JSONHelper helper = new JSONHelper(this, Config.BASE_URL + "orders/categorynivoslider?categoryId=" + currencyId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    sliderModelArrayList = new ArrayList<>();
                    if (jsonObject.has("CategoryPicture") && !jsonObject.isNull("CategoryPicture")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("CategoryPicture");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            SliderModel model = new SliderModel();
                            model.parseForImageSlider(obj);
                            sliderModelArrayList.add(model);
                        }

                    } else {
                        layoutLoading.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);
                    }
                } else {
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }
                setDataInLayOut(sliderModelArrayList);
            }
        }, false);
        helper.execute();
    }

    private void setDataInLayOut(ArrayList<SliderModel> sliderModelArrayList) {
        viewPager = findViewById(R.id.viewPager);

        if (sliderModelArrayList != null && sliderModelArrayList.size() > 0) {
            sliderView.setVisibility(View.VISIBLE);
            framLayout.setVisibility(View.VISIBLE);
            subCategorySliderAdapter = new SubCategorySliderAdapter(this, sliderModelArrayList);
            subCategorySliderAdapter.setCount(sliderModelArrayList.size());

            sliderView.setSliderAdapter(subCategorySliderAdapter);

            sliderView.setIndicatorAnimation(IndicatorAnimations.WORM);
            sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
            sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
            sliderView.setScrollTimeInSec(4); //set scroll delay in seconds :
            sliderView.startAutoCycle();

        } else {
            sliderView.setVisibility(View.GONE);
            framLayout.setVisibility(View.GONE);
        }


        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this);
        linearLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        recyclerViewForSpecificationAttribute.setLayoutManager(linearLayoutManager2);

        LinearLayoutManager linear_rcv_brand = new LinearLayoutManager(this);
        linear_rcv_brand.setOrientation(RecyclerView.VERTICAL); // set Horizontal Orientation
        rcv_brand.setLayoutManager(linear_rcv_brand);

        rangeSeekBar.setOnRangeSeekbarChangeListener(new OnRangeSeekbarChangeListener() {
            @Override
            public void valueChanged(Number min, Number max) {
                minValue.setText(String.valueOf(min));
                maxValue.setText(String.valueOf(max));
            }
        });

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                SharedPreferences.Editor editor = getSharedPreferences("subcatid", MODE_PRIVATE).edit();
                editor.putString("id", subDisplayCategory.get(position).getId());
                editor.apply();
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        setupViewPager(viewPager);
        viewPager.setCurrentItem(position, true);

    }

    private void findViewById() {
        fragmentClick = new DynamicFragment();
        layoutError = findViewById(R.id.layoutError);
        iv_toolbar_btn_cart = findViewById(R.id.iv_toolbar_btn_cart);
        tv_category_name = findViewById(R.id.tv_category_name);
        layoutMain = findViewById(R.id.layoutMain);
        appBar = findViewById(R.id.appBar);
        btnReload = findViewById(R.id.btnReload);
        rcv_brand = findViewById(R.id.rcv_brand);
        ll_filter = findViewById(R.id.ll_filter);
        btn_clear = findViewById(R.id.btn_clear);
        btn_apply = findViewById(R.id.btn_apply);
        iv_option_more = findViewById(R.id.iv_option_more);
        iv_cancel = findViewById(R.id.iv_cancel);
        tv_item_total = findViewById(R.id.tv_item_total);
        toolbar = findViewById(R.id.toolbar);
        rcv_product_list = findViewById(R.id.rcv_product_list);
        rcv_categoryList = findViewById(R.id.rcv_categoryList);
        sliderView = findViewById(R.id.imageSlider);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        scroll_layout = findViewById(R.id.scroll_layout);
        empty_list = findViewById(R.id.empty_list);
        selectedAll = findViewById(R.id.selectedAll);
        ll_productList = findViewById(R.id.ll_productList);
        tabLayout = (SmartTabLayout) findViewById(R.id.tabLayout2);
        ll_brand = findViewById(R.id.ll_brand);
        maxValue = findViewById(R.id.maxValue);
        minValue = findViewById(R.id.minValue);
        framLayout = findViewById(R.id.framLayout);

        //region filter screen
        layoutPriceRange = findViewById(R.id.layoutPriceRange);
        txtMinValue = findViewById(R.id.minValue);
        txtMaxValue = findViewById(R.id.maxValue);
        rangeSeekBar = findViewById(R.id.rangeSeekBar);
        recyclerViewForSpecificationAttribute = findViewById(R.id.recyclerViewForSpecificationAttribute);
        recyclerViewAttribute = findViewById(R.id.recyclerViewAttribute);
        recyclerViewForBrands = findViewById(R.id.rcv_brand);
        layoutCategoryOrBrandList = findViewById(R.id.layoutCategoryOrBrandList);
        txtListName = findViewById(R.id.txtListName);
        txtSelectedAll = findViewById(R.id.selectedAll);

        btnClear = findViewById(R.id.btn_clear);
        btnApply = findViewById(R.id.btn_apply);

        btnClear.setOnClickListener(this);
        btnApply.setOnClickListener(this);
        //endregion

        rcv_product_list.setLayoutManager(new GridLayoutManager(SubCategoryRelatedActivityExample.this, 2));
        btn_clear.setOnClickListener(this);
        btn_apply.setOnClickListener(this);
        iv_option_more.setOnClickListener(this);
        iv_cancel.setOnClickListener(this);
        selectedAll.setOnClickListener(this);
        btnReload.setOnClickListener(this);
        iv_toolbar_btn_cart.setOnClickListener(this);
    }

    private void ifLocationIsEmpty() {
        if (subCategory != null && subCategory.size() > 0) {
            empty_list.setVisibility(View.GONE);
            ll_productList.setVisibility(View.VISIBLE);
        } else {
            empty_list.setVisibility(View.VISIBLE);
            ll_productList.setVisibility(View.GONE);
        }
    }

    private void toolbarInit() {
        tabTitle.clear();
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void setupViewPager(ViewPager viewPager) {

        try {
            TabViewAdapter adapter = new TabViewAdapter(getSupportFragmentManager());

            for (int i = 0; i < subDisplayCategory.size(); i++) {
                filterDataModelList.add(new FilterDataModel());
                viewList.add(new View(context));
                adapter.addFragment(new SubCategoryProductListFragment(), subDisplayCategory.get(i).getName());
            }
            viewPager.setAdapter(adapter);
            viewPager.setOffscreenPageLimit(2);
            tabLayout.setViewPager(viewPager);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void onClickApply() {
        if(filterDataModelList.size() > viewPager.getCurrentItem()) {
            FilterDataModel model = filterDataModelList.get(viewPager.getCurrentItem());
                model.setSelectedMinimumValue(String.valueOf(rangeSeekBar.getSelectedMinValue()));
                model.setSelectedMaximumValue(String.valueOf(rangeSeekBar.getSelectedMaxValue()));

                model.setSelectedManufactures("");
                for (int i = 0; i < model.getManufacturerModelList().size(); i++) {
                    ManufacturerModel manufacturerModel = model.getManufacturerModelList().get(i);
                    if (manufacturerModel.isSelected()) {
                        model.setSelectedManufactures(model.getSelectedManufactures() + manufacturerModel.getId() + ",");
                    }
                }

                model.setSelectedSpecificationAttributeString("");
                for (int i = 0; i < model.getSpecificationModelList().size(); i++) {
                    SpecificationForFilterModel specification = model.getSpecificationModelList().get(i);
                    for (int j = 0; j < specification.getSpecificationValueModelList().size(); j++) {
                        SpecificationValueModel value = specification.getSpecificationValueModelList().get(j);
                        if (value.isSelected()) {
                            model.setSelectedSpecificationAttributeString(model.getSelectedManufactures() + value.getId() + ",");
                        }
                    }
                }
                model.setSelectedProductAttributeString("");
                for (int i = 0; i < model.getAttributeModelList().size(); i++) {
                    AttributeModel attributeModel = model.getAttributeModelList().get(i);
                    if (attributeModel.getAttributeType() == 1 || attributeModel.getAttributeType() == 2 || attributeModel.getAttributeType() == 40 || attributeModel.getAttributeType() == 45) {
                        if (attributeModel.getCurrentValueModel() != null) {
                            model.setSelectedProductAttributeString(model.getSelectedProductAttributeString() + attributeModel.getCurrentValueModel().getId() + ",");
                        }
                    } else if (attributeModel.getAttributeType() == 3 || attributeModel.getAttributeType() == 50) {
                        if (attributeModel.getSelectedValueModelList() != null) {
                            for (int j = 0; j < attributeModel.getSelectedValueModelList().size(); j++) {
                                if (attributeModel.getSelectedValueModelList().get(j) != null) {
                                    model.setSelectedProductAttributeString(model.getSelectedProductAttributeString() + attributeModel.getSelectedValueModelList().get(j).getId() + ",");
                                }
                            }
                        }
                    }
                }

                isFilterOpen = false;
                layoutMain.setVisibility(View.VISIBLE);
                appBar.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
                ll_filter.setVisibility(View.GONE);


                fragmentClick.onClickApplyButton(SubCategoryRelatedActivityExample.this, model);
        }
    }

    void onClickClear() {
        isFilterOpen = false;
        layoutMain.setVisibility(View.VISIBLE);
        appBar.setVisibility(View.VISIBLE);
        toolbar.setVisibility(View.VISIBLE);
        ll_filter.setVisibility(View.GONE);

        FilterDataModel model = new FilterDataModel();
        filterDataModelList.set(viewPager.getCurrentItem(),model);

        fragmentClick.onClickClear(SubCategoryRelatedActivityExample.this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_option_more:

                setDataForFilter();
                break;
            case R.id.iv_toolbar_btn_cart:
                startActivity(new Intent(SubCategoryRelatedActivityExample.this, CartScreen.class));
                break;
            case R.id.iv_cancel:
                isFilterOpen = false;
                layoutMain.setVisibility(View.VISIBLE);
                appBar.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
                ll_filter.setVisibility(View.GONE);
                break;
            case R.id.btn_apply:
                isFilterOpen = false;
                onClickApply();
                break;
            case R.id.btn_clear:
                isFilterOpen = false;
                onClickClear();
                break;

            case R.id.selectedAll:
                break;

            case R.id.btnReload:
//                callAPi();
                break;
        }
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        if (isFilterOpen) {
            isFilterOpen = false;
            layoutMain.setVisibility(View.VISIBLE);
            appBar.setVisibility(View.VISIBLE);
            toolbar.setVisibility(View.VISIBLE);
            ll_filter.setVisibility(View.GONE);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onItemClick(SubCategoryRelatedActivityExample subCategoryRelatedActivityExample) {
        Toast.makeText(subCategoryRelatedActivityExample, "IS From Frgment", Toast.LENGTH_SHORT).show();
    }

    public void setDataForFilter() {
        if(filterDataModelList.size() > viewPager.getCurrentItem()) {
            FilterDataModel filter = filterDataModelList.get(viewPager.getCurrentItem());
            if (filter != null) {
                if(filter.getMinimumValue() != null && !filter.getMinimumValue().isEmpty()) {
                    isFilterOpen = true;
                    iv_option_more.setVisibility(View.VISIBLE);

                    if (filter.getMinimumValue() != null && filter.getMaximumValue() != null && !filter.getMinimumValue().isEmpty() && !filter.getMaximumValue().isEmpty()) {
                        layoutPriceRange.setVisibility(View.VISIBLE);
                        if (filter.getSelectedMinimumValue() == null || filter.getSelectedMinimumValue().isEmpty()) {
                            filter.setSelectedMinimumValue(filter.getMinimumValue());
                        }
                        if (filter.getSelectedMaximumValue() == null || filter.getSelectedMaximumValue().isEmpty()) {
                            filter.setSelectedMaximumValue(filter.getMaximumValue());
                        }

                        txtMinValue.setText(filter.getSelectedMinimumValue());
                        txtMaxValue.setText(filter.getSelectedMinimumValue());

                        rangeSeekBar.setMinValue((float) Math.floor(Double.parseDouble(filter.getMinimumValue())));
                        rangeSeekBar.setMaxValue((float) Math.ceil(Double.parseDouble(filter.getMaximumValue())));
                        rangeSeekBar.setMinStartValue((float) Math.floor(Double.parseDouble(filter.getSelectedMinimumValue()))).setMaxStartValue((float) Math.ceil(Double.parseDouble(filter.getSelectedMaximumValue()))).apply();

                        rangeSeekBar.setOnRangeSeekbarChangeListener(new OnRangeSeekbarChangeListener() {
                            @Override
                            public void valueChanged(Number min, Number max) {
                                txtMinValue.setText(String.valueOf(min));
                                txtMaxValue.setText(String.valueOf(max));
                            }
                        });

                    } else {
                        layoutPriceRange.setVisibility(View.GONE);
                    }


                    if (filter.getAttributeModelList().size() == 0) {
                        recyclerViewAttribute.setVisibility(View.GONE);
                    } else {
                        recyclerViewAttribute.setVisibility(View.VISIBLE);
                        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(this);
                        linearLayoutManager1.setOrientation(RecyclerView.VERTICAL);
                        recyclerViewAttribute.setLayoutManager(linearLayoutManager1);
                        AttributeListAdapter attributeListAdapter = new AttributeListAdapter(SubCategoryRelatedActivityExample.this, filter.getAttributeModelList(), null, new ArrayList<Integer>(), null);
                        recyclerViewAttribute.setAdapter(attributeListAdapter);
                    }

                    if (filter.getSpecificationModelList().size() == 0) {
                        recyclerViewForSpecificationAttribute.setVisibility(View.GONE);
                    } else {
                        specificationForFilterAdapter = new SpecificationForFilterAdapter(context, filter.getSpecificationModelList());
                        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(this);
                        linearLayoutManager1.setOrientation(RecyclerView.VERTICAL);
                        recyclerViewForSpecificationAttribute.setLayoutManager(linearLayoutManager1);
                        recyclerViewForSpecificationAttribute.setAdapter(specificationForFilterAdapter);
                    }

                    if (filter.getManufacturerModelList().size() > 0) {
                        txtListName.setVisibility(View.VISIBLE);
                        txtSelectedAll.setVisibility(View.VISIBLE);
                        recyclerViewForBrands.setVisibility(View.VISIBLE);
                        txtListName.setText("Brands");
                        filterCategoryListAdapter = new FilterCategoryListAdapter(context, new ArrayList<CategoryModel>(), filter.getManufacturerModelList());
                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
                        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
                        recyclerViewForBrands.setLayoutManager(linearLayoutManager);
                        recyclerViewForBrands.setAdapter(filterCategoryListAdapter);


                        txtSelectedAll.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                filterCategoryListAdapter.selectAll();
                            }
                        });
                    } else {
                        txtListName.setVisibility(View.GONE);
                        txtSelectedAll.setVisibility(View.GONE);
                        recyclerViewForBrands.setVisibility(View.GONE);
                    }

                    layoutMain.setVisibility(View.GONE);
                    toolbar.setVisibility(View.GONE);
                    appBar.setVisibility(View.GONE);
                    ll_filter.setVisibility(View.VISIBLE);
                }
            }
        }
    }
}
