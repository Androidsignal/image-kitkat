package com.testDemo.helper;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.testDemo.activites.SignUpActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by hp on 24/01/17.
 */

public class JSONHelper extends AsyncTask<Void, Void, String> {


    Context context;
    String myUrl;
    ProgressDialog progressDialog;
    OnAsyncLoader onAsyncLoader;
    HashMap<String, String> hashMap;
    JSONObject hashMapWithJson;
    boolean isProgressVisible;


    public JSONHelper(Context context, String url, HashMap<String, String> hashMap, OnAsyncLoader onAsynckLoader, boolean isProgressVisible) {
        this.context = context;
        myUrl = url;
        this.onAsyncLoader = onAsynckLoader;
        this.hashMap = hashMap;
        this.isProgressVisible = isProgressVisible;
    }

    public JSONHelper(Context context, String url, HashMap<String, String> hashMap, OnAsyncLoader onAsynckLoader, boolean isProgressVisible, JSONObject jsonObj) {
        this.context = context;
        myUrl = url;
        this.onAsyncLoader = onAsynckLoader;
        this.hashMap = hashMap;
        this.isProgressVisible = isProgressVisible;
        this.hashMapWithJson = jsonObj;
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        if (isProgressVisible) {
            progressDialog = new ProgressDialog(context);
            progressDialog.setMessage("Please wait a moment");
            progressDialog.show();
        }
    }

    @Override
    protected String doInBackground(Void... params) {
        String result = "";
        try {
            URL url = new URL(myUrl);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

            if (hashMap != null) {
                httpURLConnection.setReadTimeout(20000);
                httpURLConnection.setConnectTimeout(20000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.setDoOutput(true);

                OutputStream os = httpURLConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(hashMap));

                writer.flush();
                writer.close();
                os.close();
            }
            if (hashMapWithJson != null) {
                httpURLConnection.setReadTimeout(20000);
                httpURLConnection.setConnectTimeout(20000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.setRequestProperty("Content-Type", "application/json");
                httpURLConnection.setRequestProperty("Accept", "application/json");

                DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
                wr.writeBytes(hashMapWithJson.toString());

        /*OutputStream os = httpURLConnection.getOutputStream();
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
        writer.write(hashMapWithJson.toString());*/
//        writer.write(getPostDataString(hashMap));

                wr.flush();
                wr.close();
//        os.close();
            }
            if (httpURLConnection.getResponseCode() == 200) {
                InputStreamReader inputStreamReader = new InputStreamReader(httpURLConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    result += line;
                }
            }
            httpURLConnection.disconnect();
        } catch (MalformedURLException e) {
            Log.e("result", "Error = " + e.toString());
            e.printStackTrace();
        } catch (IOException e) {
            Log.e("result", "Error = " + e.toString());
            e.printStackTrace();
        }
        return result;

    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if (isProgressVisible) {
            progressDialog.dismiss();
        }
        try {
            onAsyncLoader.OnResult(s);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }
        Log.e("url", result.toString());
        return result.toString();
    }

}