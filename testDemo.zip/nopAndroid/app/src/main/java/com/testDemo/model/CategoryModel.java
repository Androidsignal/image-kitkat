package com.testDemo.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class CategoryModel implements Serializable {
    String id;
    String name;
    String image;
    String parentCategoryId;
    boolean isSelected;

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }


    @Override
    public String toString() {
        return "CategoryModel{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", image='" + image + '\'' +
                ", parentCategoryId='" + parentCategoryId + '\'' +
                '}';
    }


    public String getParentCategoryId() {
        return parentCategoryId;
    }

    public void setParentCategoryId(String parentCategoryId) {
        this.parentCategoryId = parentCategoryId;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void parse(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("name") && !jsonObject.isNull("name") && !jsonObject.getString("name").isEmpty()) {
            name = jsonObject.getString("name");
        }
        if (jsonObject.has("id") && !jsonObject.isNull("id") && !jsonObject.getString("id").isEmpty()) {
            id = jsonObject.getString("id");
        }
        if (jsonObject.has("image") && !jsonObject.isNull("image")) {
            JSONObject imageJson = jsonObject.getJSONObject("image");
            if (imageJson.has("src") && !imageJson.isNull("src") && !imageJson.getString("src").isEmpty()) {
                image = imageJson.getString("src");
            }
        }
        if (jsonObject.has("parent_category_id") && !jsonObject.isNull("parent_category_id") && !jsonObject.getString("parent_category_id").isEmpty()) {
            parentCategoryId = jsonObject.getString("parent_category_id");
        }
    }

    public void parserForSubCategory(JSONObject jsonObject) throws JSONException {

        if (jsonObject.has("name") && !jsonObject.isNull("name") && !jsonObject.getString("name").isEmpty()) {
            name = jsonObject.getString("name");
        }
        if (jsonObject.has("id") && !jsonObject.isNull("id") && !jsonObject.getString("id").isEmpty()) {
            id = jsonObject.getString("id");
        }
        if (jsonObject.has("parent_category_id") && !jsonObject.isNull("parent_category_id") && !jsonObject.getString("parent_category_id").isEmpty()) {
            parentCategoryId = jsonObject.getString("parent_category_id");
        }

        if (jsonObject.has("images") && !jsonObject.isNull("images")) {
            JSONArray jsonArray = jsonObject.getJSONArray("images");
            if (jsonArray.length() > 0) {
                JSONObject obj = jsonArray.getJSONObject(0);
                if (obj.has("src") && !obj.isNull("src")) {
                    image = obj.getString("src");
                }
            }

        }


    }
}
