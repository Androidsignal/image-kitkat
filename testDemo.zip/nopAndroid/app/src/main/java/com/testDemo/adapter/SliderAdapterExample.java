package com.testDemo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.testDemo.R;
import com.testDemo.model.ImageListModel;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.ArrayList;

import static com.smarteist.autoimageslider.IndicatorView.utils.DensityUtils.pxToDp;

public class SliderAdapterExample extends SliderViewAdapter<SliderAdapterExample.SliderAdapterVH> {

    private Context context;
    private ArrayList<String> imagesList;
    private ArrayList<ImageListModel> imageModelList;

    public SliderAdapterExample(Context context, ArrayList<String> imagesList) {
        this.context = context;
        this.imagesList = imagesList;
    }

    public SliderAdapterExample(Context context, ArrayList<String> imagesList, ArrayList<ImageListModel> imageModelList) {
        this.context = context;
        this.imagesList = imagesList;
        this.imageModelList = imageModelList;
    }

    @Override
    public SliderAdapterVH onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_slider_layout_item, null);
        return new SliderAdapterVH(inflate);
    }

    @Override
    public void onBindViewHolder(final SliderAdapterVH viewHolder, int position) {
        if(imageModelList != null && imageModelList.size() > 0){
            Glide.with(viewHolder.itemView).load(imageModelList.get(position).getUrl()).placeholder(R.drawable.placeholder).error(R.drawable.noimage).into(viewHolder.imageViewBackground);
        }else {
            Glide.with(viewHolder.itemView).load(imagesList.get(position)).placeholder(R.drawable.placeholder).error(R.drawable.noimage).into(viewHolder.imageViewBackground);
        }
    }

    @Override
    public int getCount() {
        //slider view count could be dynamic size
        if(imageModelList != null) {
            return imageModelList.size();
        }
        return imagesList.size();
    }

    class SliderAdapterVH extends SliderViewAdapter.ViewHolder {

        View itemView;
        ImageView imageViewBackground;
        TextView textViewDescription;

        public SliderAdapterVH(View itemView) {
            super(itemView);
            imageViewBackground = (ImageView)itemView.findViewById(R.id.iv_auto_image_slider);
//            textViewDescription = itemView.findViewById(R.id.tv_auto_image_slider);
            this.itemView = itemView;
        }
    }
}