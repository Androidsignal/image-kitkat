package com.testDemo.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.testDemo.R;

import java.util.ArrayList;


public class CategoryTitleListAdapter extends RecyclerView.Adapter<CategoryTitleListAdapter.ViewHolder> {
    Context context;
    public ArrayList<String> mData;
    int row_index;

    public CategoryTitleListAdapter(Context context, ArrayList<String> mData) {
        this.context = context;
        this.mData = mData;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.category_iteam, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.txtCategoryName.setText(mData.get(position));
        holder.tv_category.setText(mData.get(position));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                row_index = position;
                notifyDataSetChanged();
            }
        });

        if (row_index == position) {
            holder.cardView.setVisibility(View.VISIBLE);
            holder.tv_category.setVisibility(View.GONE);
            holder.txtCategoryName.setTextColor(ContextCompat.getColor(context, R.color.white));
        } else {
            holder.cardView.setVisibility(View.GONE);
            holder.tv_category.setVisibility(View.VISIBLE);
            holder.txtCategoryName.setTextColor(Color.parseColor("#9C9CA0"));
        }

    }


    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtCategoryName, tv_category;
        CardView cardView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            txtCategoryName = (TextView) itemView.findViewById(R.id.tv_categoryTitle);
            tv_category = (TextView) itemView.findViewById(R.id.tv_category);
            cardView = (CardView) itemView.findViewById(R.id.cardView);
        }
    }


}