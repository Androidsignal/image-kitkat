package com.testDemo.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.testDemo.R;
import com.testDemo.activites.ShippingAddressesActivity;
import com.testDemo.model.AddressModel;

import org.json.JSONException;

import java.util.ArrayList;

public class SelectAddressAdapter extends RecyclerView.Adapter<SelectAddressAdapter.ViewHolder> {
    Context context;
    ArrayList<AddressModel> designerCollection;
    int selectedPosition = 0;

    public SelectAddressAdapter(Context context, ArrayList<AddressModel> designerCollection) {
        this.context = context;
        this.designerCollection = designerCollection;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.select_address_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final AddressModel myListData = designerCollection.get(position);
        if(myListData != null) {

            if (myListData.getAddressUserName() != null && !myListData.getAddressUserName().isEmpty()) {
                holder.tv_address_user_name.setVisibility(View.VISIBLE);
                holder.tv_address_user_name.setText(myListData.getAddressUserName());
            }

            if (myListData.getAddressUserEmail() != null && !myListData.getAddressUserEmail().isEmpty()) {
                holder.tv_address_user_email.setVisibility(View.VISIBLE);
                holder.tv_address_user_email.setText(myListData.getAddressUserEmail());
            }
            if (myListData.isPhoneEnabled()) {
                if (myListData.getAddressUserPhoneNumber() != null && !myListData.getAddressUserPhoneNumber().isEmpty()) {
                    holder.tv_address_user_phone.setVisibility(View.VISIBLE);
                    holder.tv_address_user_phone.setText(myListData.getAddressUserPhoneNumber());
                }
            }

            if (myListData.isCityEnabled()) {
                if ( myListData.getAddressUserCity() != null && !myListData.getAddressUserCity().isEmpty()) {
                    holder.tv_address_user_city.setVisibility(View.VISIBLE);
                    holder.tv_address_user_city.setText(myListData.getAddressUserCity());
                }
            }

            if (myListData.getAddressUserCountry() != null && !myListData.getAddressUserCountry().isEmpty()) {
                holder.tv_address_user_country.setVisibility(View.VISIBLE);
                holder.tv_address_user_country.setText(myListData.getAddressUserCountry());
            }
            if (myListData.isCountyEnabled()) {
                if (myListData.getAddressUserCounty() != null && !myListData.getAddressUserCounty().isEmpty()) {
                    holder.tv_address_user_county.setVisibility(View.VISIBLE);
                    holder.tv_address_user_county.setText(myListData.getAddressUserCounty());
                }
            }

            if (myListData.getAddressUserState() != null && !myListData.getAddressUserState().isEmpty()) {
                holder.tv_address_user_state.setVisibility(View.VISIBLE);
                holder.tv_address_user_state.setText(myListData.getAddressUserState());
            }

            String address = "";
            String address2 = "";
            if(myListData.getAddressUserAddress1() != null) {
                address = myListData.getAddressUserAddress1();
            }
            if(myListData.getAddressUserAddress2() != null) {
                address2 = myListData.getAddressUserAddress2();
            }


            if (myListData.isZipPostalCodeEnabled()) {
                holder.tv_address_user_address1.setText(address + "," + address2 + "," + myListData.getAddressUserPinCode());
            }

            if (myListData.getFormattedCustomAddressAttributes() != null) {
                if (!myListData.getFormattedCustomAddressAttributes().isEmpty()) {
                    holder.addressAttribute.setVisibility(View.VISIBLE);
                    holder.addressAttribute.setText(Html.fromHtml(myListData.getFormattedCustomAddressAttributes()));
                }
            }

            if(selectedPosition == position){
                holder.cardView.setCardBackgroundColor(context.getResources().getColor(R.color.icon_color));
            }else{
                holder.cardView.setCardBackgroundColor(context.getResources().getColor(android.R.color.transparent));
            }

            holder.cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedPosition = position;
                    notifyDataSetChanged();
                }
            });
        }

    }

    public int getSelectedPosition(){
        return selectedPosition;
    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_address_user_name, tv_address_user_email, tv_address_user_phone, tv_address_user_address1, tv_address_user_city, tv_address_user_country, addressAttribute;
        TextView tv_address_user_county;
        TextView tv_address_user_state;
        CardView cardView;

        public ViewHolder(View itemView) {
            super(itemView);

            this.setIsRecyclable(false);

            tv_address_user_name = (TextView) itemView.findViewById(R.id.tv_address_user_name);
            tv_address_user_email = (TextView) itemView.findViewById(R.id.tv_address_user_email);
            tv_address_user_phone = (TextView) itemView.findViewById(R.id.tv_address_user_phone);
            tv_address_user_address1 = (TextView) itemView.findViewById(R.id.tv_address_user_address1);
            tv_address_user_city = (TextView) itemView.findViewById(R.id.tv_address_user_city);
            tv_address_user_country = (TextView) itemView.findViewById(R.id.tv_address_user_country);
            addressAttribute = itemView.findViewById(R.id.addressAttribute);
            tv_address_user_county = itemView.findViewById(R.id.tv_address_user_county);
            tv_address_user_state = itemView.findViewById(R.id.tv_address_user_state);
            cardView = itemView.findViewById(R.id.cardView);

        }
    }
}