package com.testDemo.model.AddressModels;

import android.os.Parcel;
import android.os.Parcelable;

import com.testDemo.model.AttributeModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class AddressAttributeModel implements Parcelable {

    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String company;
    private String countryName;
    private String countyName;
    private String stateProvinceName;
    private String city;
    private String addressLine1;
    private String addressLine2;
    private String zipPostalCode;
    private String phoneNumber;
    private int countryId;
    private int stateId;

    private String faxNumber;
    private boolean isCompanyEnable = false;
    private boolean isCountryEnabled = false;
    private boolean isStateProvinceEnabled = false;
    private boolean isCountryRequire = false;
    private boolean isCityEnabled = false;
    private boolean isAddressLineEnabled = false;
    private boolean isAddressLine2Enabled = false;
    private boolean isZipPostalCodeEnabled = false;
    private boolean isPhoneEnabled = false;

    private boolean isFaxEnabled = false;
    private boolean isCompanyRequired = false;
    private boolean isCityRequired = false;
    private boolean isAddressLineRequired = false;
    private boolean isAddressLine2Required = false;
    private boolean isZipPostalCodeRequired = false;
    private boolean isPhoneRequired = false;
    private boolean isFaxRequired = false;
    boolean isCountyEnabled;
    boolean isCountyRequired;

    private ArrayList<CountryListModel> countryModelList = new ArrayList<>();
    private ArrayList<StateListModel> stateModelList = new ArrayList<>();
    private ArrayList<AttributeModel> attributeModelList = new ArrayList<>();

    CountryListModel selectedCountry ;
    StateListModel selectedState ;

    public AddressAttributeModel() {
    }

    protected AddressAttributeModel(Parcel in) {
        id = in.readInt();
        firstName = in.readString();
        lastName = in.readString();
        email = in.readString();
        company = in.readString();
        countryName = in.readString();
        countyName = in.readString();
        stateProvinceName = in.readString();
        city = in.readString();
        addressLine1 = in.readString();
        addressLine2 = in.readString();
        zipPostalCode = in.readString();
        phoneNumber = in.readString();
        countryId = in.readInt();
        stateId = in.readInt();
        faxNumber = in.readString();
        isCompanyEnable = in.readByte() != 0;
        isCountryEnabled = in.readByte() != 0;
        isStateProvinceEnabled = in.readByte() != 0;
        isCountryRequire = in.readByte() != 0;
        isCityEnabled = in.readByte() != 0;
        isAddressLineEnabled = in.readByte() != 0;
        isAddressLine2Enabled = in.readByte() != 0;
        isZipPostalCodeEnabled = in.readByte() != 0;
        isPhoneEnabled = in.readByte() != 0;
        isFaxEnabled = in.readByte() != 0;
        isCompanyRequired = in.readByte() != 0;
        isCityRequired = in.readByte() != 0;
        isAddressLineRequired = in.readByte() != 0;
        isAddressLine2Required = in.readByte() != 0;
        isZipPostalCodeRequired = in.readByte() != 0;
        isPhoneRequired = in.readByte() != 0;
        isFaxRequired = in.readByte() != 0;
        isCountyEnabled = in.readByte() != 0;
        isCountyRequired = in.readByte() != 0;
    }

    public static final Creator<AddressAttributeModel> CREATOR = new Creator<AddressAttributeModel>() {
        @Override
        public AddressAttributeModel createFromParcel(Parcel in) {
            return new AddressAttributeModel(in);
        }

        @Override
        public AddressAttributeModel[] newArray(int size) {
            return new AddressAttributeModel[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getStateProvinceName() {
        return stateProvinceName;
    }

    public void setStateProvinceName(String stateProvinceName) {
        this.stateProvinceName = stateProvinceName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getZipPostalCode() {
        return zipPostalCode;
    }

    public void setZipPostalCode(String zipPostalCode) {
        this.zipPostalCode = zipPostalCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getCountryId() {
        return countryId;
    }

    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    public int getStateId() {
        return stateId;
    }

    public void setStateId(int stateId) {
        this.stateId = stateId;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public boolean isCompanyEnable() {
        return isCompanyEnable;
    }

    public void setCompanyEnable(boolean companyEnable) {
        isCompanyEnable = companyEnable;
    }

    public boolean isCountryEnabled() {
        return isCountryEnabled;
    }

    public void setCountryEnabled(boolean countryEnabled) {
        isCountryEnabled = countryEnabled;
    }

    public boolean isStateProvinceEnabled() {
        return isStateProvinceEnabled;
    }

    public void setStateProvinceEnabled(boolean stateProvinceEnabled) {
        isStateProvinceEnabled = stateProvinceEnabled;
    }

    public boolean isCountryRequire() {
        return isCountryRequire;
    }

    public void setCountryRequire(boolean countryRequire) {
        isCountryRequire = countryRequire;
    }

    public boolean isCityEnabled() {
        return isCityEnabled;
    }

    public void setCityEnabled(boolean cityEnabled) {
        isCityEnabled = cityEnabled;
    }

    public boolean isAddressLineEnabled() {
        return isAddressLineEnabled;
    }

    public void setAddressLineEnabled(boolean addressLineEnabled) {
        isAddressLineEnabled = addressLineEnabled;
    }

    public boolean isAddressLine2Enabled() {
        return isAddressLine2Enabled;
    }

    public void setAddressLine2Enabled(boolean addressLine2Enabled) {
        isAddressLine2Enabled = addressLine2Enabled;
    }

    public boolean isZipPostalCodeEnabled() {
        return isZipPostalCodeEnabled;
    }

    public void setZipPostalCodeEnabled(boolean zipPostalCodeEnabled) {
        isZipPostalCodeEnabled = zipPostalCodeEnabled;
    }

    public boolean isPhoneEnabled() {
        return isPhoneEnabled;
    }

    public void setPhoneEnabled(boolean phoneEnabled) {
        isPhoneEnabled = phoneEnabled;
    }

    public boolean isFaxEnabled() {
        return isFaxEnabled;
    }

    public void setFaxEnabled(boolean faxEnabled) {
        isFaxEnabled = faxEnabled;
    }

    public boolean isCompanyRequired() {
        return isCompanyRequired;
    }

    public void setCompanyRequired(boolean companyRequired) {
        isCompanyRequired = companyRequired;
    }

    public boolean isCityRequired() {
        return isCityRequired;
    }

    public void setCityRequired(boolean cityRequired) {
        isCityRequired = cityRequired;
    }

    public boolean isAddressLineRequired() {
        return isAddressLineRequired;
    }

    public void setAddressLineRequired(boolean addressLineRequired) {
        isAddressLineRequired = addressLineRequired;
    }

    public boolean isAddressLine2Required() {
        return isAddressLine2Required;
    }

    public void setAddressLine2Required(boolean addressLine2Required) {
        isAddressLine2Required = addressLine2Required;
    }

    public boolean isZipPostalCodeRequired() {
        return isZipPostalCodeRequired;
    }

    public void setZipPostalCodeRequired(boolean zipPostalCodeRequired) {
        isZipPostalCodeRequired = zipPostalCodeRequired;
    }

    public boolean isPhoneRequired() {
        return isPhoneRequired;
    }

    public void setPhoneRequired(boolean phoneRequired) {
        isPhoneRequired = phoneRequired;
    }

    public boolean isFaxRequired() {
        return isFaxRequired;
    }

    public void setFaxRequired(boolean faxRequired) {
        isFaxRequired = faxRequired;
    }

    public ArrayList<CountryListModel> getCountryModelList() {
        return countryModelList;
    }

    public void setCountryModelList(ArrayList<CountryListModel> countryModelList) {
        this.countryModelList = countryModelList;
    }

    public ArrayList<StateListModel> getStateModelList() {
        return stateModelList;
    }

    public void setStateModelList(ArrayList<StateListModel> stateModelList) {
        this.stateModelList = stateModelList;
    }

    public ArrayList<AttributeModel> getAttributeModelList() {
        return attributeModelList;
    }

    public void setAttributeModelList(ArrayList<AttributeModel> attributeModelList) {
        this.attributeModelList = attributeModelList;
    }

    public CountryListModel getSelectedCountry() {
        return selectedCountry;
    }

    public void setSelectedCountry(CountryListModel selectedCountry) {
        this.selectedCountry = selectedCountry;
    }

    public StateListModel getSelectedState() {
        return selectedState;
    }

    public void setSelectedState(StateListModel selectedState) {
        this.selectedState = selectedState;
    }

    public boolean isCountyEnabled() {
        return isCountyEnabled;
    }

    public void setCountyEnabled(boolean countyEnabled) {
        isCountyEnabled = countyEnabled;
    }

    public boolean isCountyRequired() {
        return isCountyRequired;
    }

    public void setCountyRequired(boolean countyRequired) {
        isCountyRequired = countyRequired;
    }

    public String getCountyName() {
        return countyName;
    }

    public void setCountyName(String countyName) {
        this.countyName = countyName;
    }

    @Override
    public String toString() {
        return "AddressAttributeModel{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", company='" + company + '\'' +
                ", countryName='" + countryName + '\'' +
                ", stateProvinceName='" + stateProvinceName + '\'' +
                ", city='" + city + '\'' +
                ", addressLine1='" + addressLine1 + '\'' +
                ", addressLine2='" + addressLine2 + '\'' +
                ", zipPostalCode='" + zipPostalCode + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", countryId=" + countryId +
                ", stateId=" + stateId +
                ", faxNumber='" + faxNumber + '\'' +
                ", isCompanyEnable=" + isCompanyEnable +
                ", isCountryEnabled=" + isCountryEnabled +
                ", isStateProvinceEnabled=" + isStateProvinceEnabled +
                ", isCountryRequire=" + isCountryRequire +
                ", isCityEnabled=" + isCityEnabled +
                ", isAddressLineEnabled=" + isAddressLineEnabled +
                ", isAddressLine2Enabled=" + isAddressLine2Enabled +
                ", isZipPostalCodeEnabled=" + isZipPostalCodeEnabled +
                ", isPhoneEnabled=" + isPhoneEnabled +
                ", isFaxEnabled=" + isFaxEnabled +
                ", isCompanyRequired=" + isCompanyRequired +
                ", isCityRequired=" + isCityRequired +
                ", isAddressLineRequired=" + isAddressLineRequired +
                ", isAddressLine2Required=" + isAddressLine2Required +
                ", isZipPostalCodeRequired=" + isZipPostalCodeRequired +
                ", isPhoneRequired=" + isPhoneRequired +
                ", isFaxRequired=" + isFaxRequired +
                ", countryModelList=" + countryModelList +
                ", stateModelList=" + stateModelList +
                ", attributeModelList=" + attributeModelList +
                '}';
    }

    public void parse(JSONObject object) throws JSONException {
        if (object != null) {
            if (checkForNull("FirstName", object)) {
                firstName = object.getString("FirstName");
            }
            if (checkForNull("LastName", object)) {
                lastName = object.getString("LastName");
            }
            if (checkForNull("Email", object)) {
                email = object.getString("Email");
            }
            if (checkForNull("CompanyEnabled", object)) {
                isCompanyEnable = object.getBoolean("CompanyEnabled");
            }

            if (checkForNull("CompanyRequired", object)) {
                isCompanyRequired = object.getBoolean("CompanyRequired");
            }
            if (checkForNull("Company", object)) {
                company = object.getString("Company");
            }

            if (checkForNull("County", object)) {
                countyName = object.getString("County");
            }

            if (checkForNull("CountryEnabled", object)) {
                isCountryEnabled = object.getBoolean("CountryEnabled");
            }

            if (checkForNull("CountyEnabled", object)) {
                isCountyEnabled = object.getBoolean("CountyEnabled");
            }
            if (checkForNull("CountyRequired", object)) {
                isCountyRequired = object.getBoolean("CountyRequired");
            }

            if (checkForNull("CountryId", object)) {
                countryId = object.getInt("CountryId");
            }
            if (checkForNull("CountryName", object)) {
                countryName = object.getString("CountryName");
            }
            if (checkForNull("StateProvinceEnabled", object)) {
                isStateProvinceEnabled = object.getBoolean("StateProvinceEnabled");
            }
            if (checkForNull("StateProvinceId", object)) {
                stateId = object.getInt("StateProvinceId");
            }
            if (checkForNull("StateProvinceName", object)) {
                stateProvinceName = object.getString("StateProvinceName");
            }

            if (checkForNull("CityEnabled", object)) {
                isCityEnabled = object.getBoolean("CityEnabled");
            }
            if (checkForNull("CityRequired", object)) {
                isCityRequired = object.getBoolean("CityRequired");
            }
            if (checkForNull("CountyEnabled", object)) {
                isCountyEnabled = object.getBoolean("CityEnabled");
            }
            if (checkForNull("CityRequired", object)) {
                isCityRequired = object.getBoolean("CityRequired");
            }
            if (checkForNull("City", object)) {
                city = object.getString("City");
            }
            if (checkForNull("StreetAddressEnabled", object)) {
                isAddressLineEnabled = object.getBoolean("StreetAddressEnabled");
            }
            if (checkForNull("StreetAddressRequired", object)) {
                isAddressLineRequired = object.getBoolean("StreetAddressRequired");
            }
            if (checkForNull("Address1", object)) {
                addressLine1 = object.getString("Address1");
            }
            if (checkForNull("StreetAddress2Enabled", object)) {
                isAddressLine2Enabled = object.getBoolean("StreetAddress2Enabled");
            }
            if (checkForNull("StreetAddress2Required", object)) {
                isAddressLine2Required = object.getBoolean("StreetAddress2Required");
            }
            if (checkForNull("Address2", object)) {
                addressLine2 = object.getString("Address2");
            }
            if (checkForNull("ZipPostalCodeEnabled", object)) {
                isZipPostalCodeEnabled = object.getBoolean("ZipPostalCodeEnabled");
            }
            if (checkForNull("ZipPostalCodeRequired", object)) {
                isZipPostalCodeRequired = object.getBoolean("ZipPostalCodeRequired");
            }
            if (checkForNull("ZipPostalCode", object)) {
                zipPostalCode = object.getString("ZipPostalCode");
            }
            if (checkForNull("PhoneEnabled", object)) {
                isPhoneEnabled = object.getBoolean("PhoneEnabled");
            }
            if (checkForNull("PhoneRequired", object)) {
                isPhoneRequired = object.getBoolean("PhoneRequired");
            }
            if (checkForNull("PhoneNumber", object)) {
                phoneNumber = object.getString("PhoneNumber");
            }
            if (checkForNull("FaxEnabled", object)) {
                isFaxEnabled = object.getBoolean("FaxEnabled");
            }
            if (checkForNull("FaxRequired", object)) {
                isFaxRequired = object.getBoolean("FaxRequired");
            }
            if (checkForNull("FaxNumber", object)) {
                faxNumber = object.getString("FaxNumber");
            }
            if (checkForNull("AvailableCountries", object)) {
                JSONArray jsonArray = object.getJSONArray("AvailableCountries");
                countryModelList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    CountryListModel model = new CountryListModel();
                    model.parse(jsonObject);
                    countryModelList.add(model);
                    if(String.valueOf(countryId).equals(model.getStrValue())){
                        selectedCountry = model;
                    }
                }
            }

            if (checkForNull("AvailableStates", object)) {
                JSONArray jsonArray = object.getJSONArray("AvailableStates");
                stateModelList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    StateListModel model = new StateListModel();
                    model.parse(jsonObject);
                    stateModelList.add(model);
                    if(String.valueOf(stateId).equals(model.getStrValue())){
                        selectedState = model;
                    }
                }
            }

            if (checkForNull("CustomAddressAttributes", object)) {
                JSONArray jsonArray = object.getJSONArray("CustomAddressAttributes");
                attributeModelList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    AttributeModel model = new AttributeModel();
                    model.parseForAddress(jsonObject);
                    attributeModelList.add(model);
                }
            }
        }
    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(firstName);
        dest.writeString(lastName);
        dest.writeString(email);
        dest.writeString(company);
        dest.writeString(countryName);
        dest.writeString(countyName);
        dest.writeString(stateProvinceName);
        dest.writeString(city);
        dest.writeString(addressLine1);
        dest.writeString(addressLine2);
        dest.writeString(zipPostalCode);
        dest.writeString(phoneNumber);
        dest.writeInt(countryId);
        dest.writeInt(stateId);
        dest.writeString(faxNumber);
        dest.writeByte((byte) (isCompanyEnable ? 1 : 0));
        dest.writeByte((byte) (isCountryEnabled ? 1 : 0));
        dest.writeByte((byte) (isStateProvinceEnabled ? 1 : 0));
        dest.writeByte((byte) (isCountryRequire ? 1 : 0));
        dest.writeByte((byte) (isCityEnabled ? 1 : 0));
        dest.writeByte((byte) (isAddressLineEnabled ? 1 : 0));
        dest.writeByte((byte) (isAddressLine2Enabled ? 1 : 0));
        dest.writeByte((byte) (isZipPostalCodeEnabled ? 1 : 0));
        dest.writeByte((byte) (isPhoneEnabled ? 1 : 0));
        dest.writeByte((byte) (isFaxEnabled ? 1 : 0));
        dest.writeByte((byte) (isCompanyRequired ? 1 : 0));
        dest.writeByte((byte) (isCityRequired ? 1 : 0));
        dest.writeByte((byte) (isAddressLineRequired ? 1 : 0));
        dest.writeByte((byte) (isAddressLine2Required ? 1 : 0));
        dest.writeByte((byte) (isZipPostalCodeRequired ? 1 : 0));
        dest.writeByte((byte) (isPhoneRequired ? 1 : 0));
        dest.writeByte((byte) (isFaxRequired ? 1 : 0));
        dest.writeByte((byte) (isCountyEnabled ? 1 : 0));
        dest.writeByte((byte) (isCountyRequired ? 1 : 0));
    }
}
