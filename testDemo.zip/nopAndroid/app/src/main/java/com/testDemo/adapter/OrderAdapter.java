package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.testDemo.R;
import com.testDemo.activites.OrderDetailActivity;
import com.testDemo.activites.ShippingAddressesActivity;
import com.testDemo.global.Constants;
import com.testDemo.model.AddressModel;
import com.testDemo.model.OrderModel;

import org.json.JSONException;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {
    Context context;
    ArrayList<OrderModel> designerCollection;


    public OrderAdapter(Context context, ArrayList<OrderModel> designerCollection) {
        this.context = context;
        this.designerCollection = designerCollection;


    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.order_iteam, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final OrderModel myListData = designerCollection.get(position);

        holder.tv_order_id.setText(myListData.getOrderId());
        holder.tv_order_date.setText(myListData.getOrderDate());
        holder.tv_order_status.setText(myListData.getOrderStatus());
        holder.tv_order_total.setText(myListData.getOrderTotal());

        holder.cv_onClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(context, OrderDetailActivity.class);
                intent.putExtra(Constants.ORDER_ID,myListData.getOrderId());
                context.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_order_id, tv_order_status, tv_order_date, tv_order_total;
        CardView cv_onClick;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            tv_order_id = (TextView) itemView.findViewById(R.id.tv_order_id);
            tv_order_status = (TextView) itemView.findViewById(R.id.tv_order_status);
            tv_order_date = (TextView) itemView.findViewById(R.id.tv_order_date);
            tv_order_total = (TextView) itemView.findViewById(R.id.tv_order_total);
            cv_onClick = (CardView) itemView.findViewById(R.id.cv_onClick);

        }
    }
}