package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.CartScreen;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.CustomSpinner;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

public class CartItemListAdapter extends RecyclerView.Adapter<CartItemListAdapter.ViewHolder> {
    Context context;
    ArrayList<ProductModel> designerCollection;
    ArrayAdapter<String> adapter;

    ListItemClickListener listItemClickListener;


    public CartItemListAdapter(Context context, ArrayList<ProductModel> designerCollection, ListItemClickListener listItemClickListener) {
        this.context = context;
        this.designerCollection = designerCollection;
        this.listItemClickListener = listItemClickListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.cart_item_list_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final ProductModel myListData = designerCollection.get(position);
        Glide.with(holder.itemView)
                .load(myListData.getProductImage())
                .into(holder.iv_product_image);
        holder.tv_product_price.setText(myListData.getProductPrice());
        holder.tv_product_name.setText(myListData.getProductName());

        if (myListData.getValues() != null && myListData.getValues().length > 0) {
            adapter = new ArrayAdapter<String>(context, R.layout.spinner_item_selected, myListData.getValues());
            holder.ll_spinner.setAdapter(adapter);
//            holder.ll_spinner.setSelection(Integer.parseInt(myListData.getItemQuantity()));
            if (myListData.getItemQuantity() != null) {
                int spinnerPosition = adapter.getPosition(myListData.getItemQuantity());
                holder.ll_spinner.setSelection(spinnerPosition);
            }
        } else {
            holder.img_dropDown.setVisibility(View.GONE);
            holder.ll_spinner.setVisibility(View.GONE);
            holder.txt_quantity.setVisibility(View.VISIBLE);
            holder.txt_quantity.setText(myListData.getItemQuantity());
        }
        if (myListData.getAttributeString() != null && !myListData.getAttributeString().isEmpty()) {
            holder.txtAttribute.setVisibility(View.VISIBLE);
            holder.txtAttribute.setText(Html.fromHtml(myListData.getAttributeString()));
        }

        holder.ll_spinner.setSpinnerEventsListener(new CustomSpinner.OnSpinnerEventsListener() {
            public void onSpinnerOpened() {
                holder.ll_spinner.setSelected(true);
            }

            public void onSpinnerClosed() {
                holder.ll_spinner.setSelected(false);
                Log.e("spinner", "onSpinnerClosed: " + holder.ll_spinner.getSelectedItem().toString());
                listItemClickListener.onItemClick(position, holder.ll_spinner.getSelectedItem().toString());
            }
        });

        holder.ll_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, ProductDetailActivity.class);
                if (designerCollection.size() > 0 && designerCollection.get(position) != null && designerCollection.get(position).getProductId() != null) {
                    i.putExtra(Constants.INTENT_PRODUCT_ID, designerCollection.get(position).getProductId().toString());
                }
                context.startActivity(i);
            }
        });
    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_product_image, img_dropDown;
        TextView tv_product_name, tv_product_price, txt_quantity;
        CustomSpinner ll_spinner;
        LinearLayout ll_click;

        TextView txtAttribute;
//        FrameLayout ll_spinner_layout;


        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            iv_product_image = (ImageView) itemView.findViewById(R.id.iv_product_image);
            img_dropDown = (ImageView) itemView.findViewById(R.id.img_dropDown);
            tv_product_name = (TextView) itemView.findViewById(R.id.tv_product_name);
            tv_product_price = (TextView) itemView.findViewById(R.id.tv_product_price);
            txt_quantity = (TextView) itemView.findViewById(R.id.txt_quantity);
            ll_spinner = itemView.findViewById(R.id.ll_spinner);
            ll_click = itemView.findViewById(R.id.ll_click);
            txtAttribute = itemView.findViewById(R.id.txtAttribute);
//            ll_spinner_layout = itemView.findViewById(R.id.ll_spinner_layout);

        }
    }

    public void removeItem(int position) {
        designerCollection.remove(position);
        notifyItemRemoved(position);
//        notifyItemChanged(position);
    }

    public void restoreItem(ProductModel item, int position) {
        designerCollection.add(position, item);
        notifyItemInserted(position);
    }

    public ArrayList<ProductModel> getData() {
        return designerCollection;
    }


}

