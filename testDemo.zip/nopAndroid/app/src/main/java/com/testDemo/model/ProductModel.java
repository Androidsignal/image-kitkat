package com.testDemo.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProductModel implements Serializable {

    public boolean isProductinShoppingCart = false;
    boolean loadingForPaging = false;


    String productId;
    String shoppingId;
    String productName;
    String productPrice;
    String productImage;
    String itemQuantity;
    String size;
    String color;
    String totalAmount;
    String AllowQuantity;
    String subTotal;
    String Tax;
    String shipping;
    String[] values;
    String approved_rating_sum;
    String old_price;
    private ArrayList<AttributeModel> attributeModelArrayList = new ArrayList<>();

    String attributeString;

    @Override
    public String toString() {
        return "ProductModel{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", productPrice='" + productPrice + '\'' +
                ", productImage='" + productImage + '\'' +
                ", itemQuantity='" + itemQuantity + '\'' +
                ", size='" + size + '\'' +
                ", color='" + color + '\'' +
                ", totalAmount='" + totalAmount + '\'' +
                ", AllowQuantity='" + AllowQuantity + '\'' +
                ", subTotal='" + subTotal + '\'' +
                ", Tax='" + Tax + '\'' +
                ", shipping='" + shipping + '\'' +
                ", values=" + Arrays.toString(values) +
                '}';
    }


    public boolean isGetProductInShoppingCart() {
        return isProductinShoppingCart;
    }

    public void setProductInShoppingCart(boolean productinShoppingCart) {
        isProductinShoppingCart = productinShoppingCart;
    }

    public ArrayList<AttributeModel> getAttributeModelArrayList() {
        return attributeModelArrayList;
    }

    public void setAttributeModelArrayList(ArrayList<AttributeModel> attributeModelArrayList) {
        this.attributeModelArrayList = attributeModelArrayList;
    }

    public String getShoppingId() {
        return shoppingId;
    }

    public void setShoppingId(String shoppingId) {
        this.shoppingId = shoppingId;
    }

    public String getAttributeString() {
        return attributeString;
    }

    public void setAttributeString(String attributeString) {
        this.attributeString = attributeString;
    }

    public String getApproved_rating_sum() {
        return approved_rating_sum;
    }

    public void setApproved_rating_sum(String approved_rating_sum) {
        this.approved_rating_sum = approved_rating_sum;
    }

    public String getOld_price() {
        return old_price;
    }

    public void setOld_price(String old_price) {
        this.old_price = old_price;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(String itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String[] getValues() {
        return values;
    }

    public void setValues(String[] values) {
        this.values = values;
    }


    public String getAllowQuantity() {
        return AllowQuantity;
    }

    public void setAllowQuantity(String allowQuantity) {
        AllowQuantity = allowQuantity;
    }

    public String getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(String subTotal) {
        this.subTotal = subTotal;
    }

    public String getTax() {
        return Tax;
    }

    public void setTax(String tax) {
        Tax = tax;
    }

    public String getShipping() {
        return shipping;
    }

    public void setShipping(String shipping) {
        this.shipping = shipping;
    }

    public boolean isLoadingForPaging() {
        return loadingForPaging;
    }

    public void setLoadingForPaging(boolean loadingForPaging) {
        this.loadingForPaging = loadingForPaging;
    }

    public void parseForNewArrival(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("id") && !jsonObject.isNull("id")) {
            productId = jsonObject.getString("id");
        }
        if (jsonObject.has("IsProductinShoppingCart") && !jsonObject.isNull("IsProductinShoppingCart")) {
            isProductinShoppingCart = jsonObject.getBoolean("IsProductinShoppingCart");
        }
        if (jsonObject.has("name") && !jsonObject.isNull("name")) {
            productName = jsonObject.getString("name");
        }
        if (jsonObject.has("price") && !jsonObject.isNull("price")) {
            productPrice = jsonObject.getString("price");
        }
        if (jsonObject.has("order_minimum_quantity") && !jsonObject.isNull("order_minimum_quantity")) {
            itemQuantity = jsonObject.getString("order_minimum_quantity");
        }
        if (checkForNull("attributes", jsonObject)) {
            JSONArray attributes = jsonObject.getJSONArray("attributes");
            attributeModelArrayList = new ArrayList<>();
            for (int i = 0; i < attributes.length(); i++) {
                JSONObject jsonObject2 = attributes.getJSONObject(i);
                AttributeModel model = new AttributeModel();
                model.parse(jsonObject2);
                attributeModelArrayList.add(model);
            }
        }
        if (jsonObject.has("images") && !jsonObject.isNull("images")) {
            JSONArray jsonArray = jsonObject.getJSONArray("images");
            if (jsonArray.length() > 0) {
                JSONObject obj = jsonArray.getJSONObject(0);
                if (obj.has("src") && !obj.isNull("src")) {
                    productImage = obj.getString("src");
                }
            }

        }

    }

    public void parseForWhoAlsoBuy(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("id") && !jsonObject.isNull("id")) {
            productId = jsonObject.getString("id");
        }
        if (jsonObject.has("name") && !jsonObject.isNull("name")) {
            productName = jsonObject.getString("name");
        }
        if (jsonObject.has("price") && !jsonObject.isNull("price")) {
            productPrice = jsonObject.getString("price");
        }
        if (jsonObject.has("IsProductinShoppingCart") && !jsonObject.isNull("IsProductinShoppingCart")) {
            isProductinShoppingCart = jsonObject.getBoolean("IsProductinShoppingCart");
        }
        if (jsonObject.has("order_minimum_quantity") && !jsonObject.isNull("order_minimum_quantity")) {
            itemQuantity = jsonObject.getString("order_minimum_quantity");
        }
        if (jsonObject.has("images") && !jsonObject.isNull("images")) {
            JSONArray jsonArray = jsonObject.getJSONArray("images");
            if (jsonArray.length() > 0) {
                JSONObject obj = jsonArray.getJSONObject(0);
                if (obj.has("src") && !obj.isNull("src")) {
                    productImage = obj.getString("src");
                }
            }

        }

    }


    public void parseForRelatedProduct(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("id") && !jsonObject.isNull("id")) {
            productId = jsonObject.getString("id");
        }
        if (jsonObject.has("name") && !jsonObject.isNull("name")) {
            productName = jsonObject.getString("name");
        }
        if (jsonObject.has("IsProductinShoppingCart") && !jsonObject.isNull("IsProductinShoppingCart")) {
            isProductinShoppingCart = jsonObject.getBoolean("IsProductinShoppingCart");
        }
        if (jsonObject.has("price") && !jsonObject.isNull("price")) {
            productPrice = jsonObject.getString("price");
        }
        if (jsonObject.has("order_minimum_quantity") && !jsonObject.isNull("order_minimum_quantity")) {
            itemQuantity = jsonObject.getString("order_minimum_quantity");
        }
        if (jsonObject.has("images") && !jsonObject.isNull("images")) {
            JSONArray jsonArray = jsonObject.getJSONArray("images");
            if (jsonArray.length() > 0) {
                JSONObject obj = jsonArray.getJSONObject(0);
                if (obj.has("src") && !obj.isNull("src")) {
                    productImage = obj.getString("src");
                }
            }

        }

    }

    public void parseForWishList(JSONObject jsonObject) throws JSONException {
        if (checkForNull("ProductId",jsonObject)){
            productId = jsonObject.getString("ProductId");
        }
        if (checkForNull("ProductName",jsonObject)){
            productName = jsonObject.getString("ProductName");
        }
        if (checkForNull("Quantity",jsonObject)){
            itemQuantity = jsonObject.getString("Quantity");


        }
        if (checkForNull("SubTotal",jsonObject)){
            productPrice = jsonObject.getString("SubTotal");
        }
        if (checkForNull("Picture",jsonObject)){
            JSONObject jsonObject1 = jsonObject.getJSONObject("Picture");
            if (checkForNull("ImageUrl",jsonObject1)) {
                productImage = jsonObject1.getString("ImageUrl");
            }
        }
    }

    public void parseForCartItem(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("product_id") && !jsonObject.isNull("product_id")) {
            productId = jsonObject.getString("product_id");
        }
        if (jsonObject.has("id") && !jsonObject.isNull("id")) {
            shoppingId = jsonObject.getString("id");
        }
        if (jsonObject.has("quantity") && !jsonObject.isNull("quantity")) {
            itemQuantity = jsonObject.getString("quantity");
        }
        if (jsonObject.has("IsProductinShoppingCart") && !jsonObject.isNull("IsProductinShoppingCart")) {
            isProductinShoppingCart = jsonObject.getBoolean("IsProductinShoppingCart");
        }
        if (jsonObject.has("product") && !jsonObject.isNull("product")) {
            JSONObject obj = jsonObject.getJSONObject("product");

            if (obj.has("name") && !obj.isNull("name")) {
                productName = obj.getString("name");
            }
            if (obj.has("price") && !obj.isNull("price")) {
                productPrice = obj.getString("price");
            }

            if (obj.has("allowed_quantities") && !obj.isNull("allowed_quantities")) {
                AllowQuantity = obj.getString("allowed_quantities");
                values = AllowQuantity.split(",");
            }

            if (obj.has("images") && !obj.isNull("images")) {
                JSONArray array = obj.getJSONArray("images");
                if (array.length() > 0) {
                    JSONObject object = array.getJSONObject(0);
                    if (object.has("src") && !object.isNull("src")) {
                        productImage = object.getString("src");
                    }
                }

            }

        }

        if (jsonObject.has("SubTotal") && !jsonObject.isNull("SubTotal")) {
            subTotal = jsonObject.getString("SubTotal");
        }

        if (jsonObject.has("OrderTotal") && !jsonObject.isNull("OrderTotal")) {
            totalAmount = jsonObject.getString("OrderTotal");
        }

        if (jsonObject.has("Tax") && !jsonObject.isNull("Tax")) {
            Tax = jsonObject.getString("Tax");
        }

        if (jsonObject.has("Shipping") && !jsonObject.isNull("Shipping")) {
            shipping = jsonObject.getString("Shipping");
        }

        if (jsonObject.has("FormattedProductAttributes") && !jsonObject.isNull("FormattedProductAttributes")) {
            attributeString = jsonObject.getString("FormattedProductAttributes");
        }

    }

    public void parseForSearchResult(JSONObject jsonObject) throws JSONException
    {
        if (jsonObject.has("id") && !jsonObject.isNull("id")) {
            productId = jsonObject.getString("id");
        }
        if (jsonObject.has("name") && !jsonObject.isNull("name")) {
            productName = jsonObject.getString("name");
        }
        if (jsonObject.has("price") && !jsonObject.isNull("price")) {
            productPrice = jsonObject.getString("price");
        }
        if (jsonObject.has("images") && !jsonObject.isNull("images")) {
            JSONArray jsonArray = jsonObject.getJSONArray("images");
            if (jsonArray.length() > 0) {
                JSONObject obj = jsonArray.getJSONObject(0);
                if (obj.has("src") && !obj.isNull("src")) {
                    productImage = obj.getString("src");
                }
            }

        }
        if (jsonObject.has("old_price") && !jsonObject.isNull("old_price")) {
            old_price = jsonObject.getString("old_price");
        }
        if (jsonObject.has("approved_rating_sum") && !jsonObject.isNull("approved_rating_sum")) {
            approved_rating_sum = jsonObject.getString("approved_rating_sum");
        }


    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }


}


