package com.testDemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.testDemo.R;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.SpecificationForFilterModel;
import com.testDemo.model.SpecificationValueModel;

import java.util.ArrayList;

public class SpecificationForFilterAdapter extends RecyclerView.Adapter<SpecificationForFilterAdapter.ViewHolder> {
    Context context;
    ArrayList<SpecificationForFilterModel> arrayList = new ArrayList<>();

    public SpecificationForFilterAdapter(Context context, ArrayList<SpecificationForFilterModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.layout_specification_filter, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        SpecificationForFilterModel model = arrayList.get(position);
        if(model != null){
            if(model.getName() != null){
                holder.txtName.setText(model.getName());
            }
            if(model.getSpecificationValueModelList().size() > 0){
                boolean isGridLayout = false;
                SpecificationValueListAdapter adapter = new SpecificationValueListAdapter(context,model.getSpecificationValueModelList());
                for (int i = 0; i < model.getSpecificationValueModelList().size(); i++) {
                    SpecificationValueModel model1 = model.getSpecificationValueModelList().get(i);
                    if(model1.getColorCode() != null && !model1.getColorCode().isEmpty() && !model1.getColorCode().equals("null") &&!model1.getColorCode().equals("Null")  ){
                        isGridLayout =true;
                    }
                }

                GridLayoutManager gridLayoutManager = new GridLayoutManager(context,4);

                LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(context);
                linearLayoutManager1.setOrientation(RecyclerView.VERTICAL);
                if(!isGridLayout) {
                    holder.recyclerView.setLayoutManager(linearLayoutManager1);
                }else{
                    holder.recyclerView.setLayoutManager(gridLayoutManager);
                }
                holder.recyclerView.setAdapter(adapter);
            }else{
                holder.recyclerView.setVisibility(View.GONE);
            }
        }else {
            holder.itemView.setVisibility(View.GONE);
        }
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtName;
        RecyclerView recyclerView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);

            txtName = itemView.findViewById(R.id.txtName);
            recyclerView = itemView.findViewById(R.id.recyclerView);
        }
    }
}