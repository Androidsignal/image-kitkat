package com.testDemo.adapter.attributeAdapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.testDemo.R;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.adapter.AttributeListAdapter;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.AttributeValueModel;

public class ImageBoxListAdapter extends RecyclerView.Adapter<ImageBoxListAdapter.ViewHolder>{
    Context context;
    AttributeModel attributeModel;
    AttributeListAdapter attributeListAdapter;
    ProductDetailActivity productDetailActivity;


    public ImageBoxListAdapter(Context context, AttributeModel attributeModel, AttributeListAdapter attributeListAdapter,ProductDetailActivity productDetailActivity) {
        this.context = context;
        this.attributeModel = attributeModel;
        this.attributeListAdapter = attributeListAdapter;
        this.productDetailActivity = productDetailActivity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.image_squre_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final AttributeValueModel model = attributeModel.getValues().get(position);
        if(model != null && model.getImageUrl() != null){
            if(attributeModel.getCurrentValueModel() == model) {
                holder.background.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.colorAccent)));
            }else{
                holder.background.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(android.R.color.black)));
            }

            Glide.with(context).load(model.getImageUrl()).placeholder(context.getResources().getDrawable(R.drawable.placeholder)).into(holder.imageView);

            holder.imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    attributeModel.setCurrentValueModel(model);
                    holder.background.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.colorAccent)));
                    attributeModel.setError(null);
                    notifyDataSetChanged();
                    attributeModel.setError(null);
                    if(productDetailActivity != null) {
                        productDetailActivity.callApiForHideAttributeIds(true);
                    }else{
                        notifyDataSetChanged();
                        attributeListAdapter.notifyDataSetChanged();
                    }
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return attributeModel.getValues().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

       ImageView imageView;
       LinearLayout background;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);

            imageView = itemView.findViewById(R.id.imageView);
            background = itemView.findViewById(R.id.background);
        }
    }
}