package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.testDemo.R;
import com.testDemo.adapter.AddressAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.CustomSpinner;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AddressModel;
import com.testDemo.model.CurrencyModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ChangeCurrency extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Activity context = ChangeCurrency.this;
    Toolbar toolbar;
    LinearLayout layoutMain, layoutLoading, layoutNoInternet;
    ArrayList<CurrencyModel> currencyList = new ArrayList<CurrencyModel>();
    ArrayAdapter currencyAdapter;
    CustomSpinner spinner_currency;
    Button btn_forgot_password, btnReload;
    String selectedCurrencyId;
    CurrencyModel currencyModel;
    String currencyId,iteamPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_currency);
        findViewById();
        toolbarInit();
        callApi();
    }

    public void callApiForCurrency() {
        JSONHelper jsonHelper = new JSONHelper(ChangeCurrency.this, Config.BASE_URL + "languages", null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("currency") && !jsonObject.isNull("currency")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("currency");
                        currencyList = new ArrayList<CurrencyModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            currencyModel = new CurrencyModel(obj.getString("Id"), obj.getString("Name"),null);
                            currencyList.add(currencyModel);
                        }
                    }

                } else {
                    Toast.makeText(ChangeCurrency.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
                populateSpinner();
            }
        }, false);
        jsonHelper.execute();
    }

    private void populateSpinner() {
        ArrayList<String> lables = new ArrayList<String>();

        for (int i = 0; i < currencyList.size(); i++) {
            lables.add(currencyList.get(i).getName());
        }

        currencyAdapter = new ArrayAdapter<String>(ChangeCurrency.this, R.layout.spinner_item_selected_for_shipping, lables);
        currencyAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner_currency.setAdapter(currencyAdapter);
        spinner_currency.setSelection(getIndex(spinner_currency, currencyId));
    }

    private int getIndex(CustomSpinner spinner, String myString) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)) {
                return i;
            }
        }

        return 0;
    }

    private void findViewById() {
        layoutMain = findViewById(R.id.layoutMain);
        spinner_currency = findViewById(R.id.spinner_currency);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        btn_forgot_password = findViewById(R.id.btn_forgot_password);
        btnReload = findViewById(R.id.btnReload);
        btnReload.setOnClickListener(this);
        btn_forgot_password.setOnClickListener(this);
        spinner_currency.setOnItemSelectedListener(this);

    }

    private void toolbarInit() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    public void callApi() {
        if (Constants.isCheckInternetCon(ChangeCurrency.this)) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            currencyId = SharedPrefsUtils.getStringPreference(ChangeCurrency.this, Constants.PREF_SELECTED_POSITION);
            callApiForCurrency();
        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_forgot_password:
                SharedPrefsUtils.setStringPreference(context, Constants.PREF_SELECTED_CURRENCY, selectedCurrencyId);
                SharedPrefsUtils.setStringPreference(context, Constants.PREF_SELECTED_POSITION, iteamPosition);
                startActivity(new Intent(context, HomeActivity.class));
                finish();
                break;
            case R.id.btnReload:
                callApi();
                break;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        iteamPosition = parent.getItemAtPosition(position).toString();
        selectedCurrencyId = currencyList.get(position).getId();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
