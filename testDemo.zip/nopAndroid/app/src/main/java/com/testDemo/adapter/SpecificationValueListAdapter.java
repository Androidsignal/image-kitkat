package com.testDemo.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.testDemo.R;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.AttributeValueModel;
import com.testDemo.model.SpecificationValueModel;

import java.util.ArrayList;

public class SpecificationValueListAdapter extends RecyclerView.Adapter<SpecificationValueListAdapter.ViewHolder> {
    Context context;
    ArrayList<SpecificationValueModel> valueModelArrayList = new ArrayList<>();

    public SpecificationValueListAdapter(Context context, ArrayList<SpecificationValueModel> valueModelArrayList) {
        this.context = context;
        this.valueModelArrayList = valueModelArrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.simple_specification_filter_value_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final SpecificationValueModel model = valueModelArrayList.get(position);
        if(model.isSelected()){
            holder.layoutColor.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.icon_color)));
            holder.txtName.setTextColor(context.getResources().getColor(R.color.icon_color));
        }else{
            holder.layoutColor.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(android.R.color.transparent)));
            holder.txtName.setTextColor(context.getResources().getColor(R.color.black));
        }
        if(model.getColorCode() != null && !model.getColorCode().equals("null") &&!model.getColorCode().equals("Null")  &&!model.getColorCode().isEmpty()){
            holder.txtName.setVisibility(View.GONE);
            holder.layoutColor.setVisibility(View.VISIBLE);
            holder.floatingButton.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(model.getColorCode())));
        }else if(model!= null && model.getName() !=null){
            holder.txtName.setText(model.getName());
        }else{
            holder.itemView.setVisibility(View.GONE);
        }
        holder.floatingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                model.setSelected(!model.isSelected());
                notifyDataSetChanged();
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                model.setSelected(!model.isSelected());
                notifyDataSetChanged();
            }
        });
    }


    @Override
    public int getItemCount() {
        return valueModelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtName;
        LinearLayout layoutColor;
        FloatingActionButton floatingButton;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);

            txtName = itemView.findViewById(R.id.txtName);
            layoutColor = itemView.findViewById(R.id.layoutColor);
            floatingButton = itemView.findViewById(R.id.floatingButton);
        }
    }
}