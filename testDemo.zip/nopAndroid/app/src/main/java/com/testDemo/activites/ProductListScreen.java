package com.testDemo.activites;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.crystal.crystalrangeseekbar.interfaces.OnRangeSeekbarChangeListener;
import com.crystal.crystalrangeseekbar.widgets.CrystalRangeSeekbar;
import com.testDemo.R;
import com.testDemo.adapter.FilterCategoryListAdapter;
import com.testDemo.adapter.ProductListAdapter;
import com.testDemo.adapter.SizeAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.PaginationScrollListener;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.SizeModel;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.testDemo.activites.SubCategoryRelatedActivityExample.subDisplayCategory;

public class ProductListScreen extends AppCompatActivity implements View.OnClickListener {

    String manufacturersId = "", productId, mId = "null", MaxPrice = "null", MinPrice = "null", title;

    LinearLayout layoutMain, layoutLoading, layoutNoInternet, ll_filter, ll_brand, empty_list;
    RelativeLayout rl_product_list;
    RecyclerView rcv_product_list, recyclerViewForSpecificationAttribute, rcv_brand;

    ProductListAdapter productListAdapter;
    SizeAdapter sizeAdapter;
    FilterCategoryListAdapter filterCategoryListAdapter;

    ArrayList<ProductModel> productList = new ArrayList<>();
    ArrayList<SizeModel> sizeList = new ArrayList<>();
    ArrayList<CategoryModel> filterBrandList = new ArrayList<>();

    SizeModel sizeModel;
    ProductModel productModel;

    TextView tv_item_total, tv_title, minValue, maxValue, selectedAll;
    ImageView iv_option_more, iv_cancel, iv_toolbar_btn_cart;
    Button btn_clear, btn_apply;

    Toolbar toolbar;
    GridLayoutManager gridLayoutManager;
    LinearLayoutManager linear_rcv_brand;
    ProgressBar progress_bar;
    CrystalRangeSeekbar rangeSeekBar;

    boolean isLoading = false;
    boolean isLastPage = false;

    boolean applyFilter = false;
    boolean ifFromBrand = false;
    String currencyId, storeId;
    String total;
    int pages = 1;
    float min, max;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list_screen);
        findViewById();
        toolbarInit();
        currencyId = SharedPrefsUtils.getStringPreference(ProductListScreen.this, Constants.PREF_SELECTED_CURRENCY);
        storeId = SharedPrefsUtils.getStringPreference(ProductListScreen.this, Constants.PREF_SELECTED_STORE);
        if (Constants.isCheckInternetCon(ProductListScreen.this)) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            callApi(pages, ifFromBrand);
            setAdapter();
            //callApiForSize();
            //callApiForFilter();
        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }


        rcv_product_list.addOnScrollListener(new PaginationScrollListener(gridLayoutManager) {
            @Override
            protected void loadMoreItems() {
                isLoading = true;
                if (!isLastPage) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (ifFromBrand) {
                                callApiForBrandProductList(pages);
                            } else {
                                callApiForProductList(pages);
                            }
                        }
                    }, 1000);
                }

            }

            @Override
            public boolean isLastPage() {
                return isLastPage;
            }

            @Override
            public boolean isLoading() {
                return isLoading;
            }
        });


    }

    public void setAdapter() {

//        if (productList != null && productList.size() > 0) {
        productListAdapter = new ProductListAdapter(ProductListScreen.this, productList, new OnClickProduct() {
            @Override
            public void OnClickProduct(int position) {
                Intent i = new Intent(ProductListScreen.this, ProductDetailActivity.class);
                if (productList.size() > 0 && productList.get(position) != null && productList.get(position).getProductId() != null) {
                    i.putExtra(Constants.INTENT_PRODUCT_ID, productList.get(position).getProductId());
                }
                startActivity(i);

            }
        }, null);

        rcv_product_list.setAdapter(productListAdapter);
//        } else {
//            empty_list.setVisibility(View.VISIBLE);
//            layoutMain.setVisibility(View.GONE);
//        }
    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void callApi(final int page, boolean ifFromBrand) {
//         JSONHelper jsonHelper =  callApiForProductList(page);
        if (ifFromBrand) {
            callApiForBrandProductList(page);
        } else {
            callApiForProductList(page);
        }
//        jsonHelper.execute();
    }


    public void callApiForBrandProductList(final int page) {
        productId = getIntent().getStringExtra("product_id");
        JSONHelper jsonHelper = new JSONHelper(ProductListScreen.this, Config.BASE_URL + "categories/getproductbycategoriesIds?menufectureId=" + productId + "&categoryIds=" + mId + "&page=" + page + "&pagesize=4&orderby=0&MinPrice=" + MinPrice + "&MaxPrice=" + MaxPrice + "&Cid=" + currencyId + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    total = jsonObject.getString("Count");
                    if (jsonObject.has("ProductList") && !jsonObject.isNull("ProductList")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("ProductList");
                        productList = new ArrayList<ProductModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            productModel = new ProductModel();
                            productModel.parseForNewArrival(obj);
                            productList.add(productModel);
                        }
//                        progress_bar.setVisibility(View.INVISIBLE);
//                        isLoading = false;
//                        productListAdapter.addItems(productList);
//                        productListAdapter.notifyDataSetChanged();
//                        pages = page + 1;

                        if (isLoading) {
                            if (productList.size() != 0) {
                                progress_bar.setVisibility(View.GONE);
                                productListAdapter.removeLoadingFooter();
                                isLoading = false;
                                productListAdapter.addItems(productList);
                                productListAdapter.addLoadingFooter();
                                pages = page + 1;

                            } else {
                                productListAdapter.removeLoadingFooter();
                                isLoading = false;
                                isLastPage = true;
                                productListAdapter.notifyDataSetChanged();
                            }

                        } else {
                            progress_bar.setVisibility(View.GONE);

                            productListAdapter.addItems(productList);
                            productListAdapter.addLoadingFooter();
                            pages = page + 1;
                        }


                    }

                } else {
                    Toast.makeText(ProductListScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
                ifLocationIsEmpty();
                tv_item_total.setText(total + " " + getResources().getString(R.string.items_found));

//                if (applyFilter) {
//                    setAdapter();
//                }

            }
        }, false);
        jsonHelper.execute();

    }

    public void callApiForProductList(final int page) {
        String productId = getIntent().getStringExtra(Constants.INTENT_PRODUCT_ID);

        JSONHelper helper = new JSONHelper(ProductListScreen.this, Config.BASE_URL + "categories/IncludeProductsFromSubcategories1?CategoryId=" + productId + "&orderBy=0&manufectureIds=" + mId + "&page=" + page + "&pageSize=4&MinPrice=" + MinPrice + "&MaxPrice=" + MaxPrice + "&spec=" + "0" + "&Cid=" + currencyId + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    total = jsonObject.getString("Count");
                    if (jsonObject.has("ProductsFromParentcategory") && !jsonObject.isNull("ProductsFromParentcategory")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("ProductsFromParentcategory");
                        productList = new ArrayList<ProductModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            productModel = new ProductModel();
                            productModel.parseForRelatedProduct(obj);
                            productList.add(productModel);
                        }

                        if (isLoading) {
                            if (productList.size() != 0) {
                                if (productListAdapter != null) {
                                    progress_bar.setVisibility(View.GONE);
                                    productListAdapter.removeLoadingFooter();
                                    isLoading = false;
                                    productListAdapter.addItems(productList);
                                    productListAdapter.addLoadingFooter();
                                    pages = page + 1;
                                }

                            } else {
                                if (productListAdapter != null) {
                                    productListAdapter.removeLoadingFooter();
                                    isLoading = false;
                                    isLastPage = true;
                                }
                            }

                        } else {
                            if (productListAdapter != null) {
                                progress_bar.setVisibility(View.GONE);
                                productListAdapter.addItems(productList);
                                productListAdapter.addLoadingFooter();
                                pages = page + 1;
                            }

                        }

                    }

                } else {
                    Toast.makeText(ProductListScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
                ifLocationIsEmpty();
                tv_item_total.setText(total + " " + getResources().getString(R.string.items_found));

////                if (applyFilter) {
//                //// TODO: 15-10-2019
//                setAdapter();
////                }
            }
        }, false);
        helper.execute();
    }


    public void callApiForFilter() {
        JSONHelper jsonHelper = new JSONHelper(ProductListScreen.this, Config.BASE_URL + "categories/manufecturefilter?menufectureId=" + productId + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Maximumprice") && !jsonObject.isNull("Maximumprice")) {
                        MaxPrice = jsonObject.getString("Maximumprice");
                    }

                    if (jsonObject.has("MiniMumPrice") && !jsonObject.isNull("MiniMumPrice")) {
                        MinPrice = jsonObject.getString("MiniMumPrice");
                    }
                    if (jsonObject.has("Categories") && !jsonObject.isNull("Categories")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("Categories");
                        filterBrandList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            CategoryModel model = new CategoryModel();
                            JSONObject object = jsonArray.getJSONObject(i);
                            model.parse(object);
                            filterBrandList.add(model);
                        }
                        if (filterBrandList != null && filterBrandList.size() > 0) {
                            ll_brand.setVisibility(View.VISIBLE);
                        } else {
                            ll_brand.setVisibility(View.GONE);
                        }
                    }
                } else {
                    Toast.makeText(ProductListScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                }

                minValue.setText(MinPrice);
                maxValue.setText(MaxPrice);
                min = Float.parseFloat(MinPrice);
                max = Float.parseFloat(MaxPrice);
                rangeSeekBar.setMinValue(min);
                rangeSeekBar.setMaxValue(max);
                rangeSeekBar.setMinStartValue(min).setMaxStartValue(max).apply();
                filterCategoryListAdapter = new FilterCategoryListAdapter(ProductListScreen.this, filterBrandList);
                rcv_brand.setAdapter(filterCategoryListAdapter);
            }
        }, false);
        jsonHelper.execute();
    }

    private void findViewById() {
        title = getIntent().getStringExtra("product_category");
        ifFromBrand = getIntent().getBooleanExtra(Constants.IF_FROM_BRAND_LIST, false);
        layoutMain = findViewById(R.id.layoutMain);
        tv_title = findViewById(R.id.tv_title);
        iv_toolbar_btn_cart = findViewById(R.id.iv_toolbar_btn_cart);
        iv_toolbar_btn_cart.setOnClickListener(this);
        tv_title.setText(title);
        rcv_brand = findViewById(R.id.rcv_brand);
        empty_list = findViewById(R.id.empty_list);
        btn_clear = findViewById(R.id.btn_clear);
        btn_apply = findViewById(R.id.btn_apply);
        btn_clear.setOnClickListener(this);
        btn_apply.setOnClickListener(this);
        ll_filter = findViewById(R.id.ll_filter);
        iv_option_more = findViewById(R.id.iv_option_more);
        iv_cancel = findViewById(R.id.iv_cancel);
        iv_option_more.setOnClickListener(this);
        iv_cancel.setOnClickListener(this);
        tv_item_total = findViewById(R.id.tv_item_total);
        toolbar = findViewById(R.id.toolbar);
        rcv_product_list = findViewById(R.id.rcv_product_list);
        recyclerViewForSpecificationAttribute = findViewById(R.id.recyclerViewForSpecificationAttribute);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        progress_bar = findViewById(R.id.progress_bar);
        rangeSeekBar = findViewById(R.id.rangeSeekBar);
        ll_brand = findViewById(R.id.ll_brand);
        gridLayoutManager = new GridLayoutManager(ProductListScreen.this, 2);
        rcv_product_list.setLayoutManager(gridLayoutManager);
        maxValue = findViewById(R.id.maxValue);
        minValue = findViewById(R.id.minValue);
        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this);
        linearLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        recyclerViewForSpecificationAttribute.setLayoutManager(linearLayoutManager2);
        selectedAll = findViewById(R.id.selectedAll);
        rl_product_list = findViewById(R.id.rl_product_list);
        linear_rcv_brand = new LinearLayoutManager(this);
        linear_rcv_brand.setOrientation(RecyclerView.VERTICAL); // set Horizontal Orientation
        rcv_brand.setLayoutManager(linear_rcv_brand);
        selectedAll.setOnClickListener(this);

        rangeSeekBar.setOnRangeSeekbarChangeListener(new OnRangeSeekbarChangeListener() {
            @Override
            public void valueChanged(Number min, Number max) {
                minValue.setText(String.valueOf(min));
                maxValue.setText(String.valueOf(max));
            }
        });

    }

    void setDataForSpecificationAttribute() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_option_more:
                /*ll_filter.setVisibility(View.VISIBLE);
                layoutMain.setVisibility(View.GONE);
                toolbar.setVisibility(View.GONE);
                saveSate();*/
                break;
            case R.id.iv_cancel:
                layoutMain.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
                ll_filter.setVisibility(View.GONE);
                break;
            case R.id.btn_apply:
                layoutMain.setVisibility(View.GONE);
                layoutLoading.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
                ll_filter.setVisibility(View.GONE);
                productList.clear();
                applyFilter = true;
                pages = 1;
                MaxPrice = String.valueOf(rangeSeekBar.getSelectedMaxValue());
                MinPrice = String.valueOf(rangeSeekBar.getSelectedMinValue());
                brandSelected();
                callApi(pages, ifFromBrand);
                productListAdapter.notifyDataSetChanged();
                break;
            case R.id.btn_clear:
                layoutMain.setVisibility(View.GONE);
                layoutLoading.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
                ll_filter.setVisibility(View.GONE);
                callApiForFilter();
                MaxPrice = "null";
                MinPrice = "null";
                manufacturersId = "";
                mId = manufacturersId;
                productList.clear();
                applyFilter = true;
                pages = 1;
                callApi(pages, ifFromBrand);
                break;
            case R.id.iv_toolbar_btn_cart:
                startActivity(new Intent(this, CartScreen.class));
                break;

            case R.id.selectedAll:
                for (int i = 0; i < filterBrandList.size(); i++) {
                    filterBrandList.get(i).setSelected(true);
                }
                filterCategoryListAdapter.notifyDataSetChanged();
                break;
        }
    }

    public void ifLocationIsEmpty() {
        if (total != null && total.length() > 0) {
            empty_list.setVisibility(View.GONE);
            rl_product_list.setVisibility(View.VISIBLE);
        } else {
            empty_list.setVisibility(View.VISIBLE);
            rl_product_list.setVisibility(View.GONE);
        }
    }

    public void brandSelected() {
        String ids = "";
        for (int i = 0; i < filterBrandList.size(); i++) {
            if (filterBrandList.get(i).isSelected()) {
                ids += filterBrandList.get(i).getId() + ",";
            }
        }
        if (ids != null && !ids.isEmpty() && ids != "") {
            manufacturersId = ids.substring(0, ids.length() - 1);
        } else {
            manufacturersId = "";
        }
        mId = manufacturersId;
    }

    public void saveSate() {
        if (String.valueOf(min) == MinPrice && String.valueOf(max) == MaxPrice) {
            rangeSeekBar.setMinValue(Float.parseFloat(MinPrice));
            rangeSeekBar.setMaxValue(Float.parseFloat(MaxPrice));
            rangeSeekBar.apply();
        }
    }

    public interface OnClickProduct {
        void OnClickProduct(int position) throws JSONException;
    }
}
