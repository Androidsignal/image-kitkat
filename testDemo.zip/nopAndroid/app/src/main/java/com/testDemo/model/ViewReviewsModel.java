package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class ViewReviewsModel implements Serializable
{
    String title;
    String reviewsText;
    int rating;
    String username;
    String like;
    String dislike;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getReviewsText() {
        return reviewsText;
    }

    public void setReviewsText(String reviewsText) {
        this.reviewsText = reviewsText;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getLike() {
        return like;
    }

    public void setLike(String like) {
        this.like = like;
    }

    public String getDislike() {
        return dislike;
    }

    public void setDislike(String dislike) {
        this.dislike = dislike;
    }

    public void parse(JSONObject object) throws JSONException {
        if (object != null) {
            if (checkForNull("Title", object)) {
                title = object.getString("Title");
            }
            if (checkForNull("ReviewText", object)) {
                reviewsText = object.getString("ReviewText");
            }
            if (checkForNull("Rating", object)) {
                rating = object.getInt("Rating");
            }
            if (checkForNull("CustomerName", object)) {
                username = object.getString("CustomerName");
            }
            if (checkForNull("Helpfulness", object)) {
                JSONObject helpObj = object.getJSONObject("Helpfulness");
                if (checkForNull("HelpfulYesTotal", helpObj)) {
                    like = helpObj.getString("HelpfulYesTotal");
                }
                if (checkForNull("HelpfulNoTotal", helpObj)) {
                    dislike = helpObj.getString("HelpfulNoTotal");
                }
            }
        }

    }
    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }



}
