package com.testDemo.activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.gson.JsonObject;
import com.testDemo.R;
import com.testDemo.adapter.AttributeListAdapter;
import com.testDemo.adapter.CartItemListAdapter;
import com.testDemo.adapter.ListItemClickListener;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.global.SwipeToDeleteCallback;
import com.testDemo.global.SwipeUtil;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.ProductModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class CartScreen extends AppCompatActivity implements View.OnClickListener {

    Activity context = CartScreen.this;
    Toolbar toolbar;
    Button btn_continue, promoCodeApply;
    RecyclerView rcv_cart_item, rcv_for_attribute;
    ArrayList<ProductModel> cartItemList;
    ArrayList<AttributeModel> itemAttributeList;
    ProductModel productModel;
    CartItemListAdapter cartItemListAdapter;
    LinearLayout ll_empty, layoutNoInternet, layoutLoading, subtotalLayout, taxLayout, shippingLayout, totalLayout, ll_RemovePromoCode, ll_applyPromoCode;
    String userId, currencyId;
    TextView totalAmount, promoCode, subTotal, tax, shippin;
    ImageView removePromoCode;
    String promoCodes, storeId;
    EditText edit_promoCode;
    ScrollView ns_layout_main;


    AttributeListAdapter attributeListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_screen);
        findViewById();
        toolbarInit();
        userId = SharedPrefsUtils.getStringPreference(CartScreen.this, Constants.PREF_USER_ID);
        currencyId = SharedPrefsUtils.getStringPreference(CartScreen.this, Constants.PREF_SELECTED_CURRENCY);
        storeId = SharedPrefsUtils.getStringPreference(CartScreen.this, Constants.PREF_SELECTED_STORE);
        if (Constants.isCheckInternetCon(this)) {
            ns_layout_main.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            callApiForCart();
            callApiAppliedPromoCode();

        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutLoading.setVisibility(View.GONE);
            ns_layout_main.setVisibility(View.GONE);
        }

        enableSwipeToDeleteAndUndo();
    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("Cart");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void findViewById() {
        rcv_cart_item = findViewById(R.id.rcv_cart_item);
        ll_empty = findViewById(R.id.ll_empty);
        ns_layout_main = findViewById(R.id.ns_layout_main);

        rcv_for_attribute = findViewById(R.id.rcv_for_attribute);
        btn_continue = findViewById(R.id.btn_continue);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        ll_RemovePromoCode = findViewById(R.id.ll_RemovePromoCode);
        ll_applyPromoCode = findViewById(R.id.ll_applyPromoCode);
        layoutLoading = findViewById(R.id.layoutLoading);
        subtotalLayout = findViewById(R.id.subtotalLayout);
        taxLayout = findViewById(R.id.taxLayout);
        shippingLayout = findViewById(R.id.shippingLayout);
        totalLayout = findViewById(R.id.totalLayout);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        totalAmount = findViewById(R.id.txt_totalAmount);
        subTotal = findViewById(R.id.txt_subTotal);
        tax = findViewById(R.id.txt_tax);
        edit_promoCode = findViewById(R.id.edit_promoCode);
        shippin = findViewById(R.id.txt_shipping);
        promoCodeApply = findViewById(R.id.btn_apply);
        promoCode = findViewById(R.id.txt_promoCode);
        removePromoCode = findViewById(R.id.img_remove_promocode);
        btn_continue.setOnClickListener(this);
        promoCodeApply.setOnClickListener(this);
        removePromoCode.setOnClickListener(this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL); //
        rcv_cart_item.setLayoutManager(linearLayoutManager);
    }


    public void ifCartIsEmpty() {
        if (cartItemList != null && cartItemList.size() > 0) {
            ns_layout_main.setVisibility(View.VISIBLE);
            if (promoCodes != null && !promoCodes.isEmpty()) {
                ll_RemovePromoCode.setVisibility(View.VISIBLE);
                ll_applyPromoCode.setVisibility(View.GONE);
            } else {
                ll_RemovePromoCode.setVisibility(View.GONE);
                ll_applyPromoCode.setVisibility(View.VISIBLE);
            }
        } else {
            ns_layout_main.setVisibility(View.GONE);
            ll_empty.setVisibility(View.VISIBLE);
        }
    }

    public void callApiForCart() {
        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/" + userId + "?Cid=" + currencyId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                JSONArray jsonArray = null;
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("shopping_carts") && !jsonObject.isNull("shopping_carts")) {
                        jsonArray = jsonObject.getJSONArray("shopping_carts");
                        if (jsonArray.length() > 0) {
                            cartItemList = new ArrayList<ProductModel>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                productModel = new ProductModel();
                                productModel.parseForCartItem(obj);
                                cartItemList.add(productModel);
                            }

                        } else {
                            ifCartIsEmpty();
//                            Toast.makeText(CartScreen.this, "Cart Is Empty", Toast.LENGTH_SHORT).show();
                        }
                    }

                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();

                }
                if (jsonArray != null && jsonArray.length() > 0) {
                    callApiForProductAttribute();
                }

            }
        }, false);
        jsonHelper.execute();
    }

    public void callApiForProductAttribute() {
        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/checkoutattributeincart?customerId=" + userId + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                JSONArray jsonArray = null;
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("CheckOutAttribute") && !jsonObject.isNull("CheckOutAttribute")) {
                        jsonArray = jsonObject.getJSONArray("CheckOutAttribute");
                        if (jsonArray.length() > 0) {
                            itemAttributeList = new ArrayList<AttributeModel>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                AttributeModel attributeModel = new AttributeModel();
                                attributeModel.parseForCartItem(obj);
                                itemAttributeList.add(attributeModel);
                            }
                        } else {
                            ifCartIsEmpty();
                            Toast.makeText(CartScreen.this, "Cart Is Empty", Toast.LENGTH_SHORT).show();
                        }
                    }

                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();

                }
                if (jsonArray != null && jsonArray.length() > 0) {

                    getCartProductListPriceTotal();
                    layoutLoading.setVisibility(View.GONE);
                    ns_layout_main.setVisibility(View.VISIBLE);
                    ifCartIsEmpty();

                    if (itemAttributeList.size() > 0) {
                        rcv_for_attribute.setVisibility(View.VISIBLE);
                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
                        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
                        rcv_for_attribute.setLayoutManager(linearLayoutManager);
                        attributeListAdapter = new AttributeListAdapter(context, itemAttributeList, null, new ArrayList<Integer>(), null);
                        rcv_for_attribute.setAdapter(attributeListAdapter);
                    } else {
                        rcv_for_attribute.setVisibility(View.GONE);
                    }

                    cartItemListAdapter = new CartItemListAdapter(CartScreen.this, cartItemList, new ListItemClickListener() {
                        @Override
                        public void onItemClick(int position, String quantity) {
                            if (quantity != null) {
                                if (!cartItemList.get(position).getItemQuantity().equals(quantity)) {
                                    callApiForUpdateQuantity(quantity, position);
                                }
                            }
                        }
                    });
                    rcv_cart_item.setAdapter(cartItemListAdapter);
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(CartScreen.this);
                    linearLayoutManager.setOrientation(RecyclerView.VERTICAL); //
                    rcv_cart_item.setLayoutManager(linearLayoutManager);

                }

            }
        }, false);
        jsonHelper.execute();
    }

    public void callApiForUpdateQuantity(String quantity, int position) {
        layoutLoading.setVisibility(View.VISIBLE);
        ns_layout_main.setVisibility(View.GONE);

        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/updatecart?quantity=" + quantity + "&shoppingcartId=" + cartItemList.get(position).getShoppingId().toString() + "&removeshoppingcartId=0&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                JSONArray jsonArray = null;
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject != null)
                        if (jsonObject.getString("Success").equals("0")) {
                            Toast.makeText(context, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                            getCartProductTotalAfterUpadate();
                        } else {
                            Toast.makeText(context, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                            layoutLoading.setVisibility(View.GONE);
                            ns_layout_main.setVisibility(View.VISIBLE);
                        }


                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();

                }
                if (jsonArray != null && jsonArray.length() > 0) {
                    callApiForProductAttribute();
                }

            }
        }, false);
        jsonHelper.execute();
    }

    public void getCartProductListPriceTotal() {
        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/getcarttotal?customerId=" + userId + "&storeid=" + storeId + "&Cid=" + currencyId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject != null) {
                        if (jsonObject.has("CartTotal") && !jsonObject.isNull("CartTotal")) {
                            JSONObject object = jsonObject.getJSONObject("CartTotal");
                            productModel.parseForCartItem(object);
                            if (productModel.getTotalAmount() != null && !productModel.getTotalAmount().isEmpty()) {
                                totalAmount.setText(productModel.getTotalAmount());
                            } else {
                                totalLayout.setVisibility(View.GONE);
                            }
                            if (productModel.getSubTotal() != null && !productModel.getSubTotal().isEmpty()) {
                                subTotal.setText(productModel.getSubTotal());
                            } else {
                                subtotalLayout.setVisibility(View.GONE);
                            }
                            if (productModel.getShipping() != null && !productModel.getShipping().isEmpty()) {
                                shippin.setText(productModel.getShipping());
                            } else {
                                shippingLayout.setVisibility(View.GONE);
                            }
                            if (productModel.getTax() != null && !productModel.getTax().isEmpty()) {
                                tax.setText(productModel.getTax());
                            } else {
                                taxLayout.setVisibility(View.GONE);
                            }
                        } else {
                            Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }, false);
        jsonHelper.execute();
    }

    public void getCartProductTotalAfterUpadate() {
        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/getcarttotal?customerId=" + userId + "&storeid=" + storeId + "&Cid=" + currencyId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject != null) {
                        if (jsonObject.has("CartTotal") && !jsonObject.isNull("CartTotal")) {
                            JSONObject object = jsonObject.getJSONObject("CartTotal");
                            productModel.parseForCartItem(object);
                            if (productModel.getTotalAmount() != null && !productModel.getTotalAmount().isEmpty()) {
                                totalAmount.setText(productModel.getTotalAmount());
                            } else {
                                totalLayout.setVisibility(View.GONE);
                            }
                            if (productModel.getSubTotal() != null && !productModel.getSubTotal().isEmpty()) {
                                subTotal.setText(productModel.getSubTotal());
                            } else {
                                subtotalLayout.setVisibility(View.GONE);
                            }
                            if (productModel.getShipping() != null && !productModel.getShipping().isEmpty()) {
                                shippin.setText(productModel.getShipping());
                            } else {
                                shippingLayout.setVisibility(View.GONE);
                            }
                            if (productModel.getTax() != null && !productModel.getTax().isEmpty()) {
                                tax.setText(productModel.getTax());
                            } else {
                                taxLayout.setVisibility(View.GONE);
                            }
                            finish();
                            startActivity(getIntent());
                        } else {
                            Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }, false);
        jsonHelper.execute();
    }

    private void setSwipeForRecyclerView() {

        SwipeUtil swipeHelper = new SwipeUtil(0, ItemTouchHelper.LEFT, this) {
            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int swipedPosition = viewHolder.getAdapterPosition();
                cartItemListAdapter = (CartItemListAdapter) rcv_cart_item.getAdapter();
//                cartItemListAdapter.pendingRemoval(swipedPosition);
            }

            @Override
            public int getSwipeDirs(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
                int position = viewHolder.getAdapterPosition();
                cartItemListAdapter = (CartItemListAdapter) rcv_cart_item.getAdapter();
//                if (cartItemListAdapter.isPendingRemoval(position)) {
//                    return 0;
//                }
                return super.getSwipeDirs(recyclerView, viewHolder);
            }
        };

        ItemTouchHelper mItemTouchHelper = new ItemTouchHelper(swipeHelper);
        mItemTouchHelper.attachToRecyclerView(rcv_cart_item);
        //set swipe label
        swipeHelper.setLeftSwipeLable("Archive");
        //set swipe background-Color
        swipeHelper.setLeftcolorCode(ContextCompat.getColor(this, R.color.blue_btn_bg_color));
    }


    private void enableSwipeToDeleteAndUndo() {

        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(this) {

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {


                final int position = viewHolder.getAdapterPosition();
                final ProductModel item = cartItemListAdapter.getData().get(position);

                callApiForDeleteItem(item.getShoppingId(),position);


            }
        };

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchhelper.attachToRecyclerView(rcv_cart_item);
    }

    public void callApiForDeleteItem(String Id, final int position) {
        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/deleteshoppingcartorwishlistitem?id=" + Id, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("success") && !jsonObject.isNull("success") && jsonObject.getString("success").equals("0")) {
                        String msg = jsonObject.getString("message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                        cartItemListAdapter.notifyDataSetChanged();
                    } else {
                        String msg = jsonObject.getString("message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                    }
                    cartItemListAdapter.removeItem(position);
                    cartItemListAdapter.notifyDataSetChanged();

                    ifCartIsEmpty();

                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }, false);
        jsonHelper.execute();

    }

    public void callApiForRemovePromoCode() {
        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/removediscountcoupon?discountcouponcode=" + promoCodes + "&customerId=" + userId + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {
                        String msg = jsonObject.getString("Message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                        promoCodes = "";
                        edit_promoCode.setText("");
                        ll_RemovePromoCode.setVisibility(View.GONE);
                        ll_applyPromoCode.setVisibility(View.VISIBLE);

                        getCartProductListPriceTotal();

                    } else {
                        String msg = jsonObject.getString("Message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                }

            }
        }, true);
        jsonHelper.execute();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.cart_option, menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_continue:
                boolean isErrorInAttribute = conditionForAttribute();
                if (isErrorInAttribute) {
                    attributeListAdapter.notifyDataSetChanged();
                } else {
                    callApiForStoreCheckoutAttribute();
                }

                break;
            case R.id.btn_apply:
                if (!edit_promoCode.getText().toString().isEmpty()) {
                    callApiForApplyPromoCode();
                } else {
                    edit_promoCode.setError(getResources().getString(R.string.strErrorEmptyPromoCode));
                }
                break;
            case R.id.img_remove_promocode:
                callApiForRemovePromoCode();
                break;
        }
    }


    public void callApiForApplyPromoCode() {
        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/applydiscountcoupon?discountcouponcode=" + edit_promoCode.getText().toString() + "&customerId=" + userId + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {
                        String msg = jsonObject.getString("Message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                        callApiAppliedPromoCode();
                    } else {
                        String msg = jsonObject.getString("Message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }, true);
        jsonHelper.execute();

    }

    public void callApiAppliedPromoCode() {
        JSONHelper jsonHelper = new JSONHelper(CartScreen.this, Config.BASE_URL + "shopping_cart_items/applieddiscountcouponcode?customerId=" + userId + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {
                        if (jsonObject.has("CurrentCode") && !jsonObject.isNull("CurrentCode")) {
                            JSONArray jsonArray = jsonObject.getJSONArray("CurrentCode");
                            if (jsonArray.length() > 0) {
                                JSONObject obj = jsonArray.getJSONObject(0);
                                if (obj.getString("CouponCode") != null && !obj.getString("CouponCode").isEmpty()) {
                                    promoCodes = obj.getString("CouponCode");
                                    promoCode.setText(promoCodes);
                                    ll_applyPromoCode.setVisibility(View.GONE);
                                    ll_RemovePromoCode.setVisibility(View.VISIBLE);
                                    getCartProductListPriceTotal();
                                }
                            } else {
                                ll_applyPromoCode.setVisibility(View.VISIBLE);
                                ll_RemovePromoCode.setVisibility(View.GONE);
                            }
                        }

                    }
                } else {
                    Toast.makeText(CartScreen.this, "Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }

                ll_applyPromoCode.setVisibility(View.GONE);
                ll_RemovePromoCode.setVisibility(View.VISIBLE);

            }
        }, false);
        jsonHelper.execute();
    }

    boolean conditionForAttribute() {
        ArrayList<Boolean> errorList = new ArrayList<>();
        for (int i = 0; i < itemAttributeList.size(); i++) {
            AttributeModel model = itemAttributeList.get(i);
            if (model.getAttributeType() == 1 || model.getAttributeType() == 2 || model.getAttributeType() == 40 || model.getAttributeType() == 45) {
                boolean isError = conditionForSingleValue(model);
                if (isError) {
                    errorList.add(true);
                }
            } else if (model.getAttributeType() == 3) {
                boolean isError = conditionForMultiValue(model);
                if (isError) {
                    errorList.add(true);
                }
            } else if (model.getAttributeType() == 4 || model.getAttributeType() == 10 || model.getAttributeType() == 20 || model.getAttributeType() == 30) {
                boolean isError = conditionForStringValue(model);
                if (isError) {
                    errorList.add(true);
                }
            }
        }
        if (errorList.size() > 0) {
            return true;
        }
        return false;
    }

    boolean conditionForSingleValue(AttributeModel model) {
        if (model.isRequired()) {
            if (model.getCurrentValueModel() == null) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel() + " Is Required");
                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    boolean conditionForMultiValue(AttributeModel model) {
        if (model.isRequired()) {
            if (model.getSelectedValueModelList() == null || model.getSelectedValueModelList().size() == 0) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel() + " Is Required");
                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    boolean conditionForStringValue(AttributeModel model) {
        if (model.isRequired()) {
            if (model.getCurrentValue() == null || model.getCurrentValue().isEmpty()) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel() + " Is Required");
                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    String makeRequestStringForConditionalAttribute(ArrayList<AttributeModel> attributeModelArrayList) {
        String value = "";
        if (attributeModelArrayList.size() > 0) {
            for (int i = 0; i < attributeModelArrayList.size(); i++) {
                AttributeModel model = attributeModelArrayList.get(i);
                model.setChecked(0);
                if (model.getAttributeType() == 1 || model.getAttributeType() == 2 || model.getAttributeType() == 40 || model.getAttributeType() == 45) {
                    String currentValue = "0";
                    if (model.getCurrentValueModel() != null) {
                        currentValue = String.valueOf(model.getCurrentValueModel().getId());
                    }
                    value += "checkout_attribute_" +
                            "_" + model.getId() +
                            "_" + currentValue +
                            ",";
                }
                if (model.getAttributeType() == 3 || model.getAttributeType() == 50) {
                    String currentValue = "0";
                    for (int j = 0; j < model.getSelectedValueModelList().size(); j++) {
                        if (j == model.getSelectedValueModelList().size() - 1) {
                            currentValue += String.valueOf(model.getSelectedValueModelList().get(j).getId());
                        } else {
                            currentValue += String.valueOf(model.getSelectedValueModelList().get(j).getId()) + ":";
                        }
                    }
                    value += "checkout_attribute_" +
                            "_" + model.getId() +
                            "_" + currentValue +
                            ",";
                }

                if (model.getAttributeType() == 4 || model.getAttributeType() == 10 || model.getAttributeType() == 20) {
                    String currentValue = "";
                    if (model.getCurrentValue() != null) {
                        currentValue = model.getCurrentValue();
                    }
                    value += "checkout_attribute_" +
                            "_" + model.getId() +
                            "_" + currentValue +
                            ",";
                }
            }
        }
        return value;
    }

    void callApiForStoreCheckoutAttribute() {
        String value = makeRequestStringForConditionalAttribute(itemAttributeList);
        JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "checkouts/savecheckoutattribute?customerId=" + userId + "&checkout_attribute=" + value + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject object = new JSONObject(result);
                    if (object.has("Success") && !object.isNull("Success") && object.getString("Success").equals("1")) {
                        Intent i = new Intent(context, CheckOutActivity.class);
                        startActivity(i);
                    }
                }
            }
        }, true);
        helper.execute();
    }
}
