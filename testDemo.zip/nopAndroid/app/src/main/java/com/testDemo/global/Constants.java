package com.testDemo.global;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;

public class Constants {
    public static String START_SHOPPING = "START_SHOPPING";
    public static String PREF_USER_ID = "UserId";
    public static String PREF_USER_PASSWORD = "UserPassword";
    public static String PREF_USER_EMAIL = "UserEmail";
    public static String PREF_USER_NAME = "UserName";
    public static String PREF_SELECTED_CURRENCY = "SelectedCurrency";
    public static String PREF_SELECTED_POSITION = "Position";
    public static String PREF_SELECTED_STORE_POSITION = "StorePosition";
    public static String PREF_SELECTED_STORE = "SelectedStore";
    public static String IN_APP_ONLY_ONE_TIME = "ONE_TIME";

    public static String INTENT_PRODUCT_ID = "productId";
    public static String CATEGORY_LIST = "categoryList";
    public static String PARENT_CATEGORY_ID = "parentID";
    public static String CATEGORY_NAME = "CategoryName";
    public static String CATEGORY_ID= "CategoryID";
    public static String POSITION = "Position";
    public static String IF_FROM_BRAND_LIST = "IsFromBrandList";
    public static String IF_DESIGNER_COLLECTION = "IsDesignerCollecation";
    public static String IF_TOP_TREND = "isFromTopTrend";
    public static String IF_BESTSELLER = "isFromBestSeller";
    public static String ORDER_ID ="Order_id";

    public static String INTENT_FOR_TITLE ="title";
    public static String INTENT_FOR_ID ="id_for_product_list";


    public static Boolean isLoadingForAddress = false;

    public static final String INTENT_ADDRESS_MODEL = "AddressModel";
    public static String PREF_STORE_URL = "base_url";

    public static boolean isCheckInternetCon(Context paramContext) {
        ConnectivityManager localConnectivityManager = (ConnectivityManager) paramContext.getSystemService("connectivity");
        if (localConnectivityManager != null) {
            NetworkInfo[] arrayOfNetworkInfo = localConnectivityManager.getAllNetworkInfo();
            if (arrayOfNetworkInfo != null) {
                for (int i = 0; i < arrayOfNetworkInfo.length; i++) {
                    if (arrayOfNetworkInfo[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
                }
            }
            new Handler(paramContext.getMainLooper()).post(new Runnable() {
                public void run() {
                }
            });
        }
        return false;
    }
}
