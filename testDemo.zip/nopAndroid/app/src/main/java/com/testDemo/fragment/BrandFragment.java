package com.testDemo.fragment;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.testDemo.R;
import com.testDemo.activites.CartScreen;
import com.testDemo.activites.SearchAutoCompleteActivity;
import com.testDemo.adapter.BrandListAdapter;
import com.testDemo.adapter.CategoryListAdapter;
import com.testDemo.adapter.SubCategorySliderAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.ManufacturerModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.SliderModel;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.smarteist.autoimageslider.IndicatorView.utils.DensityUtils.pxToDp;

/**
 * A simple {@link Fragment} subclass.
 */
public class BrandFragment extends Fragment implements View.OnClickListener {


    Toolbar toolbar;
    RecyclerView rcv_category_list;
    BrandListAdapter categoryListAdapter;
    SliderView sliderView;

    ImageView iv_toolbar_btn_cart,iv_toolbar_search_button;

    LinearLayout layoutMain, layoutNoInternet, layoutLoading, layoutError;
    Button btnReload;

    ArrayList<ManufacturerModel> arrayListManufacturer = new ArrayList<>();

    SwipeRefreshLayout swipeRefresh;
    SubCategorySliderAdapter subCategorySliderAdapter;

    public static BrandFragment newInstance() {
        return new BrandFragment();
    }

    ArrayList<SliderModel> sliderModelArrayList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_brand, container, false);
        findViewById(view);
        toolbarInit();
        if (!Constants.isCheckInternetCon(getActivity())) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            callApiToManufacturer();


        }

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (Constants.isCheckInternetCon(getActivity())) {
                    swipeRefresh.setRefreshing(true);
                    callApiToManufacturer();
                }
            }
        });

        return view;
    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().finish();
            }
        });

    }

    private void findViewById(View view) {
        rcv_category_list = view.findViewById(R.id.rcv_category_list);
        iv_toolbar_btn_cart = view.findViewById(R.id.iv_toolbar_btn_cart);
        iv_toolbar_search_button = view.findViewById(R.id.iv_toolbar_search_button);
        iv_toolbar_btn_cart.setOnClickListener(this);
        iv_toolbar_search_button.setOnClickListener(this);
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
        sliderView = view.findViewById(R.id.imageSlider);
        toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        layoutMain = view.findViewById(R.id.layoutMain);
        layoutNoInternet = view.findViewById(R.id.layoutNoInternet);
        layoutLoading = view.findViewById(R.id.layoutLoading);
        btnReload = view.findViewById(R.id.btnReload);
        layoutError = view.findViewById(R.id.layoutError);
        btnReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().recreate();
            }
        });
        rcv_category_list.setLayoutManager(new GridLayoutManager(getActivity(), 3));
    }

    private void setDataInList(ArrayList<SliderModel> sliderModelArrayList) {
        swipeRefresh.setRefreshing(false);
        layoutLoading.setVisibility(View.GONE);
        layoutMain.setVisibility(View.VISIBLE);


        categoryListAdapter = new BrandListAdapter(getActivity(), arrayListManufacturer);
        rcv_category_list.setAdapter(categoryListAdapter);


        if (sliderModelArrayList != null && sliderModelArrayList.size() > 0) {
            subCategorySliderAdapter = new SubCategorySliderAdapter(getActivity(), sliderModelArrayList);
            subCategorySliderAdapter.setCount(sliderModelArrayList.size());
        } else {
            subCategorySliderAdapter = new SubCategorySliderAdapter(getActivity(), null);
            subCategorySliderAdapter.setCount(5);
        }

        sliderView.setSliderAdapter(subCategorySliderAdapter);
        sliderView.setIndicatorAnimation(IndicatorAnimations.WORM);
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderView.setScrollTimeInSec(4); //set scroll delay in seconds :
        sliderView.startAutoCycle();
    }

    private void callApiToManufacturer() {

        JSONHelper helper = new JSONHelper(getActivity(), Config.BASE_URL + "manufacturers", null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("manufacturers") && !jsonObject.isNull("manufacturers")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("manufacturers");
                        arrayListManufacturer = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            ManufacturerModel model = new ManufacturerModel();
                            JSONObject object = jsonArray.getJSONObject(i);
                            model.parse(object);
                            arrayListManufacturer.add(model);
                        }
                    } else {
                        layoutLoading.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);
                    }
                } else {
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }
                callApiToImageSlider();
            }
        }, false);
        helper.execute();
    }

    private void callApiToImageSlider() {

        JSONHelper helper = new JSONHelper(getActivity(), Config.BASE_URL + "orders/menufecturenivoslider", null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    sliderModelArrayList = new ArrayList<>();
                    if (jsonObject.has("CategoryPicture") && !jsonObject.isNull("CategoryPicture")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("CategoryPicture");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            SliderModel model = new SliderModel();
                            model.parseForImageSlider(obj);
                            sliderModelArrayList.add(model);
                        }
                    } else {
                        layoutLoading.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);
                    }
                } else {
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }
                setDataInList(sliderModelArrayList);
            }
        }, false);
        helper.execute();
    }

    @Override
    public void onClick(View view) {
       switch (view.getId()) {
            case R.id.iv_toolbar_btn_cart:
                startActivity(new Intent(getActivity(), CartScreen.class));
                break;

           case R.id.iv_toolbar_search_button:
               startActivity(new Intent(getActivity(), SearchAutoCompleteActivity.class));
               break;
        }
    }
}
