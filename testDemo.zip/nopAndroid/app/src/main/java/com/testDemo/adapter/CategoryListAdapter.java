package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.SubCategoryActivity;
import com.testDemo.fragment.ExploreFragment;
import com.testDemo.fragment.ShopFragment;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.ProductModel;

import java.util.ArrayList;

public class CategoryListAdapter extends RecyclerView.Adapter<CategoryListAdapter.ViewHolder> {
    Context context;
    ArrayList<CategoryModel> designerCollection;
    ExploreFragment fragment;


    public CategoryListAdapter(Context context, ArrayList<CategoryModel> designerCollection, ExploreFragment fragment) {
        this.context = context;
        this.designerCollection = designerCollection;
        this.fragment = fragment;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.category_list_layout_explorer, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final CategoryModel myListData = designerCollection.get(position);
        if (myListData != null) {
            if (myListData.getName() != null) {
                holder.txtCategoryName.setText(myListData.getName());
            }
            if (myListData.getImage() != null) {
                Glide.with(holder.itemView)
                        .load(myListData.getImage())
                        .into(holder.iv_product_image);
            }
        }
        holder.cv_onClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment.onclickCategory(myListData, position);
            }
        });
    }

    public void updateList(ArrayList<CategoryModel> list) {
        designerCollection = list;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_product_image;
        TextView txtCategoryName;
        CardView cv_onClick;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            iv_product_image = (ImageView) itemView.findViewById(R.id.iv_product_image);
            txtCategoryName = (TextView) itemView.findViewById(R.id.tv_category_name);
            cv_onClick = (CardView) itemView.findViewById(R.id.cv_onClick);
        }
    }


}