package com.testDemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.model.SliderModel;
import com.smarteist.autoimageslider.SliderViewAdapter;

import java.util.ArrayList;

public class SubCategorySliderAdapter extends
        SliderViewAdapter<SubCategorySliderAdapter.SliderAdapterVH> {

    Context context;
    ArrayList<SliderModel> sliderModelArrayListNew = new ArrayList<>();
    int mCount;

    public SubCategorySliderAdapter(Context context, ArrayList<SliderModel> sliderModelArrayLis) {
        this.context = context;
        this.sliderModelArrayListNew = sliderModelArrayLis;
    }

    public void setCount(int count) {
        this.mCount = count;
    }

    @Override
    public SliderAdapterVH onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_slider_layout_item, null);
        return new SliderAdapterVH(inflate);
    }

    @Override
    public void onBindViewHolder(SliderAdapterVH viewHolder, final int position) {

        if (sliderModelArrayListNew != null && sliderModelArrayListNew.size() > 0) {
            Glide.with(viewHolder.itemView)
                    .load(sliderModelArrayListNew.get(position).imageUrl)
                    .fitCenter()
                    .into(viewHolder.imageViewBackground);
        }


    }

    @Override
    public int getCount() {
        //slider view count could be dynamic size
        return mCount;
    }

    class SliderAdapterVH extends SliderViewAdapter.ViewHolder {

        View itemView;
        ImageView imageViewBackground;


        public SliderAdapterVH(View itemView) {
            super(itemView);
            imageViewBackground = itemView.findViewById(R.id.iv_auto_image_slider);
            this.itemView = itemView;
        }
    }
}
