package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class PaymentMethodModel implements Serializable {
    String paymentMethodSystemName;
    String name;
    String description;
    boolean isSelected;
    String logoUrl;

    public String getPaymentMethodSystemName() {
        return paymentMethodSystemName;
    }

    public String getName() {
        return name;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public String getLogoUrl() {
        return logoUrl;
    }

    public String getDescription() {
        return description;
    }

    public void parse(JSONObject object) throws JSONException {
        if (object != null) {
            if (checkForNull("PaymentMethodSystemName", object)) {
                paymentMethodSystemName = object.getString("PaymentMethodSystemName");
            }
            if (checkForNull("Name", object)) {
                name = object.getString("Name");
            }
            if (checkForNull("Selected", object)) {
                isSelected = object.getBoolean("Selected");
            }
            if(checkForNull("Description",object)){
                description = object.getString("Description");
            }
            if (checkForNull("LogoUrl", object)) {
                logoUrl = object.getString("LogoUrl");
            }
        }
    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }
}
