package com.testDemo.model.AddressModels;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONException;
import org.json.JSONObject;

public class StateListModel implements Parcelable {
    boolean isDisabled = false;
    boolean isSelected = false;
    String strText;
    String strValue;

    public StateListModel() {
    }

    protected StateListModel(Parcel in) {
        isDisabled = in.readByte() != 0;
        isSelected = in.readByte() != 0;
        strText = in.readString();
        strValue = in.readString();
    }

    public static final Creator<StateListModel> CREATOR = new Creator<StateListModel>() {
        @Override
        public StateListModel createFromParcel(Parcel in) {
            return new StateListModel(in);
        }

        @Override
        public StateListModel[] newArray(int size) {
            return new StateListModel[size];
        }
    };

    public boolean isDisabled() {
        return isDisabled;
    }

    public void setDisabled(boolean disabled) {
        isDisabled = disabled;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getStrText() {
        return strText;
    }

    public void setStrText(String strText) {
        this.strText = strText;
    }

    public String getStrValue() {
        return strValue;
    }

    public void setStrValue(String strValue) {
        this.strValue = strValue;
    }

    @Override
    public String toString() {
        return "StateListModel{" +
                "isDisabled=" + isDisabled +
                ", isSelected=" + isSelected +
                ", strText='" + strText + '\'' +
                ", strValue='" + strValue + '\'' +
                '}';
    }

    public void parse(JSONObject object) throws JSONException {
        if(object != null){
            if(checkForNull("Disabled",object)){
                isDisabled = object.getBoolean("Disabled");
            }
            if(checkForNull("Selected",object)){
                isSelected = object.getBoolean("Selected");
            }
            if(checkForNull("Text",object)){
                strText = object.getString("Text");
            }
            if(checkForNull("Value",object)){
                strValue = object.getString("Value");
            }

            if(checkForNull("name",object)){
                strText = object.getString("name");
            }
            if(checkForNull("id",object)){
                strValue = object.getString("id");
            }
        }
    }

    private boolean checkForNull(String key,JSONObject object){
        return  object!= null && object.has(key) && !object.isNull(key);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte((byte) (isDisabled ? 1 : 0));
        dest.writeByte((byte) (isSelected ? 1 : 0));
        dest.writeString(strText);
        dest.writeString(strValue);
    }
}
