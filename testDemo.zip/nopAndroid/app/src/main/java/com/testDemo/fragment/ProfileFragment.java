package com.testDemo.fragment;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.google.gson.JsonObject;
import com.testDemo.R;
import com.testDemo.activites.ChangeCurrency;
import com.testDemo.activites.ChangePasswordActivity;
import com.testDemo.activites.ChangeStoreLocationActivity;
import com.testDemo.activites.ContactusActivity;
import com.testDemo.activites.EditProfileActivity;
import com.testDemo.activites.LoginActivity;
import com.testDemo.activites.MyOrderActivity;
import com.testDemo.activites.MyReviewListActivity;
import com.testDemo.activites.ResetPasswordActivity;
import com.testDemo.activites.ShippingAddressesActivity;
import com.testDemo.activites.SplashActivity;
import com.testDemo.activites.WishlistActivity;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;

import cn.pedant.SweetAlert.SweetAlertDialog;

import com.testDemo.activites.ResetPasswordActivity;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductModel;
import com.testDemo.model.UserModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.facebook.FacebookSdk.getApplicationContext;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment implements View.OnClickListener {


    public static ProfileFragment newInstance() {
        return new ProfileFragment();
    }

    LinearLayout ll_logout;
    LinearLayout layout_profile;
    LinearLayout ll_change_password;
    LinearLayout ll_shipping_addresses, ll_orders;
    LinearLayout ll_change_store_location;
    LinearLayout ll_currency;
    LinearLayout ll_contactus;
    LinearLayout ll_edit_profile;
    LinearLayout ll_wishlist;
    LinearLayout ll_my_product_review;

    CircleImageView circleImageView;
    TextView username;
    LinearLayout layoutNoInternet, layoutLoading;
    ScrollView scroll_layout;
    UserModel userModel;

    String userId, firstName, lastName, imageUrl;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        FacebookSdk.sdkInitialize(getApplicationContext());
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        findViewById(view);
        userId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_USER_ID);

        callApi();

        return view;
    }

    private void callApi() {
        if (Constants.isCheckInternetCon(getActivity())) {
            scroll_layout.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            callApiForProfile();
        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            scroll_layout.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }
    }

    private void findViewById(View view) {
        ll_logout = view.findViewById(R.id.ll_logout);
        ll_shipping_addresses = view.findViewById(R.id.ll_shipping_addresses);
        ll_change_password = view.findViewById(R.id.ll_change_password);
        ll_my_product_review = view.findViewById(R.id.ll_my_product_review);
        ll_currency = view.findViewById(R.id.ll_currency);
        ll_contactus = view.findViewById(R.id.ll_contactus);
        ll_edit_profile = view.findViewById(R.id.ll_edit_profile);
        ll_orders = view.findViewById(R.id.ll_orders);
        ll_wishlist = view.findViewById(R.id.ll_wishlist);
        ll_change_store_location = view.findViewById(R.id.ll_change_store_location);
        ll_change_store_location.setOnClickListener(this);
        ll_logout.setOnClickListener(this);
        layout_profile = view.findViewById(R.id.layout_profile);
        layout_profile.setOnClickListener(this);
        ll_currency.setOnClickListener(this);
        ll_contactus.setOnClickListener(this);
        ll_shipping_addresses.setOnClickListener(this);
        ll_change_password.setOnClickListener(this);
        ll_my_product_review.setOnClickListener(this);
        ll_orders.setOnClickListener(this);
        ll_wishlist.setOnClickListener(this);
        ll_edit_profile.setOnClickListener(this);
        username = view.findViewById(R.id.txt_username);
        circleImageView = view.findViewById(R.id.profile_image);
        layoutNoInternet = view.findViewById(R.id.layoutNoInternet);
        layoutLoading = view.findViewById(R.id.layoutLoading);
        scroll_layout = view.findViewById(R.id.scroll_layout);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ll_logout:
                logOutButton();
                break;
            case R.id.ll_change_password:
                changePasswordButton();
                break;
            case R.id.ll_shipping_addresses:
                startActivity(new Intent(getActivity(), ShippingAddressesActivity.class));
                break;
            case R.id.ll_currency:
                startActivity(new Intent(getActivity(), ChangeCurrency.class));
                break;
            case R.id.ll_change_store_location:
                startActivity(new Intent(getActivity(), ChangeStoreLocationActivity.class));
                break;
            case R.id.ll_orders:
                startActivity(new Intent(getActivity(), MyOrderActivity.class));
                break;
            case R.id.ll_edit_profile:
                Intent intent = new Intent(getActivity(), EditProfileActivity.class);
                startActivityForResult(intent, 10001);
                break;
            case R.id.layout_profile:
                intent = new Intent(getActivity(), EditProfileActivity.class);
                startActivityForResult(intent, 10001);
                break;
            case R.id.ll_wishlist:
                intent = new Intent(getActivity(), WishlistActivity.class);
                startActivityForResult(intent, 10001);
                break;
            case R.id.ll_my_product_review:
                intent = new Intent(getActivity(), MyReviewListActivity.class);
                startActivityForResult(intent, 10001);
                break;
            case R.id.ll_contactus:
                intent = new Intent(getActivity(), ContactusActivity.class);
                startActivityForResult(intent, 10001);
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ((requestCode == 10001) && (resultCode == Activity.RESULT_OK)) {
            callApi();
        }

    }

    private void changePasswordButton() {
        startActivity(new Intent(getActivity(), ChangePasswordActivity.class));
    }

    private void logOutButton() {
        try {
            new SweetAlertDialog(getContext(), SweetAlertDialog.CUSTOM_IMAGE_TYPE)
                    .setTitleText("Are you sure want to Logout?")
                    .setConfirmText("Yes!")
                    .setCustomImage(R.mipmap.ic_launcher)
                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            try {
                                SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
                                editor.remove(Constants.PREF_USER_ID);
                                editor.commit();
                                LoginManager.getInstance().logOut();
                                SharedPrefsUtils.setBooleanPreference(getActivity(), Constants.START_SHOPPING, true);
                                startActivity(new Intent(getActivity(), LoginActivity.class));
                                getActivity().finish();
                                sDialog.dismissWithAnimation();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    })
                    .setCancelButton("No", new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            sDialog.dismissWithAnimation();
                        }
                    })
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void callApiForProfile() {
        JSONHelper jsonHelper = new JSONHelper(getActivity(), Config.BASE_URL + "customers/" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("customers") && !jsonObject.isNull("customers")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("customers");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            userModel = new UserModel();
                            if (obj.has("first_name") && !obj.isNull("first_name")) {
                                firstName = obj.getString("first_name");
                            }
                            if (obj.has("last_name") && !obj.isNull("last_name")) {
                                lastName = obj.getString("last_name");

                            }
                            if (obj.has("avatar_url") && !obj.isNull("avatar_url")) {
                                imageUrl = obj.getString("avatar_url");
                            }
                        }
                        username.setText(firstName);

                        Glide.with(getActivity()).load(imageUrl).placeholder(R.drawable.image).into(circleImageView);


                    }

                } else {
                    Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }

                layoutLoading.setVisibility(View.GONE);
                scroll_layout.setVisibility(View.VISIBLE);
            }
        }, false);
        jsonHelper.execute();
    }


}
