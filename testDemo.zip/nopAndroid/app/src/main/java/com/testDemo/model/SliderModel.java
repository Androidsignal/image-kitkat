package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

public class SliderModel {

    public String id;
    public String imageUrl;


    public void parseForImageSlider(JSONObject obj) {
        try {
            if (obj.has("id") && !obj.isNull("id")) {
                id = obj.getString("id");
            }
            if (obj.has("pictureurl") && !obj.isNull("pictureurl")) {
                imageUrl = obj.getString("pictureurl");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
