package com.testDemo.activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.testDemo.R;
import com.testDemo.adapter.SearchProductAdapter;
import com.testDemo.adapter.SearchResultAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.PaginationScrollListener;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class SearchResultActivity extends AppCompatActivity implements View.OnClickListener {

    Toolbar toolbar;

    EditText searchEditText;

    String TAG = getClass().getSimpleName();
    Activity context = SearchResultActivity.this;

    String keyword;

    LinearLayout layoutMain;
    LinearLayout layoutLoading;
    LinearLayout layoutNoDataFound;
    LinearLayout layoutError;
    LinearLayout layoutNoInternet;
    LinearLayout layoutFilter;
    Button btnReload;

    ImageView imgFilterBtn;
    ImageView iv_cancel;

    ProgressBar progress_bar;

    int page = 1;

    boolean isLastPage =false;
    boolean isLoading = false;
    boolean isFilterOpen = false;
    boolean isFilterApplied = false;

    GridLayoutManager gridLayoutManager;

    RecyclerView recyclerViewForSearchItems;

    SearchResultAdapter searchResultAdapter;

    ArrayList<ProductModel> searchList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);

        keyword = getIntent().getStringExtra("keyword");

        findViewById();

        setUpToolbar();

        setSearchEditText();

        callApi();

        applySearchFilter();
    }

    private  void findViewById()
    {
        toolbar = findViewById(R.id.toolbar);
        searchEditText = findViewById(R.id.searchEditText);
        progress_bar = findViewById(R.id.progress_bar);
        imgFilterBtn = findViewById(R.id.imgFilterBtn);
        iv_cancel = findViewById(R.id.iv_cancel);
        recyclerViewForSearchItems = findViewById(R.id.recyclerViewForSearchItems);
        gridLayoutManager = new GridLayoutManager(context,2);
        recyclerViewForSearchItems.setLayoutManager(gridLayoutManager);

        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutError = findViewById(R.id.layoutError);
        layoutNoDataFound = findViewById(R.id.layoutNoDataFound);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutFilter = findViewById(R.id.layoutFilter);
        layoutMain = findViewById(R.id.layoutMain);
        btnReload = findViewById(R.id.btnReload);

        imgFilterBtn.setOnClickListener(this);
        iv_cancel.setOnClickListener(this);
    }

    void setUpToolbar() {
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
    void setSearchEditText()
    {
        searchEditText.setText(keyword);
    }

    private void callApi() {

        if (Constants.isCheckInternetCon(SearchResultActivity.this))
        {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            layoutNoDataFound.setVisibility(View.GONE);

            callApiToGetSearchProducts(keyword,page);
        }
        else
        {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }

    }

    private void applySearchFilter() {
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (s.length() >= 3) {
                    searchResultAdapter = null;
                    page = 1;
                    isLastPage = false;
                    isLoading = true;
                    Log.d(TAG, s.toString());
                    layoutMain.setVisibility(View.GONE);
                    layoutNoDataFound.setVisibility(View.GONE);
                    layoutError.setVisibility(View.GONE);
                    layoutLoading.setVisibility(View.VISIBLE);

                    callApiToGetSearchProducts(s.toString(),page);
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

                if (searchEditText.getText().toString().equals("")) {
                    recyclerViewForSearchItems.setVisibility(View.GONE);
                }

            }
        });
    }

    private void callApiToGetSearchProducts(String keyword, final int page) {
        Log.d("word", "key word " + keyword);

        String url = Config.BASE_URL + "products/advancedsearch";

        HashMap<String,String> hashMap = new HashMap<>();
        hashMap.put("q",keyword);
        hashMap.put("Page", String.valueOf(page));
        hashMap.put("PageSize", String.valueOf(10));
        Log.d("inputss", String.valueOf(hashMap));

        JSONHelper jsonHelper = new JSONHelper(context, url, hashMap, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {

                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    Log.d("resultsss",result);

                    if (jsonObject.has("pro") && !jsonObject.isNull("pro")) {
                        JSONArray searchArrayObj = jsonObject.getJSONArray("pro");

                        searchList = new ArrayList<>();

                        for (int i = 0; i < searchArrayObj.length(); i++) {
                            JSONObject jsonObject1 = searchArrayObj.getJSONObject(i);
                            ProductModel productModel = new ProductModel();
                            productModel.parseForSearchResult(jsonObject1);
                            searchList.add(productModel);
                        }

                        if (searchArrayObj.length() < 1) {
                            isLastPage = true;
                        } else {
                            isLastPage = false;
                        }

                        setDataForRecyclerView();

                    } else {
                        layoutMain.setVisibility(View.GONE);
                        layoutError.setVisibility(View.GONE);
                        layoutLoading.setVisibility(View.GONE);
                        layoutNoDataFound.setVisibility(View.VISIBLE);
                    }
                } else {
                    layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                    layoutLoading.setVisibility(View.GONE);
                    layoutNoDataFound.setVisibility(View.GONE);
                }
            }
        }, false);

        jsonHelper.execute();
    }

    private void setDataForRecyclerView() {

            if (searchResultAdapter==null)
            {
                if (searchList.size() == 0)
                {
                    layoutNoDataFound.setVisibility(View.VISIBLE);
                    layoutLoading.setVisibility(View.GONE);
                    layoutMain.setVisibility(View.GONE);
                }else {
                    layoutNoDataFound.setVisibility(View.GONE);
                    layoutLoading.setVisibility(View.GONE);
                    layoutMain.setVisibility(View.VISIBLE);
                    recyclerViewForSearchItems.setVisibility(View.VISIBLE);
                    searchResultAdapter = new SearchResultAdapter(this, searchList);
                    recyclerViewForSearchItems.setAdapter(searchResultAdapter);
                }
            }
            else {
                if(searchList.size() > 0) {
                    searchResultAdapter.upDateArrayList(searchList);
                }
                progress_bar.setVisibility(View.GONE);
                isLoading = false;
            }

            recyclerViewForSearchItems.addOnScrollListener(new PaginationScrollListener(gridLayoutManager) {
                @Override
                protected void loadMoreItems() {
                    progress_bar.setVisibility(View.VISIBLE);
                    if(Constants.isCheckInternetCon(context)) {
                        if (!isLastPage) {
                            isLoading = true;
                            progress_bar.setVisibility(View.VISIBLE);
                            page = page + 1;
                            callApiToGetSearchProducts(keyword,page);

                        }
                    }
                }

                @Override
                public boolean isLastPage() {
                    return isLastPage;
                }

                @Override
                public boolean isLoading() {
                    return isLoading;
                }
            });


    }

    void onClickFilter() {
        isFilterOpen = true;
        layoutMain.setVisibility(View.GONE);
        toolbar.setVisibility(View.GONE);
        layoutFilter.setVisibility(View.VISIBLE);
    }

    void onCLickFilterCancel()
    {
        isFilterOpen = false;
        layoutMain.setVisibility(View.VISIBLE);
        toolbar.setVisibility(View.VISIBLE);
        layoutFilter.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.btnReload:
                callApi();
                break;

            case R.id.imgFilterBtn:
                onClickFilter();
                break;

            case R.id.iv_cancel:
                onCLickFilterCancel();
                break;
        }
    }
}
