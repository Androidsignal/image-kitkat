package com.testDemo.activites;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.global.Utility;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductDetailModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.UserModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class AddReview extends AppCompatActivity {
    Activity context = AddReview.this;
    Toolbar toolbar;
    ImageView productImage;
    CircleImageView userImage;
    TextView userName, productName;
    RatingBar ratingBar;
    EditText edtTitle, edtAddReview;
    Button btnSubmit;
    String storeId = "";


    UserModel userModel;
    String userId, firstName, lastName, imageUrl;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_review);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
        findid();
        storeId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_STORE);
        userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);
        btnsetsubmit();
        Glide.with(this).load(getIntent().getStringExtra("image")).into(productImage);
        //  userName.setText(getIntent().getStringExtra("username"));
        productName.setText(getIntent().getStringExtra("prodname"));

        JSONHelper jsonHelper = new JSONHelper(context, Config.BASE_URL + "customers/" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("customers") && !jsonObject.isNull("customers")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("customers");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            userModel = new UserModel();
                            if (obj.has("first_name") && !obj.isNull("first_name")) {
                                firstName = obj.getString("first_name");
                            }
                            if (obj.has("last_name") && !obj.isNull("last_name")) {
                                lastName = obj.getString("last_name");

                            }
                            if (obj.has("avatar_url") && !obj.isNull("avatar_url")) {
                                imageUrl = obj.getString("avatar_url");
                            }
                        }
                        userName.setText(firstName);

                        if (imageUrl == null) {
                            Glide.with(context).load(imageUrl).placeholder(R.drawable.actor).into(userImage);
                        } else {
                            Glide.with(context).load(imageUrl).into(userImage);
                        }

                    }

                } else {
                    Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }

               /* layoutLoading.setVisibility(View.GONE);
                scroll_layout.setVisibility(View.VISIBLE);*/
            }
        }, false);
        jsonHelper.execute();
    }

    private void btnsetsubmit() {

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ratingBar.getRating() == 0.0) {

                    Toast.makeText(AddReview.this, "Fill Rating", Toast.LENGTH_SHORT).show();

                } else if (edtTitle.getText().toString().length() == 0) {

                    edtTitle.setError("Enter Title");

                } else if (edtAddReview.getText().toString().length() == 0) {
                    edtAddReview.setError("Add Review");
                } else {

                    callcustomerApi();
                }
            }
        });
    }

    private void callcustomerApi() {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("rating", String.valueOf(ratingBar.getRating()));
        hashMap.put("title", edtTitle.getText().toString());
        hashMap.put("review", edtAddReview.getText().toString());
        JSONHelper jsonHelper = new JSONHelper(AddReview.this, Config.BASE_URL + "products/addproductreviews?customerId=" + userId, hashMap, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success")) {
                        finish();
                    }

                } else {
                    Toast.makeText(context, " Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }, true);

        jsonHelper.execute();
    }


    private void findid() {
        productImage = findViewById(R.id.iv_product_image);
        userImage = findViewById(R.id.user_image);

        userName = findViewById(R.id.txt_userName);
        productName = findViewById(R.id.txt_productName);

        ratingBar = findViewById(R.id.rb_rating);

        edtTitle = findViewById(R.id.edt_title);
        edtAddReview = findViewById(R.id.edt_review);

        btnSubmit = findViewById(R.id.btn_submit);


    }

}
