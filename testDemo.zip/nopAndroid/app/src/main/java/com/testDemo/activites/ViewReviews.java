package com.testDemo.activites;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.testDemo.R;
import com.testDemo.adapter.ViewReviewsAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductDetailModel;
import com.testDemo.model.ViewReviewsModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ViewReviews extends AppCompatActivity {
    ViewReviewsModel viewReviewsModel;
    ArrayList<ViewReviewsModel> reviewsModels;
    RecyclerView recyclerView;
    String productId = "";
    String customerID;

    LinearLayout layoutNoInternet;
    LinearLayout layoutLoading;
    Toolbar toolbar;
    Button btnReload;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_reviews);
        findViewById();
        setSupportActionBar(toolbar);
        toolbar.setTitle("Review");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });
        productId = getIntent().getStringExtra("PRODUCT_ID");
        customerID = getIntent().getStringExtra("CUSTOMER_ID");
      //  reviewDetail();

        btnReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.isCheckInternetCon(ViewReviews.this)) {
                    layoutNoInternet.setVisibility(View.GONE);
                    layoutLoading.setVisibility(View.GONE);
                    reviewDetail();

                }
            }
        });

        if (Constants.isCheckInternetCon(ViewReviews.this)) {

            layoutLoading.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.GONE);
            reviewDetail();

        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutLoading.setVisibility(View.VISIBLE);
        }





    }

    private void findViewById() {
        recyclerView = findViewById(R.id.rv_viewReviews);
       // layoutMain=findViewById(R.id.ll_viewmain);
        toolbar=findViewById(R.id.toolbar_view);
        layoutLoading=findViewById(R.id.layoutLoading);
        layoutNoInternet=findViewById(R.id.layoutNoInternet);
        btnReload = findViewById(R.id.btnReload);

    }

    private void reviewDetail() {

        JSONHelper helper = new JSONHelper(ViewReviews.this, Config.BASE_URL + "products/productreviewslist?productId=" + productId + "&customerId=" + customerID, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {


                try {
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        JSONObject jsonObject1 = jsonObject.getJSONObject("ProductReviewsList");
                        if (jsonObject1.has("Items") && !jsonObject1.isNull("Items")) {
                            JSONArray products = jsonObject1.getJSONArray("Items");
                            reviewsModels = new ArrayList<>();
                            for (int i = 0; i < products.length(); i++) {
                                JSONObject object = products.getJSONObject(i);
                                viewReviewsModel = new ViewReviewsModel();
                                viewReviewsModel.parse(object);
                                reviewsModels.add(viewReviewsModel);
                            }
                        }
                    }

                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewReviews.this);
                    linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
                    recyclerView.setLayoutManager(linearLayoutManager);
                    ViewReviewsAdapter adapter = new ViewReviewsAdapter(ViewReviews.this, reviewsModels);
                    recyclerView.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();

                }
            }
        }, false);
        helper.execute();

    }
}
