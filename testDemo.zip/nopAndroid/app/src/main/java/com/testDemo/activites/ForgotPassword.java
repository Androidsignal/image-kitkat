package com.testDemo.activites;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.UserModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ForgotPassword extends AppCompatActivity implements View.OnClickListener {

    Activity context = ForgotPassword.this;

    Toolbar toolbar;
    Button btn_forgot_password,btnReload;
    EditText et_email;
    LinearLayout layoutMain, layoutNoInternet;

    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        findViewById();
        toolbarInit();
        if (!Constants.isCheckInternetCon(context)) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
        }


    }

    private void findViewById() {
        et_email = findViewById(R.id.et_email);
        btnReload = findViewById(R.id.btnReload);
        layoutMain = findViewById(R.id.layoutMain);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        btn_forgot_password = findViewById(R.id.btn_forgot_password);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        btn_forgot_password.setOnClickListener(this);
        btnReload.setOnClickListener(this);
    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_forgot_password:
                if (validateForm()) {
                    callApiForForgotPassword();
                }
                break;
            case R.id.btnReload:
                finish();
                startActivity(getIntent());
                break;
        }
    }

    boolean validateForm() {
        if (!et_email.getText().toString().isEmpty()) {

            if (et_email.getText().toString().matches(emailPattern)) {
                return true;
            } else {
                et_email.setError(getResources().getString(R.string.strErrorInvalidEmail));
            }

        } else {
            et_email.setError(getResources().getString(R.string.strErrorEmptyEmail));
        }
        return false;
    }


    public void callApiForForgotPassword() {
        JSONHelper jsonHelper = new JSONHelper(ForgotPassword.this, Config.BASE_URL + "customers/forgotpassword?Email=" + et_email.getText().toString(), null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("success") && !jsonObject.isNull("success") && jsonObject.getString("success").equals("0")) {

                        Toast.makeText(context, "Link has been Send", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(context, "Link has been Send Failed", Toast.LENGTH_SHORT).show();
                        /*layoutMain.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);*/
                    }
                } else {
                    Toast.makeText(context, "Link has been Send Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }
            }
        }, true);
        jsonHelper.execute();
    }

}
