package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.CartScreen;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.config.Config;
import com.testDemo.fragment.ShopFragment;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class DesignerCollectionListAdapter extends RecyclerView.Adapter<DesignerCollectionListAdapter.ViewHolder> {
    Context context;
    ArrayList<ProductModel> designerCollection;
    Fragment fragment;
    ProductModel myListData;
    public DesignerCollectionListAdapter(Context context, ArrayList<ProductModel> designerCollection, Fragment fragment) {
        this.context = context;
        this.designerCollection = designerCollection;
        this.fragment = fragment;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.designer_collection_product_row_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
          myListData = designerCollection.get(position);
        Glide.with(holder.itemView)
                .load(myListData.getProductImage())
                .into(holder.iv_product_image);


        holder.tv_product_price.setText(myListData.getProductPrice());
        holder.tv_product_name.setText(myListData.getProductName());
        holder.iv_cart_not_added.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ((ShopFragment) fragment).favoriteOnclick(position);
                ((ShopFragment) fragment).onclickDesignerCollectionItem(position);
            }
        });
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ShopFragment) fragment).onclickDesignerCollectionItem(position);
            }
        });

        ViewGroup.MarginLayoutParams layoutParams =
                (ViewGroup.MarginLayoutParams) holder.cardView.getLayoutParams();
        if (position == 0) {
            layoutParams.setMargins(30, 10, 10, 10);
        } else {
            layoutParams.setMargins(10, 10, 10, 10);
        }
        holder.cardView.requestLayout();

        if (myListData.isGetProductInShoppingCart()) {
            holder.iv_cart_not_added.setVisibility(View.GONE);
            holder.iv_cart_added.setVisibility(View.VISIBLE);
        } else {
            holder.iv_cart_not_added.setVisibility(View.VISIBLE);
            holder.iv_cart_added.setVisibility(View.GONE);
        }

        holder.iv_cart_not_added.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myListData.getAttributeModelArrayList() != null && myListData.getAttributeModelArrayList().size() > 0) {
                    Intent i = new Intent(context, ProductDetailActivity.class);
                    i.putExtra(Constants.INTENT_PRODUCT_ID, myListData.getProductId().toString());
                    context.startActivity(i);
                } else {
                    callApiForAddToCart(myListData, position, holder);
                }
            }
        });

        holder.iv_cart_added.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, CartScreen.class));
            }
        });
    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_product_image;
        ImageView iv_cart_not_added, iv_cart_added;
        TextView tv_product_name, tv_product_price;
        LinearLayout cardView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            iv_product_image = (ImageView) itemView.findViewById(R.id.iv_product_image);
            iv_cart_not_added = (ImageView) itemView.findViewById(R.id.iv_cart_not_added);
            iv_cart_added = (ImageView) itemView.findViewById(R.id.iv_cart_added);
            tv_product_name = (TextView) itemView.findViewById(R.id.tv_product_name);
            tv_product_price = (TextView) itemView.findViewById(R.id.tv_product_price);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }

    void callApiForAddToCart(final ProductModel myListData, int position, final ViewHolder holder) {
        String userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);
        String storeId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_STORE);
        String url = Config.BASE_URL +
                "shopping_cart_items/addproducttoshoppingcart?customerId=" + userId +
                "&productId=" + myListData.getProductId() +
                "&shoppingCartTypeId=1&quantity=1&attributeControlIds=&rentalStartDate=null&rentalEndDate=null" + "&storeid=" + storeId;
        new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success")) {
                        if (jsonObject.getBoolean("Success")) {
                            if (jsonObject.has("Message") && !jsonObject.isNull("Message")) {
                                String message = jsonObject.getString("Message");
                                Toast.makeText(context, "" + Html.fromHtml(message), Toast.LENGTH_SHORT).show();
                                myListData.setProductInShoppingCart(true);
                                holder.iv_cart_not_added.setVisibility(View.GONE);
                                holder.iv_cart_added.setVisibility(View.VISIBLE);
                                notifyDataSetChanged();

                            }
                        } else {
                            if (jsonObject.has("message") && !jsonObject.isNull("message")) {
                                String message = jsonObject.getString("message");
                                Toast.makeText(context, "" + Html.fromHtml(message), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        }, true).execute();
    }
}