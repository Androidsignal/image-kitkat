package com.testDemo.activites;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.textfield.TextInputLayout;
import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.fragment.ProfileFragment;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.scottyab.showhidepasswordedittext.ShowHidePasswordEditText;

import org.json.JSONException;
import org.json.JSONObject;

public class ChangePasswordActivity extends AppCompatActivity implements View.OnClickListener {

    Activity context = ChangePasswordActivity.this;
    Toolbar toolbar;
    String userId;
    EditText newPassword, confirmPassword;
    Button reset, btnReload;
    EditText oldPassword;
    LinearLayout layoutNoInternet, layoutMain, layoutError;
    TextInputLayout ti_old_password, ti_new_password, ti_confirm_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        findViewById();
        toolbarInit();


        oldPassword.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    ti_old_password.setPasswordVisibilityToggleDrawable(R.drawable.btn_eye);
                } else {
                    ti_old_password.setPasswordVisibilityToggleDrawable(null);
                }
            }
        });


        newPassword.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    ti_new_password.setPasswordVisibilityToggleDrawable(R.drawable.btn_eye);
                } else {
                    ti_new_password.setPasswordVisibilityToggleDrawable(null);
                }
            }
        });


        confirmPassword.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    ti_confirm_password.setPasswordVisibilityToggleDrawable(R.drawable.btn_eye);
                } else {
                    ti_confirm_password.setPasswordVisibilityToggleDrawable(null);
                }
            }
        });
        callApi();
    }

    private void findViewById() {
        toolbar = findViewById(R.id.toolbar);
        ti_confirm_password = findViewById(R.id.ti_confirm_password);
        ti_new_password = findViewById(R.id.ti_new_password);
        ti_old_password = findViewById(R.id.ti_old_password);


    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        oldPassword = findViewById(R.id.et_old_password);
        newPassword = findViewById(R.id.et_new_password);
        confirmPassword = findViewById(R.id.et_confirm_password);
        reset = findViewById(R.id.btn_reset_now);
        layoutMain = findViewById(R.id.layoutMain);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutError = findViewById(R.id.layoutError);
        btnReload = findViewById(R.id.btnReload);
        reset.setOnClickListener(this);
        btnReload.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_reset_now:
                if (resetButton()) {
                    callAPiForChangePassword();
                }
                break;
            case R.id.btnReload:
                callApi();
                break;
        }
    }

    public void callApi() {
        if (!Constants.isCheckInternetCon(context)) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
        }
        userId = SharedPrefsUtils.getStringPreference(ChangePasswordActivity.this, Constants.PREF_USER_ID);
    }

    public void callAPiForChangePassword() {
        JSONHelper jsonHelper = new JSONHelper(ChangePasswordActivity.this, Config.BASE_URL + "customers/changecustomerpassword?OldPassword=" + oldPassword.getText().toString() + "&NewPassword=" + newPassword.getText().toString() + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {

                        String msg = jsonObject.getString("Message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                        finish();

                    } else {
                        String msg = jsonObject.getString("Message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                        /*layoutMain.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);*/
                    }
                } else {
                    Toast.makeText(context, "Password has not been changed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }
            }
        }, true);
        jsonHelper.execute();

    }

    boolean resetButton() {
        if (oldPassword.getText().toString().length() > 0) {
            if (newPassword.getText().toString().length() > 0) {
                if (confirmPassword.getText().toString().length() > 0) {
                    if (newPassword.getText().toString().equals(confirmPassword.getText().toString())) {
                        return true;
                    } else {
                        ti_confirm_password.setPasswordVisibilityToggleDrawable(null);
                        confirmPassword.setError(getResources().getString(R.string.not_match_re_enter_password));
                    }
                } else {
                    ti_confirm_password.setPasswordVisibilityToggleDrawable(null);
                    confirmPassword.setError(getResources().getString(R.string.empty_re_enter_password));
                }
            } else {
                ti_new_password.setPasswordVisibilityToggleDrawable(null);
                newPassword.setError(getResources().getString(R.string.empty_newPassword));
            }
        } else {
            ti_old_password.setPasswordVisibilityToggleDrawable(null);
            oldPassword.setError(getResources().getString(R.string.empty_oldPassword));
        }
        return false;
    }
}
