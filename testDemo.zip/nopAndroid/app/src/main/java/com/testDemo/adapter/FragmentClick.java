package com.testDemo.adapter;

import com.testDemo.activites.SubCategoryRelatedActivityExample;
import com.testDemo.fragment.DynamicFragment;
import com.testDemo.model.FilterDataModel;

public interface FragmentClick{

    void onClickApplyButton(SubCategoryRelatedActivityExample subCategoryRelatedActivityExample,FilterDataModel filter);

    void onClickClear(SubCategoryRelatedActivityExample subCategoryRelatedActivityExample);
}
