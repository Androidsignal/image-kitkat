package com.testDemo.fragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.testDemo.R;
import com.testDemo.activites.CheckOutActivity;
import com.testDemo.adapter.ShippingMethodAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.PaymentMethodModel;
import com.testDemo.model.ShippingMethodModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 */
public class SelectShippingMethod extends Fragment {

    LinearLayout layoutMain;
    LinearLayout layoutLoading;
    LinearLayout layoutNoInternet;
    LinearLayout layoutError;
    Button btnRetry;
    Button btnSave;

    CheckOutActivity checkOutActivity;

    RecyclerView recyclerView;

    ArrayList<ShippingMethodModel> arrayList = new ArrayList<>();
    ShippingMethodAdapter shippingMethodAdapter;
    String userId, storeId;

    public SelectShippingMethod() {
        // Required empty public constructor
    }

    public SelectShippingMethod(CheckOutActivity checkOutActivity) {
        this.checkOutActivity = checkOutActivity;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_select_shipping_method2, container, false);
        findViewByIds(view);
        if (!Constants.isCheckInternetCon(getActivity())) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.VISIBLE);
            setAdapter();
            btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    callApiToInsertPaymentMethod();
                }
            });
        }
        return view;
    }

    void findViewByIds(View v) {
        layoutMain = v.findViewById(R.id.layoutMain);
        layoutLoading = v.findViewById(R.id.layoutLoading);
        layoutNoInternet = v.findViewById(R.id.layoutNoInternet);
        layoutError = v.findViewById(R.id.layoutError);
        btnRetry = v.findViewById(R.id.btnReload);
        btnSave = v.findViewById(R.id.btnSave);
        recyclerView = v.findViewById(R.id.recyclerView);
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.isCheckInternetCon(getActivity())) {
                    layoutMain.setVisibility(View.VISIBLE);
                    layoutNoInternet.setVisibility(View.GONE);
                    setAdapter();
                }
            }
        });

    }

    public void setAdapter() {
        arrayList = new ArrayList<ShippingMethodModel>();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        if (checkOutActivity != null && checkOutActivity.getShippingMethodModelList() != null) {
            arrayList = checkOutActivity.getShippingMethodModelList();
        }
        recyclerView.setVisibility(View.VISIBLE);
        shippingMethodAdapter = new ShippingMethodAdapter(getActivity(), arrayList);
        recyclerView.setAdapter(shippingMethodAdapter);
    }

    void callApiToInsertPaymentMethod() {
        userId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_USER_ID);
        storeId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_SELECTED_STORE);
        ShippingMethodModel model = arrayList.get(Integer.parseInt(shippingMethodAdapter.getSelectedItem()));

        if (model != null && model.getName() != null && model.getShippingRateComputationMethodSystemName() != null) {

            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("shippingoption", model.getName() + "___" + model.getShippingRateComputationMethodSystemName());
            hashMap.put("customerId", userId);

            JSONHelper helper = new JSONHelper(getActivity(), Config.BASE_URL + "checkouts/selectshippingmethod?storeid="+storeId+"shippingoption=", hashMap, new OnAsyncLoader() {
                @Override
                public void OnResult(String result) throws JSONException {
                    if (result != null && !result.isEmpty()) {
                        JSONObject resultJson = new JSONObject(result);
                        if (resultJson.has("Success") && !resultJson.isNull("Success")) {
                            if (resultJson.getString("Success").equals("0")) {
                                JSONObject paymentMethodListObject = resultJson.getJSONObject("PaymentMethodList");
                                if (paymentMethodListObject.has("PaymentMethods") && !paymentMethodListObject.isNull("PaymentMethods")) {
                                    ArrayList<PaymentMethodModel> paymentMethodModelArrayList = new ArrayList<>();
                                    JSONArray jsonArray = paymentMethodListObject.getJSONArray("PaymentMethods");
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        JSONObject object = jsonArray.getJSONObject(i);
                                        PaymentMethodModel model = new PaymentMethodModel();
                                        model.parse(object);
                                        paymentMethodModelArrayList.add(model);
                                    }
                                    checkOutActivity.setPaymentMethodModelList(paymentMethodModelArrayList);
                                    checkOutActivity.setPage(2);
                                }
                            } else {
                                Toast.makeText(checkOutActivity, "Unsuccessful To Save Address", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }, true);
            helper.execute();
        } else {
            Toast.makeText(checkOutActivity, "Something Went Wrong Try Again Later", Toast.LENGTH_SHORT).show();
        }
    }
}
