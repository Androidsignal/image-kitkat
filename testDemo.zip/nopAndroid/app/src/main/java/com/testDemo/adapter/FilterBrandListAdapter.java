package com.testDemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.testDemo.R;
import com.testDemo.model.ManufacturerModel;

import java.util.ArrayList;

public class FilterBrandListAdapter extends RecyclerView.Adapter<FilterBrandListAdapter.ViewHolder> {
    Context context;
    ArrayList<ManufacturerModel> designerCollection;


    public FilterBrandListAdapter(Context context, ArrayList<ManufacturerModel> designerCollection) {
        this.context = context;
        this.designerCollection = designerCollection;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.filter_brand_list_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final ManufacturerModel myListData = designerCollection.get(position);

        holder.tv_brand_title.setText(myListData.getName());
        holder.tv_brand_title_gone.setText(myListData.getName());

        if (myListData.isSelected()) {
            myListData.setSelected(true);
            holder.ll_selected_brand.setVisibility(View.VISIBLE);
            holder.ll_selected_brand_gone.setVisibility(View.GONE);

        } else {
            myListData.setSelected(false);
            holder.ll_selected_brand.setVisibility(View.GONE);
            holder.ll_selected_brand_gone.setVisibility(View.VISIBLE);

        }


        holder.ll_selected_brand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myListData.isSelected()) {
                    myListData.setSelected(false);
                    holder.ll_selected_brand.setVisibility(View.VISIBLE);
                    holder.ll_selected_brand_gone.setVisibility(View.GONE);
                } else {
                    myListData.setSelected(true);
                    holder.ll_selected_brand.setVisibility(View.GONE);
                    holder.ll_selected_brand_gone.setVisibility(View.VISIBLE);

                }
                notifyDataSetChanged();
            }
        });

        holder.ll_selected_brand_gone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myListData.isSelected()) {
                    myListData.setSelected(false);
                    holder.ll_selected_brand.setVisibility(View.VISIBLE);
                    holder.ll_selected_brand_gone.setVisibility(View.GONE);

                } else {
                    myListData.setSelected(true);
                    holder.ll_selected_brand.setVisibility(View.GONE);
                    holder.ll_selected_brand_gone.setVisibility(View.VISIBLE);
//                    ((SubCategoryRelatedActivity) context).setOnClick(position);
                }
                notifyDataSetChanged();
            }
        });

    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_brand_title, tv_brand_title_gone;
        ImageView iv_selected;
        LinearLayout ll_selected_brand, ll_selected_brand_gone;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            tv_brand_title = (TextView) itemView.findViewById(R.id.tv_brand_title);
            tv_brand_title_gone = (TextView) itemView.findViewById(R.id.tv_brand_title_gone);
            iv_selected = (ImageView) itemView.findViewById(R.id.iv_selected);
            ll_selected_brand = (LinearLayout) itemView.findViewById(R.id.ll_selected_brand);
            ll_selected_brand_gone = (LinearLayout) itemView.findViewById(R.id.ll_selected_brand_gone);
        }
    }


}