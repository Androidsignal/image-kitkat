package com.testDemo.adapter;

import android.content.Context;
import android.media.Image;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.model.ProductDetailModel;
import com.testDemo.model.ProductSpecificationModel;

import java.util.ArrayList;

public class AssociatedProductListAdapter extends RecyclerView.Adapter<AssociatedProductListAdapter.ViewHolder> {
    Context context;
    ArrayList<ProductDetailModel> arrayList;
    ProductDetailActivity productDetailActivity;

    public AssociatedProductListAdapter(Context context, ArrayList<ProductDetailModel> arrayList, ProductDetailActivity productDetailActivity) {
        this.context = context;
        this.arrayList = arrayList;
        this.productDetailActivity = productDetailActivity;
    }

    public AssociatedProductListAdapter(Context context, ArrayList<ProductDetailModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.associated_product_row_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        if (arrayList != null) {
            final ProductDetailModel model = arrayList.get(position);
            if (model != null) {
                if (model.getName() != null) {
                    holder.productName.setText(model.getName());
                }
                if (model.getPrice() != null) {
                    holder.price.setText(model.getPrice());
                }

                if (model.getImageList() != null && model.getImageList().size() > 0) {
                    Glide.with(context).load(model.getImageList().get(0).getUrl()).placeholder(R.drawable.image).into(holder.imgProduct);
                }

                holder.cardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (productDetailActivity != null) {
                            productDetailActivity.onClickProduct(model.getId());
                        }
                    }
                });
                holder.imgFavorite.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (productDetailActivity != null) {
                            productDetailActivity.onClickAddToCartInProductList(model.getId());
                        }
                    }
                });
            } else {
                holder.cardView.setVisibility(View.GONE);
            }


        }
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgFavorite;
        ImageView imgProduct;
        TextView productName;
        TextView price;
        CardView cardView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            cardView = itemView.findViewById(R.id.cardView);
            imgFavorite = itemView.findViewById(R.id.image_favorite);
            imgProduct = itemView.findViewById(R.id.iv_product_image);
            productName = itemView.findViewById(R.id.tv_product_name);
            price = itemView.findViewById(R.id.tv_product_price);
        }
    }
}