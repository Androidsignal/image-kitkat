package com.testDemo.model;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

public class AttributeModel implements Parcelable {

    private int id;
    private int mapId;
    private String attributeName;
    private String attributeLabel;
    private int attributeType;
    private boolean isRequired;
    private ArrayList<AttributeValueModel> values = new ArrayList<>();
    private ArrayList<String> valuesInString = new ArrayList<>();

    private String currentValue;
    private File currentFile;
    private AttributeValueModel currentValueModel;
    private ArrayList<AttributeValueModel> selectedValueModelList = new ArrayList<>();

    String dropDownPosition = null;

    String error;
    //this is used to handle selected item on init
    int checked = 0;

    public AttributeModel() {
    }

    protected AttributeModel(Parcel in) {
        id = in.readInt();
        mapId = in.readInt();
        attributeName = in.readString();
        attributeLabel = in.readString();
        attributeType = in.readInt();
        isRequired = in.readByte() != 0;
        valuesInString = in.createStringArrayList();
        currentValue = in.readString();
        dropDownPosition = in.readString();
        error = in.readString();
        checked = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(mapId);
        dest.writeString(attributeName);
        dest.writeString(attributeLabel);
        dest.writeInt(attributeType);
        dest.writeByte((byte) (isRequired ? 1 : 0));
        dest.writeStringList(valuesInString);
        dest.writeString(currentValue);
        dest.writeString(dropDownPosition);
        dest.writeString(error);
        dest.writeInt(checked);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<AttributeModel> CREATOR = new Creator<AttributeModel>() {
        @Override
        public AttributeModel createFromParcel(Parcel in) {
            return new AttributeModel(in);
        }

        @Override
        public AttributeModel[] newArray(int size) {
            return new AttributeModel[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMapId() {
        return mapId;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public String getAttributeLabel() {
        return attributeLabel;
    }

    public void setAttributeLabel(String attributeLabel) {
        this.attributeLabel = attributeLabel;
    }

    public int getAttributeType() {
        return attributeType;
    }

    public void setAttributeType(int attributeType) {
        this.attributeType = attributeType;
    }

    public boolean isRequired() {
        return isRequired;
    }

    public void setRequired(boolean required) {
        isRequired = required;
    }

    public ArrayList<AttributeValueModel> getValues() {
        return values;
    }

    public void setValues(ArrayList<AttributeValueModel> values) {
        this.values = values;
    }

    public String getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(String currentValue) {
        this.currentValue = currentValue;
    }

    public AttributeValueModel getCurrentValueModel() {
        return currentValueModel;
    }

    public void setCurrentValueModel(AttributeValueModel currentValueModel) {
        this.currentValueModel = currentValueModel;
    }

    public ArrayList<String> getValuesInString() {
        return valuesInString;
    }

    public void setValuesInString(ArrayList<String> valuesInString) {
        this.valuesInString = valuesInString;
    }

    public ArrayList<AttributeValueModel> getSelectedValueModelList() {
        return selectedValueModelList;
    }

    public void setSelectedValueModelList(ArrayList<AttributeValueModel> selectedValueModelList) {
        this.selectedValueModelList = selectedValueModelList;
    }

    public File getCurrentFile() {
        return currentFile;
    }

    public void setCurrentFile(File currentFile) {
        this.currentFile = currentFile;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getDropDownPosition() {
        return dropDownPosition;
    }

    public void setDropDownPosition(String dropDownPosition) {
        this.dropDownPosition = dropDownPosition;
    }

    public int getChecked() {
        return checked;
    }

    public void setChecked(int checked) {
        this.checked = checked;
    }

    @Override
    public String toString() {
        return "AttributeModel{" +
                "id=" + id +
                ", mapId=" + mapId +
                ", attributeName='" + attributeName + '\'' +
                ", attributeLabel='" + attributeLabel + '\'' +
                ", attributeType=" + attributeType +
                ", isRequired=" + isRequired +
                ", values=" + values +
                ", valuesInString=" + valuesInString +
                ", currentValue='" + currentValue + '\'' +
                ", currentFile=" + currentFile +
                ", currentValueModel=" + currentValueModel +
                ", selectedValueModelList=" + selectedValueModelList +
                ", error='" + error + '\'' +
                '}';
    }

    public void parse(JSONObject object) throws JSONException {
        if (checkForNull("product_attribute_id", object)) {
            id = object.getInt("product_attribute_id");
        }
        if (checkForNull("id", object)) {
            mapId = object.getInt("id");
        }
        if (checkForNull("text_prompt", object)) {
            attributeLabel = object.getString("text_prompt");
        }
        if (checkForNull("product_attribute_name", object)) {
            attributeName = object.getString("product_attribute_name");
        }
        if (checkForNull("is_required", object)) {
            isRequired = object.getBoolean("is_required");
        }

        if (checkForNull("attribute_control_type_id", object)) {
            attributeType = object.getInt("attribute_control_type_id");
        }

        if (checkForNull("default_value", object)) {
            currentValue = object.getString("default_value");
        }

        if (checkForNull("attribute_values", object)) {
            JSONArray attributeValues = object.getJSONArray("attribute_values");
            values = new ArrayList<>();
            for (int i = 0; i < attributeValues.length(); i++) {
                JSONObject jsonObject = attributeValues.getJSONObject(i);
                AttributeValueModel model = new AttributeValueModel();
                model.parse(jsonObject);
                if (model.isPreSelected) {
                    currentValueModel = model;
                    selectedValueModelList.add(model);
                    dropDownPosition = String.valueOf(i);
                }
                values.add(model);
                valuesInString.add(model.name);
            }
        }
    }

    public void parseForAddress(JSONObject object) throws JSONException {
        if (checkForNull("Id", object)) {
            id = object.getInt("Id");
        }
        if (checkForNull("Name", object)) {
            attributeLabel = object.getString("Name");
        }
        if (checkForNull("Name", object)) {
            attributeName = object.getString("Name");
        }
        if (checkForNull("IsRequired", object)) {
            isRequired = object.getBoolean("IsRequired");
        }

        if (checkForNull("AttributeControlType", object)) {
            attributeType = object.getInt("AttributeControlType");
        }

        if (checkForNull("DefaultValue", object)) {
            currentValue = object.getString("DefaultValue");
        }

        if (checkForNull("Values", object)) {
            JSONArray attributeValues = object.getJSONArray("Values");
            values = new ArrayList<>();
            for (int i = 0; i < attributeValues.length(); i++) {
                JSONObject jsonObject = attributeValues.getJSONObject(i);
                AttributeValueModel model = new AttributeValueModel();
                model.parseForAddress(jsonObject);
                if (model.isPreSelected) {
                    currentValueModel = model;
                    selectedValueModelList.add(model);
                    dropDownPosition = String.valueOf(i);
                }
                values.add(model);
                valuesInString.add(model.name);
            }
        }
    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }


    public void parseForCartItem(JSONObject object) throws JSONException {
        if (checkForNull("Id", object)) {
            id = object.getInt("Id");
        }
        if (checkForNull("Name", object)) {
            attributeLabel = object.getString("Name");
        }
        if (checkForNull("Name", object)) {
            attributeName = object.getString("Name");
        }
        if (checkForNull("IsRequired", object)) {
            isRequired = object.getBoolean("IsRequired");
        }

        if (checkForNull("AttributeControlType", object)) {
            attributeType = object.getInt("AttributeControlType");
        }

        if (checkForNull("DefaultValue", object)) {
            currentValue = object.getString("DefaultValue");
        }

        if (checkForNull("Values", object)) {
            JSONArray attributeValues = object.getJSONArray("Values");
            values = new ArrayList<>();
            for (int i = 0; i < attributeValues.length(); i++) {
                JSONObject jsonObject = attributeValues.getJSONObject(i);
                AttributeValueModel model = new AttributeValueModel();
                model.parseForAddress(jsonObject);
                if (model.isPreSelected) {
                    currentValueModel = model;
                    selectedValueModelList.add(model);
                    dropDownPosition = String.valueOf(i);
                }
                values.add(model);
                valuesInString.add(model.name);
            }
        }
    }
}
