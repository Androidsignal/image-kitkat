package com.testDemo.model.AddressModels;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONException;
import org.json.JSONObject;

public class CountryListModel implements Parcelable {
    boolean isDisable;
    boolean isSelected;
    String strText;
    String strValue;

    public CountryListModel() {
    }

    protected CountryListModel(Parcel in) {
        isDisable = in.readByte() != 0;
        isSelected = in.readByte() != 0;
        strText = in.readString();
        strValue = in.readString();
    }

    public static final Creator<CountryListModel> CREATOR = new Creator<CountryListModel>() {
        @Override
        public CountryListModel createFromParcel(Parcel in) {
            return new CountryListModel(in);
        }

        @Override
        public CountryListModel[] newArray(int size) {
            return new CountryListModel[size];
        }
    };

    public boolean isDisable() {
        return isDisable;
    }

    public void setDisable(boolean disable) {
        isDisable = disable;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getStrText() {
        return strText;
    }

    public void setStrText(String strText) {
        this.strText = strText;
    }

    public String getStrValue() {
        return strValue;
    }

    public void setStrValue(String strValue) {
        this.strValue = strValue;
    }

    @Override
    public String toString() {
        return "CountryListModel{" +
                "isDisable=" + isDisable +
                ", isSelected=" + isSelected +
                ", strText='" + strText + '\'' +
                ", strValue='" + strValue + '\'' +
                '}';
    }



    public void parse(JSONObject object) throws JSONException {
        if(object != null){
            if(checkForNull("Disabled",object)){
                isDisable = object.getBoolean("Disabled");
            }
            if(checkForNull("Selected",object)){
                isSelected = object.getBoolean("Selected");
            }
            if(checkForNull("Text",object)){
                strText = object.getString("Text");
            }
            if(checkForNull("Value",object)){
                strValue = object.getString("Value");
            }
        }
    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte((byte) (isDisable ? 1 : 0));
        dest.writeByte((byte) (isSelected ? 1 : 0));
        dest.writeString(strText);
        dest.writeString(strValue);
    }
}
