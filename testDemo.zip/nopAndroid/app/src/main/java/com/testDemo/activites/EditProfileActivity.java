package com.testDemo.activites;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputLayout;
import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.fragment.ProfileFragment;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.global.Utility;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.UserModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class EditProfileActivity extends AppCompatActivity implements View.OnClickListener {

    Toolbar toolbar;
    CircleImageView circleImageView;
    ImageView img_select;
    EditText editFirstName, editEmail;
    Button btn_save, btnReload;
    TextInputLayout txtInputFirstName, txtInputEmail;
    LinearLayout layoutNoInternet, layoutError, layoutMain, layoutLoading;
    String customerId;
    UserModel userModel;
    String firstName, lastName, imageUrl, email;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String userChoosenTask;
    Bitmap bitmap;
    String image = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        findViewById();
        toolbarInit();
        callApi();
    }

    private void callApi() {
        if (Constants.isCheckInternetCon(EditProfileActivity.this)) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            getUserInformationList();
        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }
    }

    public void findViewById() {
        toolbar = findViewById(R.id.toolbar);
        btnReload = findViewById(R.id.btnReload);
        circleImageView = findViewById(R.id.circleImageView);
        img_select = findViewById(R.id.img_select);
        editFirstName = findViewById(R.id.editFirstName);
        txtInputFirstName = findViewById(R.id.txtInputFirstName);
        txtInputEmail = findViewById(R.id.txtInputEmail);
        editEmail = findViewById(R.id.editEmail);
        btn_save = findViewById(R.id.btn_save);
        layoutMain = findViewById(R.id.layoutMain);
        layoutError = findViewById(R.id.layoutError);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutLoading = findViewById(R.id.layoutLoading);
        btn_save.setOnClickListener(this);
        btnReload.setOnClickListener(this);
        img_select.setOnClickListener(this);


    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void getUserInformationList() {
        customerId = SharedPrefsUtils.getStringPreference(EditProfileActivity.this, Constants.PREF_USER_ID);
        JSONHelper helper = new JSONHelper(EditProfileActivity.this, Config.BASE_URL + "customers/" + customerId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("customers") && !jsonObject.isNull("customers")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("customers");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            if (obj.has("first_name") && !obj.isNull("first_name")) {
                                firstName = obj.getString("first_name");
                            }
                            if (obj.has("last_name") && !obj.isNull("last_name")) {
                                lastName = obj.getString("last_name");

                            }
                            if (obj.has("email") && !obj.isNull("email")) {
                                email = obj.getString("email");

                            }
                            if (obj.has("avatar_url") && !obj.isNull("avatar_url")) {
                                imageUrl = obj.getString("avatar_url");
                            }

                        }

                        editFirstName.setText(firstName);
                        editEmail.setText(email);
                        Glide.with(EditProfileActivity.this).load(imageUrl).placeholder(R.drawable.image).into(circleImageView);

                    }
                } else {

                    Toast.makeText(EditProfileActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
            }
        }, false);
        helper.execute();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_save:
                if (validateForm()) {
                    callApiForUpdateProfile();
                }
                break;
            case R.id.img_select:
                selectImage();
                break;
            case R.id.btnReload:
                callApi();
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (userChoosenTask.equals("Take Photo"))
                        cameraIntent();
                    else if (userChoosenTask.equals("Choose from Library"))
                        galleryIntent();
                } else {
                    //code for deny
                }
                break;
        }
    }

    private void selectImage() {
        final CharSequence[] items = {"Take Photo", "Choose from Library",
                "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(EditProfileActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result = Utility.checkPermission(EditProfileActivity.this);
                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";
                    if (result)
                        cameraIntent();
                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask = "Choose from Library";
                    if (result)
                        galleryIntent();
                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }

    }

    private void onCaptureImageResult(Intent data) {
        bitmap = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 20, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Glide.with(EditProfileActivity.this).load(bitmap).placeholder(R.drawable.image).into(circleImageView);
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {

        if (data != null) {
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Glide.with(EditProfileActivity.this).load(bitmap).placeholder(R.drawable.image).into(circleImageView);
    }


    public void callApiForUpdateProfile() {

        if (bitmap != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, baos);
            byte[] b = baos.toByteArray();
            image = Base64.encodeToString(b, Base64.DEFAULT);
        }

        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("FirstName", editFirstName.getText().toString());
        hashMap.put("fileString", image);
        hashMap.put("customerId", customerId);

        JSONHelper helper = new JSONHelper(EditProfileActivity.this, Config.BASE_URL + "customers/customerinfo", hashMap, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("errorcode") && !jsonObject.isNull("errorcode") && jsonObject.getString("errorcode").equals("0")) {
                        userModel = new UserModel();
                        if (jsonObject.has("id") && jsonObject.isNull("id")) {
                            userModel.setId(jsonObject.getString("id"));
                        }
                        if (jsonObject.has("first_name") && jsonObject.isNull("first_name")) {
                            userModel.setName(jsonObject.getString("first_name"));
                        }
                        if (jsonObject.has("avatar_url") && jsonObject.isNull("avatar_url")) {
                            userModel.setImageUrl(jsonObject.getString("avatar_url"));
                        }

                        String msg = jsonObject.getString("message");
                        Toast.makeText(EditProfileActivity.this, msg, Toast.LENGTH_SHORT).show();

                        setResult(EditProfileActivity.RESULT_OK);
                        finish();


                    } else {
                        String msg = jsonObject.getString("message");
                        Toast.makeText(EditProfileActivity.this, msg, Toast.LENGTH_SHORT).show();
                    }
                } else {

                    Toast.makeText(EditProfileActivity.this, "customer updated Unsuccessfully", Toast.LENGTH_SHORT).show();
                }

            }
        }, true);
        helper.execute();
    }

    boolean validateForm() {
        if (!editFirstName.getText().toString().isEmpty()) {
            return true;
        } else {
            editFirstName.setError(getResources().getString(R.string.strErrorEmptyName));
        }

        return false;
    }

}
