package com.testDemo.fragment;


import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.testDemo.R;
import com.testDemo.activites.CartScreen;
import com.testDemo.activites.ProductListActivity;
import com.testDemo.activites.SearchAutoCompleteActivity;
import com.testDemo.activites.SubCategoryActivity;
import com.testDemo.adapter.CategoryListAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.CategoryModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 */
public class ExploreFragment extends Fragment implements View.OnClickListener {


    private RecyclerView rcv_category_list;

   private ArrayList<CategoryModel> categoryModelList = new ArrayList<>();
   private ArrayList<CategoryModel> categoryList = new ArrayList<>();

    private CategoryListAdapter categoryListAdapter;
    private ImageView iv_toolbar_btn_cart,iv_toolbar_search_button;

    private LinearLayout layoutMain, layoutNoInternet, layoutLoading, layoutError, layoutRecord, layoutEmpty;
    private Button btnReload;

    EditText editSearch;

    SwipeRefreshLayout swipeRefresh;

    private final int REQ_CODE_SPEECH_INPUT = 100;
    String storeId;

    public static ExploreFragment newInstance() {
        return new ExploreFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_explore, container, false);
        findViewById(view);
        if (!Constants.isCheckInternetCon(getActivity())) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            storeId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_SELECTED_STORE);
            callApiToGetCategory();
        }

        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                search(s.toString());
            }
        });

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (Constants.isCheckInternetCon(getActivity())) {
                    swipeRefresh.setRefreshing(true);
                    callApiToGetCategory();
                }
            }
        });
        return view;
    }

    private void search(String s) {
        if (!s.isEmpty()) {
            ArrayList<CategoryModel> searchList = new ArrayList<>();
            for (CategoryModel d : categoryModelList) {
                if (d.getName() != null && d.getName().toLowerCase().contains(s.toLowerCase())) {
                    searchList.add(d);
                }
            }
            if (searchList != null && searchList.size() > 0) {
                categoryListAdapter.updateList(searchList);
                layoutEmpty.setVisibility(View.GONE);
                rcv_category_list.setVisibility(View.VISIBLE);
            } else {
                layoutEmpty.setVisibility(View.VISIBLE);
                rcv_category_list.setVisibility(View.GONE);
            }
        } else {
            if (categoryModelList != null && categoryModelList.size() > 0) {
                categoryListAdapter.updateList(categoryModelList);
                layoutEmpty.setVisibility(View.GONE);
                rcv_category_list.setVisibility(View.VISIBLE);
            } else {
                layoutEmpty.setVisibility(View.VISIBLE);
                rcv_category_list.setVisibility(View.GONE);
            }

        }
    }

    private void callApiToGetCategory() {
        if(categoryList!=null){
            categoryList.clear();
            categoryModelList.clear();
        }
        try {
            JSONHelper helper = new JSONHelper(getActivity(), Config.BASE_URL + "categories?storeid=" + storeId, null, new OnAsyncLoader() {
                @Override
                public void OnResult(String result) throws JSONException {
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.has("categories") && !jsonObject.isNull("categories")) {
                            JSONArray jsonArray = jsonObject.getJSONArray("categories");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                CategoryModel model = new CategoryModel();
                                JSONObject object = jsonArray.getJSONObject(i);
                                model.parse(object);
                                categoryList.add(model);
                                if (object.getString("parent_category_id").equals("0")) {
                                    model.parse(object);
                                    categoryModelList.add(model);
                                }
                            }

                        } else {
                            layoutLoading.setVisibility(View.GONE);
                            layoutError.setVisibility(View.VISIBLE);
                        }
                    } else {
                        layoutLoading.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);
                    }
                    setDataInList();
                }
            }, false);
            helper.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void findViewById(View view) {
        rcv_category_list = view.findViewById(R.id.rcv_category_list);
        iv_toolbar_btn_cart = view.findViewById(R.id.iv_toolbar_btn_cart);
        iv_toolbar_search_button = view.findViewById(R.id.iv_toolbar_search_button);
        iv_toolbar_search_button.setOnClickListener(this);
        iv_toolbar_btn_cart.setOnClickListener(this);
        layoutMain = view.findViewById(R.id.layoutMain);
        layoutNoInternet = view.findViewById(R.id.layoutNoInternet);
        layoutLoading = view.findViewById(R.id.layoutLoading);
        btnReload = view.findViewById(R.id.btnReload);
        layoutError = view.findViewById(R.id.layoutError);
        editSearch = view.findViewById(R.id.editSearch);
        layoutRecord = view.findViewById(R.id.layoutRecord);
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
        layoutEmpty = view.findViewById(R.id.layoutEmpty);

        btnReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().recreate();
            }
        });
        layoutRecord.setOnClickListener(this);

    }

    private void setDataInList() {
        swipeRefresh.setRefreshing(false);
        layoutMain.setVisibility(View.VISIBLE);
        layoutLoading.setVisibility(View.GONE);
        /*LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL); //
        rcv_category_list.setLayoutManager(linearLayoutManager);*/
        rcv_category_list.setLayoutManager(new GridLayoutManager(getActivity(),3));


        categoryListAdapter = new CategoryListAdapter(getActivity(), categoryModelList, this);
        rcv_category_list.setAdapter(categoryListAdapter);
        categoryListAdapter.notifyDataSetChanged();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_toolbar_btn_cart:
                startActivity(new Intent(getActivity(), CartScreen.class));
                break;
            case R.id.layoutRecord:
                promptSpeechInput();
                break;
            case R.id.iv_toolbar_search_button:
                startActivity(new Intent(getActivity(), SearchAutoCompleteActivity.class));
                break;
        }
    }

    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say Something");
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getActivity(), "Sorry! Your device doesn't support speech input", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_CODE_SPEECH_INPUT) {
            if (resultCode == RESULT_OK && null != data) {

                ArrayList<String> result = data
                        .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                editSearch.setText(result.get(0));
            }
        }
    }


    public void onclickCategory(CategoryModel model, int position) {
        int i;
        ArrayList<CategoryModel> list = new ArrayList<>();
        for (i = 0; i < categoryList.size(); i++) {
            if (categoryList.get(i).getParentCategoryId().equals(model.getId())) {
                list.add(categoryList.get(i));
            }
        }
        if (list.size() != 0) {
            Intent intent = new Intent(getActivity(), SubCategoryActivity.class);
            intent.putExtra(Constants.CATEGORY_LIST, list);
            intent.putExtra(Constants.PARENT_CATEGORY_ID, list.get(position).getParentCategoryId());
            intent.putExtra(Constants.CATEGORY_NAME, model.getName());
            startActivity(intent);
        } else {
            /*// TODO: 18/10/2019 comment code for sometime
            Intent intent = new Intent(getActivity(), ProductListActivity.class);
            try {
                intent.putExtra(Constants.INTENT_FOR_ID, categoryModelList.get(position).getId());
                intent.putExtra(Constants.INTENT_FOR_TITLE, categoryModelList.get(position).getName());
                intent.putExtra(Constants.IF_FROM_BRAND_LIST,false);
            } catch (Exception e) {
                e.printStackTrace();
            }
            startActivity(intent);*/
//            getActivity().startActivity(intent);
            Intent intent = new Intent(getActivity(), ProductListActivity.class);
            intent.putExtra(Constants.INTENT_FOR_TITLE, categoryModelList.get(position).getName());
            intent.putExtra(Constants.INTENT_FOR_ID, categoryModelList.get(position).getId());
            intent.putExtra(Constants.IF_FROM_BRAND_LIST, false);
            startActivity(intent);
        }

    }
}
