package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.testDemo.R;
import com.testDemo.adapter.OrderAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.OrderModel;
import com.testDemo.model.ProductModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MyOrderActivity extends AppCompatActivity implements View.OnClickListener {

    Toolbar toolbar;
    RecyclerView rcv_my_order;
    LinearLayout layoutMain, layoutLoading, layoutNoInternet, ll_no_order;
    String userId;
    ArrayList<OrderModel> orderList = new ArrayList<OrderModel>();
    OrderAdapter orderAdapter;
    OrderModel orderModel;
    Button btnReload;
    String currencyId,storeId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order);
        findViewById();
        toolbarInit();
        callApi();
    }

    private void findViewById() {
        layoutMain = findViewById(R.id.layoutMain);
        layoutLoading = findViewById(R.id.layoutLoading);
        ll_no_order = findViewById(R.id.ll_no_order);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        btnReload = findViewById(R.id.btnReload);
        userId = SharedPrefsUtils.getStringPreference(MyOrderActivity.this, Constants.PREF_USER_ID);
        rcv_my_order = findViewById(R.id.rcv_my_order);
        LinearLayoutManager linear_rcv_brand = new LinearLayoutManager(this);
        linear_rcv_brand.setOrientation(LinearLayoutManager.VERTICAL); // set Horizontal Orientation
        rcv_my_order.setLayoutManager(linear_rcv_brand);
        btnReload.setOnClickListener(this);
    }

    private void toolbarInit() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    public void callApi() {
        if (Constants.isCheckInternetCon(MyOrderActivity.this)) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            currencyId = SharedPrefsUtils.getStringPreference(MyOrderActivity.this, Constants.PREF_SELECTED_CURRENCY);
            storeId = SharedPrefsUtils.getStringPreference(MyOrderActivity.this, Constants.PREF_SELECTED_STORE);
            callApiForOrderList();

        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }
    }

    public void callApiForOrderList() {
        JSONHelper jsonHelper = new JSONHelper(MyOrderActivity.this, Config.BASE_URL + "orders?customer_id=" + userId + "&Cid=" + currencyId + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("orders") && !jsonObject.isNull("orders")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("orders");
                        orderList = new ArrayList<OrderModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            orderModel = new OrderModel();
                            orderModel.parseForOrderList(obj);
                            orderList.add(orderModel);
                        }
                    }
                } else {
                    Toast.makeText(MyOrderActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
                ifOrderIsEmpty();
                orderAdapter = new OrderAdapter(MyOrderActivity.this, orderList);
                rcv_my_order.setAdapter(orderAdapter);
            }
        }, false);
        jsonHelper.execute();
    }

    private void ifOrderIsEmpty() {
        if (orderList != null && orderList.size() > 0) {
            ll_no_order.setVisibility(View.GONE);
            layoutMain.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.GONE);
            ll_no_order.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnReload:
                callApi();
                break;
        }
    }
}
