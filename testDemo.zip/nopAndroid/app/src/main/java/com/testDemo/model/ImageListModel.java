package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

public class ImageListModel {
    int id;
    String url;
    boolean isVideo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isVideo() {
        return isVideo;
    }

    public void setVideo(boolean video) {
        isVideo = video;
    }

    @Override
    public String toString() {
        return "ImageListModel{" +
                "id=" + id +
                ", url='" + url + '\'' +
                ", isVideo=" + isVideo +
                '}';
    }

    public void parse(JSONObject object) throws JSONException {
        if(checkForNull("id",object)){
            id = object.getInt("id");
        }
        if(checkForNull("src",object)){
            url = object.getString("src");
        }
    }

    boolean checkForNull(String key, JSONObject object){
        return  object!= null && object.has(key) && !object.isNull(key);
    }
}
