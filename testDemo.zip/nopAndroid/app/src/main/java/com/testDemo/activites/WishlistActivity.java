package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.testDemo.R;
import com.testDemo.adapter.WishlistProductAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class WishlistActivity extends AppCompatActivity implements View.OnClickListener {

    String TAG = getClass().getSimpleName();
    Activity context = WishlistActivity.this;


    LinearLayout layoutMain;
    LinearLayout layoutLoading;
    LinearLayout layoutNoInternet;
    LinearLayout layoutError;
    LinearLayout layoutNoDataFound;

    Button btnReload;

    ArrayList<ProductModel> wishList = new ArrayList<>();

    RecyclerView recyclerViewForWishList;

    LinearLayoutManager linearLayoutManager;

    WishlistProductAdapter wishlistProductAdapter;

    Toolbar toolbar;

    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);

        userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);

        findViewById();

        setUpToolbar();

        if (Constants.isCheckInternetCon(context)) {
            layoutNoInternet.setVisibility(View.GONE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            callApiToGetWishlistProducts();
        } else {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        }

    }

    private void callApiToGetWishlistProducts() {

        String url = Config.BASE_URL+"shopping_cart_items/getwishlistbycustomerId?customerId="+userId;

        JSONHelper jsonHelper=new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {

                if (result!=null && !result.isEmpty())
                {
                    Log.d(TAG,result);

                    JSONObject jsonObject=new JSONObject(result);
                    if (jsonObject.has("Wishlist") && !jsonObject.isNull("Wishlist")) {
                        JSONObject wishListObj = jsonObject.getJSONObject("Wishlist");
                        if (wishListObj.has("Items") && !wishListObj.isNull("Items")) {
                            {
                                wishList = new ArrayList<>();
                                JSONArray jsonArray = wishListObj.getJSONArray("Items");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject obj = jsonArray.getJSONObject(i);
                                    ProductModel productModel = new ProductModel();
                                    productModel.parseForWishList(obj);
                                    wishList.add(productModel);
                                }

                                setDataForRecyclerView();
                            }
                        }
                    }
                    else {
                        layoutError.setVisibility(View.VISIBLE);
                        layoutMain.setVisibility(View.GONE);
                        layoutLoading.setVisibility(View.GONE);
                    }

                }else {
                    layoutError.setVisibility(View.VISIBLE);
                    layoutMain.setVisibility(View.GONE);
                    layoutLoading.setVisibility(View.GONE);
                }

            }
        },false);

        jsonHelper.execute();


    }

    void findViewById()
    {
        toolbar = findViewById(R.id.toolbar);

        layoutMain = findViewById(R.id.layoutMain);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutError = findViewById(R.id.layoutError);
        layoutNoDataFound = findViewById(R.id.layoutNoDataFound);
        recyclerViewForWishList = findViewById(R.id.recyclerViewForWishList);

        linearLayoutManager = new LinearLayoutManager(context);
        recyclerViewForWishList.setLayoutManager(linearLayoutManager);
        btnReload = findViewById(R.id.btnReload);

        btnReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.isCheckInternetCon(context)) {
                    layoutNoInternet.setVisibility(View.GONE);
                    layoutMain.setVisibility(View.VISIBLE);
                    layoutLoading.setVisibility(View.VISIBLE);
                    recyclerViewForWishList.setVisibility(View.GONE);
//                    callApiToGetProducts();
                }
            }
        });

    }

    void setUpToolbar() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    void setDataForRecyclerView()
    {
        layoutLoading.setVisibility(View.GONE);
        layoutMain.setVisibility(View.VISIBLE);

        if (wishList.size()==0)
        {
            layoutLoading.setVisibility(View.GONE);
            layoutMain.setVisibility(View.GONE);
            layoutNoDataFound.setVisibility(View.VISIBLE);
        }

        if (wishlistProductAdapter == null)
        {
            wishlistProductAdapter = new WishlistProductAdapter(context,wishList,WishlistActivity.this);
            recyclerViewForWishList.setAdapter(wishlistProductAdapter);
        }
    }

    @Override
    public void onClick(View v) {

    }

    public void onClickItem(int position)
    {
        String pid = wishList.get(position).getProductId();

        if (pid != null && !pid.isEmpty())
        {
            wishList.remove(position);
            String url = Config.BASE_URL+"shopping_cart_items/deleteshoppingcartorwishlistitem/"+pid;

            JSONHelper jsonHelper=new JSONHelper(context, url, null, new OnAsyncLoader() {
                @Override
                public void OnResult(String result) throws JSONException {

                    JSONObject jsonObject=new JSONObject(result);

                    Log.d(TAG, String.valueOf(jsonObject));

                }
            },true);

            jsonHelper.execute();
        }
    }
}
