package com.testDemo.adapter;

import android.content.Context;
import android.preference.PreferenceManager;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.ShippingAddressesActivity;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AddressModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.UserModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AddressAdapter extends RecyclerView.Adapter<AddressAdapter.ViewHolder> {
    Context context;
    ArrayList<AddressModel> designerCollection;
    String address, address2;
    String customerId;
    ShippingAddressesActivity.OnDelete onDelete;
    ShippingAddressesActivity shippingAddressesActivity;

    public AddressAdapter(Context context, ArrayList<AddressModel> designerCollection, String customerId, ShippingAddressesActivity.OnDelete onDelete, ShippingAddressesActivity shippingAddressesActivity) {
        this.context = context;
        this.designerCollection = designerCollection;
        this.customerId = customerId;
        this.onDelete = onDelete;
        this.shippingAddressesActivity = shippingAddressesActivity;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.addresses_row_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final AddressModel myListData = designerCollection.get(position);
        if(myListData != null) {

            if (myListData.getAddressUserName() != null && !myListData.getAddressUserName().isEmpty()) {
                holder.tv_address_user_name.setVisibility(View.VISIBLE);
                holder.tv_address_user_name.setText(myListData.getAddressUserName());
            }

            if (myListData.getAddressUserEmail() != null && !myListData.getAddressUserEmail().isEmpty()) {
                holder.tv_address_user_email.setVisibility(View.VISIBLE);
                holder.tv_address_user_email.setText(myListData.getAddressUserEmail());
            }
            if (myListData.isPhoneEnabled()) {
                if (!myListData.getAddressUserPhoneNumber().isEmpty()) {
                    holder.tv_address_user_phone.setVisibility(View.VISIBLE);
                    holder.tv_address_user_phone.setText(myListData.getAddressUserPhoneNumber());
                }
            }

            if (myListData.isCityEnabled()) {
                if (!myListData.getAddressUserCity().isEmpty()) {
                    holder.tv_address_user_city.setVisibility(View.VISIBLE);
                    holder.tv_address_user_city.setText(myListData.getAddressUserCity());
                }
            }

            if (myListData.getAddressUserCountry() != null && !myListData.getAddressUserCountry().isEmpty()) {
                holder.tv_address_user_country.setVisibility(View.VISIBLE);
                holder.tv_address_user_country.setText(myListData.getAddressUserCountry());
            }
            if (myListData.isCountyEnabled()) {
                if (!myListData.getAddressUserCounty().isEmpty()) {
                    holder.tv_address_user_county.setVisibility(View.VISIBLE);
                    holder.tv_address_user_county.setText(myListData.getAddressUserCounty());
                }
            }

            if (myListData.getAddressUserState() != null && !myListData.getAddressUserState().isEmpty()) {
                holder.tv_address_user_state.setVisibility(View.VISIBLE);
                holder.tv_address_user_state.setText(myListData.getAddressUserState());
            }


            if (myListData.isStreetAddressEnabled()) {
                address = myListData.getAddressUserAddress1();
            }
            if (myListData.isStreetAddress2Enabled()) {
                address2 = myListData.getAddressUserAddress2();
            }

            if (myListData.isZipPostalCodeEnabled()) {
                holder.tv_address_user_address1.setText(address + "," + address2 + "," + myListData.getAddressUserPinCode());
            }

            if (myListData.getFormattedCustomAddressAttributes() != null) {
                if (!myListData.getFormattedCustomAddressAttributes().isEmpty()) {
                    holder.addressAttribute.setVisibility(View.VISIBLE);
                    holder.addressAttribute.setText(Html.fromHtml(myListData.getFormattedCustomAddressAttributes()));
                }
            }

            holder.ll_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        onDelete.OnDelete(position);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });

            holder.ll_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    shippingAddressesActivity.onClickEditAddress(position);
                }
            });
        }

    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_address_user_name, tv_address_user_email, tv_address_user_phone, tv_address_user_address1, tv_address_user_city, tv_address_user_country, addressAttribute;
        LinearLayout ll_delete, ll_edit;
        TextView tv_address_user_county;
        TextView tv_address_user_state;

        public ViewHolder(View itemView) {
            super(itemView);

            this.setIsRecyclable(false);

            tv_address_user_name = (TextView) itemView.findViewById(R.id.tv_address_user_name);
            tv_address_user_email = (TextView) itemView.findViewById(R.id.tv_address_user_email);
            tv_address_user_phone = (TextView) itemView.findViewById(R.id.tv_address_user_phone);
            tv_address_user_address1 = (TextView) itemView.findViewById(R.id.tv_address_user_address1);
            tv_address_user_city = (TextView) itemView.findViewById(R.id.tv_address_user_city);
            tv_address_user_country = (TextView) itemView.findViewById(R.id.tv_address_user_country);
            addressAttribute = itemView.findViewById(R.id.addressAttribute);
            ll_delete = (LinearLayout) itemView.findViewById(R.id.ll_delete);
            ll_edit = (LinearLayout) itemView.findViewById(R.id.ll_edit);
            tv_address_user_county = itemView.findViewById(R.id.tv_address_user_county);
            tv_address_user_state = itemView.findViewById(R.id.tv_address_user_state);

        }
    }
}