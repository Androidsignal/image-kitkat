package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.testDemo.R;

public class ResetPasswordDoneActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn_reset_now;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password_done);
        findViewById();
    }

    private void findViewById() {
        btn_reset_now = findViewById(R.id.btn_reset_now);
        btn_reset_now.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_reset_now:
                startActivity(new Intent(this, OTPActivity.class));
                finish();
                break;
        }
    }
}
