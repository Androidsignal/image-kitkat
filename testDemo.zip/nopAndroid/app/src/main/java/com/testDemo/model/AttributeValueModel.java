package com.testDemo.model;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONException;
import org.json.JSONObject;

public class AttributeValueModel implements Parcelable {

    int id;
    String name;
    String cost;
    boolean isPreSelected = false;

    String productImageId;
    String imageUrl;

    String color;

    public AttributeValueModel() {
    }

    protected AttributeValueModel(Parcel in) {
        id = in.readInt();
        name = in.readString();
        cost = in.readString();
        isPreSelected = in.readByte() != 0;
        productImageId = in.readString();
        imageUrl = in.readString();
        color = in.readString();
    }

    public static final Creator<AttributeValueModel> CREATOR = new Creator<AttributeValueModel>() {
        @Override
        public AttributeValueModel createFromParcel(Parcel in) {
            return new AttributeValueModel(in);
        }

        @Override
        public AttributeValueModel[] newArray(int size) {
            return new AttributeValueModel[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public boolean isPreSelected() {
        return isPreSelected;
    }

    public void setPreSelected(boolean preSelected) {
        isPreSelected = preSelected;
    }

    public String getProductImageId() {
        return productImageId;
    }

    public void setProductImageId(String productImageId) {
        this.productImageId = productImageId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "AttributeValueModel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", cost='" + cost + '\'' +
                ", isPreSelected=" + isPreSelected +
                ", productImageId='" + productImageId + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", color='" + color + '\'' +
                '}';
    }

    public  void parse(JSONObject object) throws JSONException {
        if(checkForNull("id",object)){
            id = object.getInt("id");
        }
        if(checkForNull("name",object)){
            name = object.getString("name");
        }
        if(checkForNull("is_pre_selected",object)){
            isPreSelected = object.getBoolean("is_pre_selected");
        }
        if(checkForNull("product_image_id",object)){
            productImageId = object.getString("product_image_id");
        }
        if(checkForNull("image_squares_image",object)){
            JSONObject jsonObject = object.getJSONObject("image_squares_image");
            if(checkForNull("src",jsonObject)){
                imageUrl = jsonObject.getString("src");
            }
        }
        if(checkForNull("color_squares_rgb",object)){
            color = object.getString("color_squares_rgb");
        }
    }

    public  void parseForAddress(JSONObject object) throws JSONException {
        if(checkForNull("Id",object)){
            id = object.getInt("Id");
        }
        if(checkForNull("Name",object)){
            name = object.getString("Name");
        }
        if(checkForNull("IsPreSelected",object)){
            isPreSelected = object.getBoolean("IsPreSelected");
        }

        if(checkForNull("ColorSquaresRgb",object)){
            color = object.getString("ColorSquaresRgb");
        }
    }

    private boolean checkForNull(String key,JSONObject object){
        return  object!= null && object.has(key) && !object.isNull(key);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(cost);
        dest.writeByte((byte) (isPreSelected ? 1 : 0));
        dest.writeString(productImageId);
        dest.writeString(imageUrl);
        dest.writeString(color);
    }
}
