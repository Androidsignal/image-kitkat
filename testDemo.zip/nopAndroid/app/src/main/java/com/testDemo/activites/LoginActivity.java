package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.TextViewCompat;

import com.facebook.FacebookSdk;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import android.app.Activity;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.login.Login;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.material.textfield.TextInputLayout;
import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.UserModel;
import com.scottyab.showhidepasswordedittext.ShowHidePasswordEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tv_sign_up, tv_forgot;
    String TAG = getClass().getSimpleName();
    Activity context = LoginActivity.this;
    Button btn_login, btn_login_facebook;

    EditText editEmail;
    ShowHidePasswordEditText editPassword;
    LoginButton loginButton;
    private CallbackManager callbackManager;
    LinearLayout layoutMain;
    LinearLayout layoutNoInternet;
    LinearLayout layoutError;
    Button btnReload;
    ImageView iv_back;

    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String userId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(this.getApplicationContext());
        setContentView(R.layout.activity_login);
        findViewById();

        Glide.with(LoginActivity.this)
                .load(R.drawable.back_full)
                .centerInside().into(iv_back);
        if (!Constants.isCheckInternetCon(context)) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
        }
    }

    private void findViewById() {


        loginButton = findViewById(R.id.login_button);
        btn_login_facebook = findViewById(R.id.btn_login_facebook);
        btn_login_facebook.setOnClickListener(this);
        iv_back = findViewById(R.id.iv_back);
        tv_sign_up = findViewById(R.id.tv_sign_up);
        tv_forgot = findViewById(R.id.tv_forgot);
        btn_login = findViewById(R.id.btn_login);
        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);

        btnReload = findViewById(R.id.btnReload);
        layoutMain = findViewById(R.id.layoutMain);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutError = findViewById(R.id.layoutError);

        tv_sign_up.setOnClickListener(this);
        tv_forgot.setOnClickListener(this);
        btn_login.setOnClickListener(this);
        btnReload.setOnClickListener(this);

        editEmail.setText("admin@yourstore.com");
        editPassword.setText("admin");


        loginButton.setReadPermissions(Arrays.asList("email", "public_profile"));
        // Creating CallbackManager
        callbackManager = CallbackManager.Factory.create();
        // Registering CallbackManager with the LoginButton
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
//                AccessToken accessToken = loginResult.getAccessToken();
                AccessToken accessToken = AccessToken.getCurrentAccessToken();
                useLoginInformation(accessToken);

            }

            @Override
            public void onCancel() {
            }

            @Override
            public void onError(FacebookException error) {
                Log.e(TAG, "onError: " + error.getMessage());
            }
        });

        hashFromSHA1("28:56:62:A9:E4:75:E3:83:C2:FA:2E:72:21:CB:0D:6B:B3:62:05:49");
    }

    public void hashFromSHA1(String sha1) {

        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "com.testDemo",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_login:
//                btn_login.setClickable(false);
                if (validateForm()) {
                    callApiForLogin();
                }
                break;
            case R.id.tv_sign_up:
                tv_sign_up.setClickable(false);
                startActivity(new Intent(LoginActivity.this, SignUpActivity.class));
                break;
            case R.id.tv_forgot:
                tv_forgot.setClickable(false);
                startActivity(new Intent(LoginActivity.this, ForgotPassword.class));
                break;
            case R.id.btnReload:
                recreate();
                break;
            case R.id.btn_login_facebook:
                loginButton.performClick();
                break;
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (btn_login != null) {
            btn_login.setClickable(true);
        }
        if (tv_sign_up != null) {
            tv_sign_up.setClickable(true);
        }
        if (tv_forgot != null) {
            tv_forgot.setClickable(true);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (btn_login != null) {
            btn_login.setClickable(true);
        }
        if (tv_sign_up != null) {
            tv_sign_up.setClickable(true);
        }
        if (tv_forgot != null) {
            tv_forgot.setClickable(true);
        }

    }

    void callApiForLogin() {
        JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "customers/login?username=" + editEmail.getText().toString() + "&password=" + editPassword.getText().toString() + "&captchaValid=true", null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {
                        if (jsonObject.has("CustomerId") && !jsonObject.isNull("CustomerId")) {
                            userId = jsonObject.getString("CustomerId");
                            SharedPrefsUtils.setStringPreference(context, Constants.PREF_USER_ID, userId);
                            startActivity(new Intent(context, HomeActivity.class));
                            finish();
                        }
                    } else {
                        Toast.makeText(context, "Login Failed", Toast.LENGTH_SHORT).show();
                        /*layoutMain.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);*/
                    }
                } else {
                    Toast.makeText(context, "Login Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }
            }
        }, true);
        helper.execute();
    }

    boolean validateForm() {
        editEmail.setError(null);
        editPassword.setError(null);
        if (!editEmail.getText().toString().isEmpty()) {
            if (!editPassword.getText().toString().isEmpty()) {
                if (editEmail.getText().toString().matches(emailPattern)) {
                    return true;
                } else {
//                    input_layout_email.setErrorEnabled(true);
                    editEmail.setError(getResources().getString(R.string.strErrorInvalidEmail));
                }
            } else {
//                input_layout_password.setErrorEnabled(true);
                editPassword.setError(getResources().getString(R.string.strErrorEmptyPassword));
            }
        } else {
//            input_layout_email.setErrorEnabled(true);
            editEmail.setError(getResources().getString(R.string.strErrorEmptyEmail));
        }
        return false;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }


    private void useLoginInformation(AccessToken accessToken) {

        GraphRequest request = GraphRequest.newMeRequest(accessToken, new GraphRequest.GraphJSONObjectCallback() {
            @Override
            public void onCompleted(JSONObject object, GraphResponse response) {
                if (null != object) {
                    try {
                        String id = object.getString("id");
                        String name = object.getString("name");
                        String email = object.getString("email");
                        String image = object.getJSONObject("picture").getJSONObject("data").getString("url");
                        Log.e(TAG, "onCompleted: " + name + "-----" + email + "-----" + image);
                        callApiForRegistration(id, email, image, name);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    // call your authentication process
                }
            }
        });

        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,picture.width(200)");
        request.setParameters(parameters);
        request.executeAsync();
    }

    void callApiForRegistration(String fbUserId, String fbUserEmail, String fbUserImage, String fbUserName) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("UId", fbUserId);
        hashMap.put("Email", fbUserEmail);
        hashMap.put("ImageUrl", fbUserImage);
        hashMap.put("Name", fbUserName);
        JSONHelper jsonHelper = new JSONHelper(this, Config.BASE_URL + "customers/facebooksignin", hashMap, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("errorcode") && !jsonObject.isNull("errorcode") && jsonObject.getString("errorcode").equals("0")) {
                        if (jsonObject.has("CustomerId") && !jsonObject.isNull("CustomerId")) {
                            userId = jsonObject.getString("CustomerId");
                            SharedPrefsUtils.setStringPreference(context, Constants.PREF_USER_ID, userId);
                            startActivity(new Intent(context, HomeActivity.class));
                            finish();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "SignUp Failed", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(context, "SignUp Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }, true);
        jsonHelper.execute();
    }
}
