package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.material.tabs.TabLayout;
import com.testDemo.R;
import com.testDemo.adapter.PagerAdapterForCart;
import com.testDemo.fragment.CompleteFragment;
import com.testDemo.fragment.PaymentFragment;
import com.testDemo.fragment.SelectShippingMethod;
import com.testDemo.fragment.ShippingFragment;
import com.testDemo.global.Constants;
import com.testDemo.global.CustomViewPager;
import com.testDemo.model.PaymentMethodModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.ShippingMethodModel;

import java.util.ArrayList;

public class CheckOutActivity extends AppCompatActivity {
    CustomViewPager viewPager;

    Toolbar toolbar;
    LinearLayout layoutNoInternet, ll_main_layout;

    ImageView imgStep1;
    ImageView imgStep2;
    ImageView imgStep3;
    ImageView imgStep4;

    ImageView imgBorder1;
    ImageView imgBorder2;
    ImageView imgBorder3;

    ArrayList<ShippingMethodModel> shippingMethodModelList = new ArrayList<>();
    ArrayList<PaymentMethodModel> paymentMethodModelList = new ArrayList<>();

    SelectShippingMethod shippingMethodFragment;
    PaymentFragment paymentFragment;

    int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);
        findViewById();
        toolbarInit();
        if (Constants.isCheckInternetCon(this)) {
            layoutNoInternet.setVisibility(View.GONE);
            ll_main_layout.setVisibility(View.VISIBLE);
        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            ll_main_layout.setVisibility(View.GONE);
        }

    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("Checkout");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }


    private void findViewById() {
        toolbar = findViewById(R.id.toolbar);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        ll_main_layout = findViewById(R.id.ll_main_layout);
        Button btnReload = findViewById(R.id.btnReload);


        imgStep1 = findViewById(R.id.imgStep1);
        imgStep2 = findViewById(R.id.imgStep2);
        imgStep3 = findViewById(R.id.imgStep3);
        imgStep4 = findViewById(R.id.imgStep4);

        imgBorder1 = findViewById(R.id.imgBorder1);
        imgBorder2 = findViewById(R.id.imgBorder2);
        imgBorder3 = findViewById(R.id.imgBorder3);

        btnReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.isCheckInternetCon(CheckOutActivity.this)) {
                    layoutNoInternet.setVisibility(View.GONE);
                    ll_main_layout.setVisibility(View.VISIBLE);
                }
            }
        });

        viewPager = findViewById(R.id.pager);
        viewPager.setPagingEnabled(false);
        addTabs(viewPager);

    }

    private void addTabs(CustomViewPager viewPager) {
        shippingMethodFragment = new SelectShippingMethod(CheckOutActivity.this);
        paymentFragment = new PaymentFragment(CheckOutActivity.this);
        PagerAdapterForCart adapter = new PagerAdapterForCart(getSupportFragmentManager());
        adapter.addFrag(new ShippingFragment(CheckOutActivity.this), "Shipping");
        adapter.addFrag(shippingMethodFragment, "Shipping Method");
        adapter.addFrag(paymentFragment, "Payment");
        adapter.addFrag(new CompleteFragment(), "Complete");

        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                setPage(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    public void setPage(int index){
        switch (index){
            case 0:
                currentIndex = 0;
                imgStep1.setColorFilter(getResources().getColor(R.color.icon_color));

                imgStep2.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgStep3.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgStep4.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgBorder1.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgBorder2.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgBorder3.setColorFilter(getResources().getColor(R.color.colorAccent));
                viewPager.setCurrentItem(0);
                break;
            case 1:
                currentIndex = 1;
                shippingMethodFragment.setAdapter();
                imgStep2.setColorFilter(getResources().getColor(R.color.icon_color));
                imgBorder1.setColorFilter(getResources().getColor(R.color.icon_color));


                imgStep3.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgStep4.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgBorder2.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgBorder3.setColorFilter(getResources().getColor(R.color.colorAccent));
                viewPager.setCurrentItem(1);
                break;
            case 2:
                currentIndex = 2;
                paymentFragment.setAdapter();
                imgStep3.setColorFilter(getResources().getColor(R.color.icon_color));
                imgBorder1.setColorFilter(getResources().getColor(R.color.icon_color));
                imgBorder2.setColorFilter(getResources().getColor(R.color.icon_color));

                imgStep4.setColorFilter(getResources().getColor(R.color.colorAccent));
                imgBorder3.setColorFilter(getResources().getColor(R.color.colorAccent));
                viewPager.setCurrentItem(2);
                break;
            case 3:
                currentIndex = 3;
                imgStep4.setColorFilter(getResources().getColor(R.color.icon_color));
                viewPager.setCurrentItem(3);
                break;
        }
    }

    public ArrayList<ShippingMethodModel> getShippingMethodModelList() {
        return shippingMethodModelList;
    }

    public ArrayList<PaymentMethodModel> getPaymentMethodModelList() {
        return paymentMethodModelList;
    }

    public void setPaymentMethodModelList(ArrayList<PaymentMethodModel> paymentMethodModelList) {
        this.paymentMethodModelList = paymentMethodModelList;
    }

    public void setShippingMethodModelList(ArrayList<ShippingMethodModel> shippingMethodModelList) {
        this.shippingMethodModelList = shippingMethodModelList;
    }

    @Override
    public void onBackPressed() {
        if(currentIndex <= 0 || currentIndex==3) {
            if(currentIndex == 3){
                startActivity(new Intent(CheckOutActivity.this , HomeActivity.class));
                finish();
            }else {
                super.onBackPressed();
            }
        }else if(currentIndex == 1){
            setPage(currentIndex-1);
            currentIndex = currentIndex-1;
        }else{
            setPage(currentIndex-1);
        }
    }
}
