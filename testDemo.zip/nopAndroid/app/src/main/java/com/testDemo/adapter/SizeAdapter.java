package com.testDemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.model.ProductModel;
import com.testDemo.model.SizeModel;

import java.util.ArrayList;

public class SizeAdapter extends RecyclerView.Adapter<SizeAdapter.ViewHolder> {
    Context context;
    ArrayList<SizeModel> sizeList;
    boolean isSelect = true;

    public SizeAdapter(Context context, ArrayList<SizeModel> sizeList) {
        this.context = context;
        this.sizeList = sizeList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.size_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final SizeModel myListData = sizeList.get(position);
        holder.tv_size.setText(myListData.getSize());

        if (myListData.isTrue) {
            myListData.setTrue(true);
            holder.tv_size.setBackground(context.getResources().getDrawable(R.drawable.btn_pink));
            holder.tv_size.setTextColor(context.getResources().getColor(R.color.white));
        } else {
            myListData.setTrue(false);
            holder.tv_size.setBackground(context.getResources().getDrawable(R.drawable.btn_white));
            holder.tv_size.setTextColor(context.getResources().getColor(R.color.profile_background));
        }

        holder.tv_size.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myListData.isTrue) {
                    myListData.setTrue(false);
                    holder.tv_size.setBackground(context.getResources().getDrawable(R.drawable.btn_pink));
                    holder.tv_size.setTextColor(context.getResources().getColor(R.color.white));

                } else {
                    myListData.setTrue(true);
                    holder.tv_size.setBackground(context.getResources().getDrawable(R.drawable.btn_white));
                    holder.tv_size.setTextColor(context.getResources().getColor(R.color.grey));
                }
                notifyDataSetChanged();
            }
        });

    }


    @Override
    public int getItemCount() {
        return sizeList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_size;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            tv_size = (TextView) itemView.findViewById(R.id.tv_size);
        }
    }
}