package com.testDemo.fragment;


import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.CheckOutActivity;
import com.testDemo.adapter.PaymentMethodAdapter;
import com.testDemo.adapter.ShippingMethodAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.CustomViewPager;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.PaymentMethodModel;
import com.testDemo.model.ShippingMethodModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * A simple {@link Fragment} subclass.
 */
public class PaymentFragment extends Fragment implements View.OnClickListener {
    CheckOutActivity checkOutActivity;

    RecyclerView recyclerView;
    PaymentMethodAdapter adapter;
    ArrayList<PaymentMethodModel> arrayList = new ArrayList<>();
    private String userId;
    String storeId;

    ProgressDialog progressDialog;

    public PaymentFragment(CheckOutActivity checkOutActivity) {
        this.checkOutActivity = checkOutActivity;
    }

    ImageView iv_card;
    Button btn_forgot_password;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_payment, container, false);
        findviewById(view);
        return view;
    }

    private void findviewById(View view) {
        iv_card = view.findViewById(R.id.iv_card);
        btn_forgot_password = view.findViewById(R.id.btn_forgot_password);
        recyclerView = view.findViewById(R.id.recyclerView);
        btn_forgot_password.setOnClickListener(this);
        Glide.with(getActivity()).load("https://www.scotiabank.com/content/dam/scotiabank/canada/en/card-arts/ScotiaCard_Debit_ENG.png/_jcr_content/renditions/cq5dam.web.1280.1280.png").into(iv_card);
        setAdapter();
    }

    public void setAdapter() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity(), RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        if (checkOutActivity != null && checkOutActivity.getShippingMethodModelList() != null) {
            arrayList = checkOutActivity.getPaymentMethodModelList();
        }
        recyclerView.setVisibility(View.VISIBLE);
        adapter = new PaymentMethodAdapter(getActivity(), arrayList);
        recyclerView.setAdapter(adapter);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_forgot_password:
                callApiForInsertPaymentMethod();
                break;
        }
    }

    void callApiForInsertPaymentMethod() {

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Please wait a moment");
        progressDialog.show();

        userId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_USER_ID);
        storeId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_SELECTED_STORE);
        PaymentMethodModel model = arrayList.get(0);
        if (adapter.getSelectedItem() != null) {
            model = arrayList.get(Integer.parseInt(adapter.getSelectedItem()));
        }

        if (model != null && model.getName() != null && model.getPaymentMethodSystemName() != null) {
            JSONHelper helper = new JSONHelper(getActivity(), Config.BASE_URL + "checkouts/selectpaymentmethod?paymentmethod=" + model.getPaymentMethodSystemName() + "&UseRewardPoints=false&customerId=" + userId + "&storeid=" + storeId, new HashMap<String, String>(), new OnAsyncLoader() {
                @Override
                public void OnResult(String result) throws JSONException {
                    if (result != null && !result.isEmpty()) {
                        JSONObject resultJson = new JSONObject(result);
                        if (resultJson.has("Success") && !resultJson.isNull("Success")) {
                            if (resultJson.getString("Success").equals("0")) {
                                callApiForConfirmOrder();
                            } else {
                                Toast.makeText(checkOutActivity, "Fail To Store Payment Method", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }, false);
            helper.execute();
        } else {
            Toast.makeText(checkOutActivity, "Something Went Wrong Try Again Later", Toast.LENGTH_SHORT).show();
        }
    }

    void callApiForConfirmOrder() {
        JSONHelper helper = new JSONHelper(getActivity(), Config.BASE_URL + "checkouts/confirmorder?customerId=" + userId + "&storeid=" + storeId, new HashMap<String, String>(), new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                progressDialog.dismiss();
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {
                        checkOutActivity.setPage(3);
                    }
                }
            }
        }, false);
        helper.execute();
    }
}
