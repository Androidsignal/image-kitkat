package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.testDemo.R;
import com.poovam.pinedittextfield.CirclePinField;
import com.poovam.pinedittextfield.LinePinField;
import com.poovam.pinedittextfield.PinField;

import org.jetbrains.annotations.NotNull;


public class OTPActivity extends AppCompatActivity implements View.OnClickListener {
    Toolbar toolbar;
    CirclePinField linePinField;
    TextView tv_resend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        findViewById();
        toolbarInit();
        linePinField.setFocusable(true);
        linePinField.setOnTextCompleteListener(new PinField.OnTextCompleteListener() {
            @Override
            public boolean onTextComplete(@NotNull String enteredText) {
                Toast.makeText(OTPActivity.this, enteredText, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(OTPActivity.this, HomeActivity.class));
                finish();
                return true; // Return true to keep the keyboard open else return false to close the keyboard
            }
        });
    }

    private void findViewById() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        linePinField = findViewById(R.id.circleField);
        tv_resend = findViewById(R.id.tv_resend);
        tv_resend.setOnClickListener(this);

    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(menuItem);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_resend:
                Toast.makeText(this, "Otp Is Sent", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
