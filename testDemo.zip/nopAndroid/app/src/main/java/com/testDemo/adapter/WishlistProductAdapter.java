package com.testDemo.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.WishlistActivity;
import com.testDemo.model.ProductModel;

import java.util.ArrayList;

public class WishlistProductAdapter extends RecyclerView.Adapter<WishlistProductAdapter.MyViewHolder> {

    Context context;
    ArrayList<ProductModel> wishList;
    LayoutInflater layoutInflater;
    WishlistActivity wishlistActivity;

    public WishlistProductAdapter(Activity context, ArrayList<ProductModel> wishList,WishlistActivity wishlistActivity) {

        this.context = context;
        this.wishList = wishList;
        this.wishlistActivity = wishlistActivity;
        layoutInflater = layoutInflater.from(context);

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.wishlist_item,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        holder.wishListItemName.setText(wishList.get(position).getProductName());
        holder.wishListItemQuantity.setText("qty: "+wishList.get(position).getItemQuantity());
        holder.wishListItemPrice.setText("Price: "+wishList.get(position).getProductPrice());

        Glide.with(context).load(wishList.get(position).getProductImage()).into(holder.wishListItemImage);

        holder.deleteWishListItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                wishlistActivity.onClickItem(position);

            }
        });

    }

    @Override
    public int getItemCount() {
        return wishList.size();
    }




    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView wishListItemImage,deleteWishListItem;
        TextView wishListItemName,wishListItemQuantity,wishListItemPrice;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            wishListItemImage = itemView.findViewById(R.id.wishListItemImage);
            deleteWishListItem = itemView.findViewById(R.id.deleteWishListItem);
            wishListItemName = itemView.findViewById(R.id.wishListItemName);
            wishListItemQuantity = itemView.findViewById(R.id.wishListItemQuantity);
            wishListItemPrice = itemView.findViewById(R.id.wishListItemPrice);
        }
    }
}
