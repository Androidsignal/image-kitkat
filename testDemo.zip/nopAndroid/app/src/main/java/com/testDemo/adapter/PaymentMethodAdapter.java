package com.testDemo.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.model.PaymentMethodModel;

import java.util.ArrayList;

public class PaymentMethodAdapter extends RecyclerView.Adapter<PaymentMethodAdapter.ViewHolder> {

    Context context;
    ArrayList<PaymentMethodModel> arrayList;

    String selectedItem;

    public PaymentMethodAdapter(Context context, ArrayList<PaymentMethodModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.shipping_method_list_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        PaymentMethodModel model = arrayList.get(position);
        if (model != null) {
            if (model.getName() != null) {
                holder.txtName.setText(Html.fromHtml(model.getName()));
            } else {
                holder.txtName.setVisibility(View.GONE);
            }
            if (model.getLogoUrl() != null) {
                holder.imageView.setVisibility(View.VISIBLE);
                Glide.with(context).load(model.getLogoUrl()).placeholder(R.drawable.placeholder).error(R.drawable.noimage).into(holder.imageView);
            } else {
                holder.imageView.setVisibility(View.GONE);
            }
            if (model.getDescription() != null) {
                holder.txtDescription.setText(Html.fromHtml(model.getDescription()));
            } else {
                holder.txtDescription.setVisibility(View.GONE);
            }

            if (selectedItem == null && model.isSelected()) {
                selectedItem = String.valueOf(position);
                holder.cardView.setBackgroundColor(context.getResources().getColor(R.color.icon_color));
                holder.radioButton.setSelected(true);
            } else if (selectedItem.equals(String.valueOf(position))) {
                holder.cardView.setBackgroundColor(context.getResources().getColor(R.color.icon_color));
                holder.radioButton.setSelected(true);
            } else {
                holder.radioButton.setSelected(false);
                holder.cardView.setBackgroundColor(context.getResources().getColor(android.R.color.transparent));
            }

            holder.cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedItem = String.valueOf(position);
                    notifyDataSetChanged();
                }
            });
        } else {
            holder.cardView.setVisibility(View.GONE);
        }
    }

    public String getSelectedItem() {
        return selectedItem;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        CardView cardView;
        RadioButton radioButton;
        TextView txtName;
        TextView txtDescription;
        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);

            this.setIsRecyclable(false);

            cardView = itemView.findViewById(R.id.cardView);
            radioButton = itemView.findViewById(R.id.radioButton);
            txtName = itemView.findViewById(R.id.txtName);
            txtDescription = itemView.findViewById(R.id.txtDescription);
            imageView = itemView.findViewById(R.id.imageView);

        }
    }
}