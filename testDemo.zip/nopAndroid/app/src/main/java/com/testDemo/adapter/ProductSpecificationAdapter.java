package com.testDemo.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.testDemo.R;
import com.testDemo.model.ProductDetailModel;
import com.testDemo.model.ProductSpecificationModel;
import com.testDemo.model.SizeModel;

import java.util.ArrayList;

public class ProductSpecificationAdapter extends RecyclerView.Adapter<ProductSpecificationAdapter.ViewHolder> {
    Context context;
    ArrayList<ProductSpecificationModel> arrayList;

    public ProductSpecificationAdapter(Context context, ArrayList<ProductSpecificationModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.layout_specification_attribute, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        if(arrayList != null){
             ProductSpecificationModel model = arrayList.get(position);
            if (model != null){
                if(model.getName() != null){
                    holder.txtLabel.setText(model.getName());
                }
                if(model.getValue() != null){
                    holder.txtValue.setText(Html.fromHtml(model.getValue()));
                }
            }else{
                holder.layoutMain.setVisibility(View.GONE);
            }
        }
    }


    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtLabel;
        TextView txtValue;
        LinearLayout layoutMain;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            txtLabel = itemView.findViewById(R.id.txtLabel);
            txtValue = itemView.findViewById(R.id.txtValue);
            layoutMain = itemView.findViewById(R.id.layoutMain);
        }
    }
}