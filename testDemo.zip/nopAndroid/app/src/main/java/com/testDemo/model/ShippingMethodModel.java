package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

public class ShippingMethodModel {
    String shippingRateComputationMethodSystemName;
    String name;
    String description;
    boolean isSelected;

    public String getShippingRateComputationMethodSystemName() {
        return shippingRateComputationMethodSystemName;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void parse(JSONObject object) throws JSONException {
        if(object != null){
            if(checkForNull("ShippingRateComputationMethodSystemName",object)){
                shippingRateComputationMethodSystemName = object.getString("ShippingRateComputationMethodSystemName");
            }
            if(checkForNull("Name",object)){
                name = object.getString("Name");
            }
            if(checkForNull("Description",object)){
                description = object.getString("Description");
            }
            if(checkForNull("Selected",object)){
                isSelected = object.getBoolean("Selected");
            }
        }
    }

    private boolean checkForNull(String key,JSONObject object){
        return  object!= null && object.has(key) && !object.isNull(key);
    }
}