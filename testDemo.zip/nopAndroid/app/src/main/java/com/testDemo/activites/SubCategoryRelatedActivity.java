package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.crystal.crystalrangeseekbar.interfaces.OnRangeSeekbarChangeListener;
import com.crystal.crystalrangeseekbar.widgets.CrystalRangeSeekbar;
import com.google.gson.JsonArray;
import com.testDemo.R;
import com.testDemo.adapter.CategoryTitleListAdapter;
import com.testDemo.adapter.FilterBrandListAdapter;
import com.testDemo.adapter.HolidaySaleListAdapter;
import com.testDemo.adapter.ProductListAdapter;
import com.testDemo.adapter.SizeAdapter;
import com.testDemo.adapter.SubCategorySliderAdapter;
import com.testDemo.config.Config;
import com.testDemo.fragment.ExploreFragment;
import com.testDemo.global.Constants;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.ManufacturerModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.SizeModel;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SubCategoryRelatedActivity extends AppCompatActivity implements View.OnClickListener {

    LinearLayout layoutMain, layoutLoading, layoutNoInternet, ll_filter, ll_brand, empty_list, ll_productList;
    RecyclerView rcv_product_list, rcv_categoryList, recyclerViewForSpecificationAttribute, rcv_brand;
    ProductListAdapter productListAdapter;
    ArrayList<ProductModel> subCategory = new ArrayList<>();
    ProductModel productModel;
    Toolbar toolbar;
    TextView tv_item_total;
    TextView txtCategoryName;
    ImageView iv_option_more, iv_cancel, iv_toolbar_btn_cart;
    SubCategorySliderAdapter subCategorySliderAdapter;
    SliderView sliderView;
    CategoryTitleListAdapter categoryTitleListAdapter;
    ArrayList<String> categoryTitleList = new ArrayList<String>();
    ArrayList<SizeModel> sizeList = new ArrayList<>();
    ArrayList<ManufacturerModel> filterBrandList = new ArrayList<>();
    SizeModel sizeModel;
    SizeAdapter sizeAdapter;
    FilterBrandListAdapter filterBrandListAdapter;
    NestedScrollView scroll_layout;
    Button btn_clear, btn_apply;
    String CategoryId;
    CrystalRangeSeekbar rangeSeekBar;
    String MaxPrice = "null";
    String MinPrice = "null";
    TextView minValue, maxValue, selectedAll;
    float min, max;
    String manufacturersId = "";
    String mId = "";
    String categoryName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_category_related);
        findViewById();
        toolbarInit();
        if (Constants.isCheckInternetCon(SubCategoryRelatedActivity.this)) {
            scroll_layout.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            if(getIntent().getStringExtra("CategoryId") != null) {
                CategoryId = getIntent().getStringExtra("CategoryId");
            }
            if(getIntent().getStringExtra("CategoryName") != null) {
                categoryName = getIntent().getStringExtra("CategoryName");
                txtCategoryName.setText(categoryName);
            }
            callApiForProductList();
            setList();
            callApiForSize();
            callApiForFilter();
//            callApiToManufacturer();

        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            scroll_layout.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }
    }

    public void setList() {
        categoryTitleList.add("Everything");
        categoryTitleList.add("Jacket");
        categoryTitleList.add("Blazer");
        categoryTitleList.add("Dresses");
        categoryTitleList.add("Traditional");

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(SubCategoryRelatedActivity.this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); //
        rcv_categoryList.setLayoutManager(linearLayoutManager);//
        categoryTitleListAdapter = new CategoryTitleListAdapter(SubCategoryRelatedActivity.this, categoryTitleList);
        rcv_categoryList.setAdapter(categoryTitleListAdapter);
    }

    private void ifLocationIsEmpty() {
        if (subCategory != null && subCategory.size() > 0) {
            empty_list.setVisibility(View.GONE);
            ll_productList.setVisibility(View.VISIBLE);
        } else {
            empty_list.setVisibility(View.VISIBLE);
            ll_productList.setVisibility(View.GONE);
        }
    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });

    }

    private void callApiForProductList() {
        JSONHelper jsonHelper = new JSONHelper(SubCategoryRelatedActivity.this, Config.BASE_URL + "categories/IncludeProductsFromSubcategories1?CategoryId=" + CategoryId + "&orderBy=0&manufectureIds=" + mId + "&page=1&pageSize=25&MinPrice=" + MinPrice + "&MaxPrice=" + MaxPrice, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("ProductsFromParentcategory") && !jsonObject.isNull("ProductsFromParentcategory")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("ProductsFromParentcategory");
                        subCategory = new ArrayList<ProductModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            productModel = new ProductModel();
                            productModel.parseForRelatedProduct(obj);
                            subCategory.add(productModel);
                        }
                    }

                } else {
                    Toast.makeText(SubCategoryRelatedActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                layoutLoading.setVisibility(View.GONE);
                scroll_layout.setVisibility(View.VISIBLE);
                ifLocationIsEmpty();
                tv_item_total.setText(subCategory.size() + " " + getResources().getString(R.string.items_found));

                productListAdapter = new ProductListAdapter(SubCategoryRelatedActivity.this, subCategory, null, new OnClickProductSubCategory() {
                    @Override
                    public void OnClickProductSubCategory(int position) throws JSONException {
                        Intent i = new Intent(SubCategoryRelatedActivity.this, ProductDetailActivity.class);
                        if (subCategory.size() > 0 && subCategory.get(position) != null && subCategory.get(position).getProductId() != null) {
                            i.putExtra(Constants.INTENT_PRODUCT_ID, subCategory.get(position).getProductId().toString());
                        }
                        startActivity(i);
                    }
                });


                rcv_product_list.setAdapter(productListAdapter);

            }
        }, false);
        jsonHelper.execute();
    }

    private void callApiForSize() {
        sizeList = new ArrayList<SizeModel>();
        sizeModel = new SizeModel();
        sizeModel.setSize("XS");
        sizeList.add(sizeModel);


        sizeModel = new SizeModel();
        sizeModel.setSize("S");
        sizeList.add(sizeModel);

        sizeModel = new SizeModel();
        sizeModel.setSize("M");
        sizeList.add(sizeModel);

        sizeModel = new SizeModel();
        sizeModel.setSize("L");
        sizeList.add(sizeModel);


        sizeModel = new SizeModel();
        sizeModel.setSize("XL");
        sizeList.add(sizeModel);


        sizeAdapter = new SizeAdapter(SubCategoryRelatedActivity.this, sizeList);
        recyclerViewForSpecificationAttribute.setAdapter(sizeAdapter);


    }

    private void findViewById() {
        iv_toolbar_btn_cart = findViewById(R.id.iv_toolbar_btn_cart);
        txtCategoryName = findViewById(R.id.txtCategoryName);
        iv_toolbar_btn_cart.setOnClickListener(this);
        layoutMain = findViewById(R.id.layoutMain);
        recyclerViewForSpecificationAttribute = findViewById(R.id.recyclerViewForSpecificationAttribute);
        rcv_brand = findViewById(R.id.rcv_brand);
        ll_filter = findViewById(R.id.ll_filter);
        btn_clear = findViewById(R.id.btn_clear);
        btn_apply = findViewById(R.id.btn_apply);
        iv_option_more = findViewById(R.id.iv_option_more);
        iv_cancel = findViewById(R.id.iv_cancel);
        tv_item_total = findViewById(R.id.tv_item_total);
        toolbar = findViewById(R.id.toolbar);
        rcv_product_list = findViewById(R.id.rcv_product_list);
        rcv_categoryList = findViewById(R.id.rcv_categoryList);
        sliderView = findViewById(R.id.imageSlider);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        scroll_layout = findViewById(R.id.scroll_layout);
        empty_list = findViewById(R.id.empty_list);
        selectedAll = findViewById(R.id.selectedAll);
        ll_productList = findViewById(R.id.ll_productList);
        ll_brand = findViewById(R.id.ll_brand);
        rangeSeekBar = findViewById(R.id.rangeSeekBar);
        maxValue = findViewById(R.id.maxValue);
        minValue = findViewById(R.id.minValue);
        rcv_product_list.setLayoutManager(new GridLayoutManager(SubCategoryRelatedActivity.this, 2));
        btn_clear.setOnClickListener(this);
        btn_apply.setOnClickListener(this);
        iv_option_more.setOnClickListener(this);
        iv_cancel.setOnClickListener(this);
        selectedAll.setOnClickListener(this);

        subCategorySliderAdapter = new SubCategorySliderAdapter(this,null);
        subCategorySliderAdapter.setCount(5);

        sliderView.setSliderAdapter(subCategorySliderAdapter);

        sliderView.setIndicatorAnimation(IndicatorAnimations.WORM);
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderView.setScrollTimeInSec(4); //set scroll delay in seconds :
        sliderView.startAutoCycle();

        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this);
        linearLayoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        recyclerViewForSpecificationAttribute.setLayoutManager(linearLayoutManager2);

        LinearLayoutManager linear_rcv_brand = new LinearLayoutManager(this);
        linear_rcv_brand.setOrientation(RecyclerView.VERTICAL); // set Horizontal Orientation
        rcv_brand.setLayoutManager(linear_rcv_brand);

        rangeSeekBar.setOnRangeSeekbarChangeListener(new OnRangeSeekbarChangeListener() {
            @Override
            public void valueChanged(Number min, Number max) {
                minValue.setText(String.valueOf(min));
                maxValue.setText(String.valueOf(max));
            }
        });


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_option_more:
                ll_filter.setVisibility(View.VISIBLE);
                scroll_layout.setVisibility(View.GONE);
                layoutMain.setVisibility(View.GONE);
                toolbar.setVisibility(View.GONE);
                saveSate();
                break;
            case R.id.iv_toolbar_btn_cart:
                startActivity(new Intent(SubCategoryRelatedActivity.this, CartScreen.class));
                break;
            case R.id.iv_cancel:
                scroll_layout.setVisibility(View.VISIBLE);
                layoutMain.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
                ll_filter.setVisibility(View.GONE);
                break;
            case R.id.btn_apply:
                layoutMain.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
                ll_filter.setVisibility(View.GONE);
                layoutLoading.setVisibility(View.VISIBLE);
                scroll_layout.setVisibility(View.GONE);
                MaxPrice = String.valueOf(rangeSeekBar.getSelectedMaxValue());
                MinPrice = String.valueOf(rangeSeekBar.getSelectedMinValue());
                brandSelected();
                callApiForProductList();
                break;
            case R.id.btn_clear:
                layoutMain.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
                ll_filter.setVisibility(View.GONE);
                layoutLoading.setVisibility(View.VISIBLE);
                scroll_layout.setVisibility(View.GONE);
                callApiForFilter();
                MaxPrice = "null";
                MinPrice = "null";
                manufacturersId = "";
                mId = manufacturersId;
                callApiForProductList();
                break;

            case R.id.selectedAll:
                for (int i = 0; i < filterBrandList.size(); i++) {
                    filterBrandList.get(i).setSelected(true);
                }
                filterBrandListAdapter.notifyDataSetChanged();
                break;
        }
    }

    public void brandSelected() {
        String ids = "";
        for (int i = 0; i < filterBrandList.size(); i++) {
            if (filterBrandList.get(i).isSelected()) {
                ids += filterBrandList.get(i).getId() + ",";
            }
        }
        if (ids != null && !ids.isEmpty() && ids != "") {
            manufacturersId = ids.substring(0, ids.length() - 1);
        } else {
            manufacturersId = "";
        }
        mId = manufacturersId;
    }

    public void saveSate() {
        if (String.valueOf(min) == MinPrice && String.valueOf(max) == MaxPrice) {
            rangeSeekBar.setMinValue(Float.parseFloat(MinPrice));
            rangeSeekBar.setMaxValue(Float.parseFloat(MaxPrice));
            rangeSeekBar.apply();
        }
    }

    public void callApiForFilter() {
        JSONHelper jsonHelper = new JSONHelper(SubCategoryRelatedActivity.this, Config.BASE_URL + "categories/categoryfilter?categoryId=" + CategoryId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Maximumprice") && !jsonObject.isNull("Maximumprice")) {
                        MaxPrice = jsonObject.getString("Maximumprice");
                    }

                    if (jsonObject.has("MiniMumPrice") && !jsonObject.isNull("MiniMumPrice")) {
                        MinPrice = jsonObject.getString("MiniMumPrice");
                    }
                    if (jsonObject.has("Manufacturers") && !jsonObject.isNull("Manufacturers")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("Manufacturers");
                        filterBrandList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            ManufacturerModel model = new ManufacturerModel();
                            JSONObject object = jsonArray.getJSONObject(i);
                            model.parse(object);
                            filterBrandList.add(model);
                        }
                        if (filterBrandList != null && filterBrandList.size() > 0) {
                            ll_brand.setVisibility(View.VISIBLE);
                        } else {
                            ll_brand.setVisibility(View.GONE);
                        }
                    }
                } else {
                    Toast.makeText(SubCategoryRelatedActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }

                minValue.setText(MinPrice);
                maxValue.setText(MaxPrice);
                min = Float.parseFloat(MinPrice);
                max = Float.parseFloat(MaxPrice);
                rangeSeekBar.setMinValue(min);
                rangeSeekBar.setMaxValue(max);
                rangeSeekBar.setMinStartValue(min).setMaxStartValue(max).apply();
                filterBrandListAdapter = new FilterBrandListAdapter(SubCategoryRelatedActivity.this, filterBrandList);
                rcv_brand.setAdapter(filterBrandListAdapter);
            }
        }, false);
        jsonHelper.execute();
    }

    public interface OnClickProductSubCategory {
        public void OnClickProductSubCategory(int position) throws JSONException;
    }

}
