package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

public class ReviewModel {
    int id;
    int rating;
    String title;
    String review;
    String productName;
    String date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "ReviewModel{" +
                "id=" + id +
                ", rating=" + rating +
                ", title='" + title + '\'' +
                ", review='" + review + '\'' +
                ", productName='" + productName + '\'' +
                ", date='" + date + '\'' +
                '}';
    }

    public void reviewParsing(JSONObject jsonObject) throws JSONException {
        if(checkForNull("ProductId",jsonObject)){
            id = jsonObject.getInt("ProductId");
        }
        if(checkForNull("ProductId",jsonObject)){
            productName = jsonObject.getString("ProductName");
        }
        if(checkForNull("ProductId",jsonObject)){
            title = jsonObject.getString("Title");
        }
        if(checkForNull("ReviewText",jsonObject)){
            review = jsonObject.getString("ReviewText");
        }
        if(checkForNull("Rating",jsonObject)){
            rating = jsonObject.getInt("Rating");
        }
        if(checkForNull("WrittenOnStr",jsonObject)){
            date = jsonObject.getString("WrittenOnStr");
        }
    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }
}
