package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.fragment.ShopFragment;
import com.testDemo.global.Constants;
import com.testDemo.model.ProductModel;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class OrderDetailAdapter extends RecyclerView.Adapter<OrderDetailAdapter.ViewHolder> {
    Context context;
    ArrayList<ProductModel> designerCollection;
    Fragment fragment;


    public OrderDetailAdapter(Context context, ArrayList<ProductModel> designerCollection) {
        this.context = context;
        this.designerCollection = designerCollection;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.top_trending_product_row_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final ProductModel myListData = designerCollection.get(position);
        Glide.with(holder.itemView)
                .load(myListData.getProductImage())
                .into(holder.iv_product_image);
        holder.tv_product_price.setText(myListData.getProductPrice());
        holder.tv_product_name.setText(myListData.getProductName());

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, ProductDetailActivity.class);
                if (designerCollection.size() > 0 && designerCollection.get(position) != null && designerCollection.get(position).getProductId() != null) {
                    i.putExtra(Constants.INTENT_PRODUCT_ID, designerCollection.get(position).getProductId().toString());
                }
                context.startActivity(i);
            }
        });
    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_product_image,iv_cart_added;
        ImageView iv_cart_not_added;

        TextView tv_product_name, tv_product_price;
        LinearLayout cardView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            iv_product_image = (ImageView) itemView.findViewById(R.id.iv_product_image);
            iv_cart_not_added = (ImageView) itemView.findViewById(R.id.iv_cart_not_added);
            iv_cart_added = (ImageView) itemView.findViewById(R.id.iv_cart_added);
            tv_product_name = (TextView) itemView.findViewById(R.id.tv_product_name);
            tv_product_price = (TextView) itemView.findViewById(R.id.tv_product_price);
            cardView = itemView.findViewById(R.id.cardView);

        }
    }
}