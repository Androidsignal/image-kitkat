package com.testDemo.adapter.attributeAdapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.testDemo.R;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.adapter.AttributeListAdapter;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.AttributeValueModel;

import java.util.ArrayList;

public class ColorBoxListAdapter extends RecyclerView.Adapter<ColorBoxListAdapter.ViewHolder>{
    Context context;
    AttributeModel attributeModel;
    AttributeListAdapter attributeListAdapter;
    ProductDetailActivity productDetailActivity;


    public ColorBoxListAdapter(Context context, AttributeModel attributeModel, AttributeListAdapter attributeListAdapter,ProductDetailActivity productDetailActivity) {
        this.context = context;
        this.attributeModel = attributeModel;
        this.attributeListAdapter = attributeListAdapter;
        this.productDetailActivity = productDetailActivity;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.color_squer_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final AttributeValueModel model = attributeModel.getValues().get(position);
        if(model != null && model.getColor() != null){
            if(attributeModel.getCurrentValueModel() == model) {
                holder.background.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.colorAccent)));
            }else{
                holder.background.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(android.R.color.transparent)));
            }
            holder.floatingButton.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(model.getColor())));
            holder.floatingButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    attributeModel.setCurrentValueModel(model);
                    holder.background.setBackgroundTintList(ColorStateList.valueOf(context.getResources().getColor(R.color.colorAccent)));
                    notifyDataSetChanged();
                    attributeModel.setError(null);
                    if(productDetailActivity != null) {
                        productDetailActivity.callApiForHideAttributeIds(true);
                    }else{
                        notifyDataSetChanged();
                        attributeListAdapter.notifyDataSetChanged();
                    }
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return attributeModel.getValues().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

       FloatingActionButton floatingButton;
       LinearLayout background;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);

            floatingButton = itemView.findViewById(R.id.floatingButton);
            background = itemView.findViewById(R.id.background);
        }
    }
}