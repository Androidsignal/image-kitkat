package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.google.android.material.textfield.TextInputLayout;
import com.testDemo.R;
import com.testDemo.adapter.AddressAdapter;
import com.testDemo.adapter.AttributeListAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AddressModel;
import com.testDemo.model.AddressModels.AddressAttributeModel;
import com.testDemo.model.AddressModels.CountryListModel;
import com.testDemo.model.AddressModels.StateListModel;
import com.testDemo.model.AttributeModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;

public class AddAddressScreen extends AppCompatActivity {

    String TAG = getClass().getSimpleName();
    Activity context = AddAddressScreen.this;

    Toolbar toolbar;

    LinearLayout layoutMain;
    LinearLayout layoutLoading;
    LinearLayout layoutNoInternet;
    LinearLayout layoutError;

    Button btnRetry;

    AddressAttributeModel addressAttributeModel;

    RecyclerView recyclerViewForCustomAttribute;
    AttributeListAdapter attributeListAdapter;
    SmartMaterialSpinner dropDownForCountry;
    SmartMaterialSpinner dropDownForState;

    Button btnSave;

    TextInputLayout txtInputFirstName;
    TextInputLayout txtInputLastName;
    TextInputLayout txtInputEmail;
    TextInputLayout txtInputCompany;
    TextInputLayout txtInputCounty;
    TextInputLayout txtInputCity;
    TextInputLayout txtInputAddress1;
    TextInputLayout txtInputAddress2;
    TextInputLayout txtInputZipCode;
    TextInputLayout txtInputPhoneNumber;
    TextInputLayout txtInputFax;

    EditText editFirstName;
    EditText editLastName;
    EditText editEmail;
    EditText editCompany;
    EditText editCounty;
    EditText editCity;
    EditText editAddress1;
    EditText editAddress2;
    EditText editZipCode;
    EditText editPhoneNumber;
    EditText editFax;

    String userId, storeId;

    String addressId;

    int selection = 0;


    NestedScrollView ns_layout_main;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address_screen);
        findViewByIds();
        setupToolbar();
        getIntentData();
        userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);
        storeId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_STORE);
        if (!Constants.isCheckInternetCon(context)) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            if (getIntent().getStringExtra(Constants.INTENT_ADDRESS_MODEL) == null) {
                callApiForGetAddressAttributes();
            }
        }
    }

    void getIntentData() {
        if (getIntent().getStringExtra(Constants.INTENT_ADDRESS_MODEL) != null) {
            toolbar.setTitle("Edit Address");
            addressId = getIntent().getStringExtra(Constants.INTENT_ADDRESS_MODEL);
            if (!Constants.isCheckInternetCon(context)) {
                layoutMain.setVisibility(View.GONE);
                layoutLoading.setVisibility(View.GONE);
                layoutNoInternet.setVisibility(View.VISIBLE);
            } else {
                layoutLoading.setVisibility(View.VISIBLE);
                layoutNoInternet.setVisibility(View.GONE);
                callApiToGetAddressFromAddressId(addressId);
            }
        }
    }

    void findViewByIds() {
        ns_layout_main = findViewById(R.id.ns_layout_main);
        toolbar = findViewById(R.id.toolbar);
        layoutMain = findViewById(R.id.layoutMain);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutError = findViewById(R.id.layoutError);
        recyclerViewForCustomAttribute = findViewById(R.id.recyclerViewForCustomAttribute);
        btnRetry = findViewById(R.id.btnReload);
        btnSave = findViewById(R.id.btnSave);

        txtInputFirstName = findViewById(R.id.txtInputFirstName);
        txtInputLastName = findViewById(R.id.txtInputLastName);
        txtInputEmail = findViewById(R.id.txtInputEmail);
        txtInputCompany = findViewById(R.id.txtInputCompany);
        txtInputCounty = findViewById(R.id.txtInputCounty);
        txtInputCity = findViewById(R.id.txtInputCity);
        txtInputAddress1 = findViewById(R.id.txtInputAddress1);
        txtInputAddress2 = findViewById(R.id.txtInputAddress2);
        txtInputZipCode = findViewById(R.id.txtInputZipCode);
        txtInputPhoneNumber = findViewById(R.id.txtInputPhoneNumber);
        txtInputFax = findViewById(R.id.txtInputFax);

        editFirstName = findViewById(R.id.editFirstName);
        editLastName = findViewById(R.id.editLastName);
        editEmail = findViewById(R.id.editEmail);
        editCompany = findViewById(R.id.editCompany);
        editCounty = findViewById(R.id.editCounty);
        editCity = findViewById(R.id.editCity);
        editAddress1 = findViewById(R.id.editAddress1);
        editAddress2 = findViewById(R.id.editAddress2);
        editZipCode = findViewById(R.id.editZipCode);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        editFax = findViewById(R.id.editFax);

        dropDownForCountry = findViewById(R.id.dropDownForCountry);
        dropDownForState = findViewById(R.id.dropDownForState);


//        Toast.makeText(context, "ok", Toast.LENGTH_SHORT).show();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickSave();
            }
        });
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.isCheckInternetCon(context)) {
                    layoutNoInternet.setVisibility(View.GONE);
                    layoutLoading.setVisibility(View.VISIBLE);
                    if (getIntent().getStringExtra(Constants.INTENT_ADDRESS_MODEL) == null) {
                        callApiForGetAddressAttributes();
                    } else {
                        callApiToGetAddressFromAddressId(addressId);
                    }
                }
            }
        });
    }

    void setupToolbar() {
        toolbar.setTitle("Add New Address");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    void callApiForGetAddressAttributes() {
        JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "customers/getcustomerattributeaddress?storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) {
                try {
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.has("AddressAttributeList") && !jsonObject.isNull("AddressAttributeList")) {
                            JSONObject object = jsonObject.getJSONObject("AddressAttributeList");
                            if (object.has("Address") && !object.isNull("Address")) {
                                JSONObject object1 = object.getJSONObject("Address");
                                addressAttributeModel = new AddressAttributeModel();
                                addressAttributeModel.parse(object1);
                                setData();
                            } else {
                                layoutLoading.setVisibility(View.GONE);
                                layoutError.setVisibility(View.VISIBLE);
                            }
                        } else {
                            layoutLoading.setVisibility(View.GONE);
                            layoutError.setVisibility(View.VISIBLE);
                        }
                    } else {
                        layoutLoading.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }
            }
        }, false);
        helper.execute();
    }

    void setData() {
        //attribute
        if (addressAttributeModel.getAttributeModelList().size() > 0) {
            recyclerViewForCustomAttribute.setVisibility(View.VISIBLE);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
            recyclerViewForCustomAttribute.setLayoutManager(linearLayoutManager);
            attributeListAdapter = new AttributeListAdapter(context, addressAttributeModel.getAttributeModelList(), null, new ArrayList<Integer>(), ns_layout_main);
            recyclerViewForCustomAttribute.setAdapter(attributeListAdapter);
        } else {
            recyclerViewForCustomAttribute.setVisibility(View.GONE);
        }

        //country
        if (addressAttributeModel.isCountryEnabled()) {
            dropDownForCountry.setVisibility(View.VISIBLE);
            dropDownForCountry.setHint(Html.fromHtml("Select Country <font color='#EE0000'>*</font>"));
            ArrayList<String> stringArrayList = new ArrayList<>();

            for (int i = 0; i < addressAttributeModel.getCountryModelList().size(); i++) {
                CountryListModel model = addressAttributeModel.getCountryModelList().get(i);
                stringArrayList.add(model.getStrText());
            }

            ArrayAdapter aa = new ArrayAdapter(context, android.R.layout.simple_spinner_item, stringArrayList);
            aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dropDownForCountry.setAdapter(aa);


            for (int i = 0; i < addressAttributeModel.getCountryModelList().size(); i++) {
                CountryListModel model = addressAttributeModel.getCountryModelList().get(i);
                if (model.isSelected()) {
                    dropDownForCountry.setSelection(i, false);
                }
            }

            dropDownForCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (selection++ > 1) {
                        addressAttributeModel.setSelectedCountry(addressAttributeModel.getCountryModelList().get(position));
                        callApiForGetStates(addressAttributeModel.getCountryModelList().get(position).getStrValue());
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }

        //state
        if (addressAttributeModel.isStateProvinceEnabled()) {
            dropDownForState.setVisibility(View.VISIBLE);
            dropDownForState.setHint(Html.fromHtml("Select State <font color='#EE0000'>*</font>"));
            ArrayList<String> stringArrayList = new ArrayList<>();
            for (int i = 0; i < addressAttributeModel.getStateModelList().size(); i++) {
                StateListModel model = addressAttributeModel.getStateModelList().get(i);
                stringArrayList.add(model.getStrText());
            }

            ArrayAdapter aa = new ArrayAdapter(context, android.R.layout.simple_spinner_item, stringArrayList);
            aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            dropDownForState.setItem(stringArrayList);

            for (int i = 0; i < addressAttributeModel.getStateModelList().size(); i++) {
                StateListModel model = addressAttributeModel.getStateModelList().get(i);
                if (model.isSelected()) {
                    dropDownForState.setSelection(i, false);
                }
            }

            dropDownForState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    addressAttributeModel.setSelectedState(addressAttributeModel.getStateModelList().get(position));
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }

        //Company
        if (addressAttributeModel.isCompanyEnable()) {
            txtInputCompany.setVisibility(View.VISIBLE);
            if (addressAttributeModel.isCompanyRequired()) {
                txtInputCompany.setHint(Html.fromHtml("Company <font color='#EE0000'>*</font>"));
            }
        }

        //County
        if (addressAttributeModel.isCountyEnabled()) {
            txtInputCounty.setVisibility(View.VISIBLE);
            if (addressAttributeModel.isCountyRequired()) {
                txtInputCounty.setHint(Html.fromHtml("County <font color='#EE0000'>*</font>"));
            }
        }

        //City
        if (addressAttributeModel.isCityEnabled()) {
            txtInputCity.setVisibility(View.VISIBLE);
            if (addressAttributeModel.isCityRequired()) {
                txtInputCity.setHint(Html.fromHtml("City <font color='#EE0000'>*</font>"));
            }
        }

        //Address1
        if (addressAttributeModel.isAddressLineEnabled()) {
            txtInputAddress1.setVisibility(View.VISIBLE);
            if (addressAttributeModel.isAddressLineRequired()) {
                txtInputAddress1.setHint(Html.fromHtml("Address 1 <font color='#EE0000'>*</font>"));
            }
        }

        //Address2
        if (addressAttributeModel.isAddressLine2Enabled()) {
            txtInputAddress2.setVisibility(View.VISIBLE);
            if (addressAttributeModel.isAddressLine2Required()) {
                txtInputAddress2.setHint(Html.fromHtml("Address 2 <font color='#EE0000'>*</font>"));
            }
        }

        //Zip Code
        if (addressAttributeModel.isZipPostalCodeEnabled()) {
            txtInputZipCode.setVisibility(View.VISIBLE);
            if (addressAttributeModel.isZipPostalCodeRequired()) {
                txtInputZipCode.setHint(Html.fromHtml("Zip Code <font color='#EE0000'>*</font>"));
            }
        }

        //Phone Number
        if (addressAttributeModel.isPhoneEnabled()) {
            txtInputPhoneNumber.setVisibility(View.VISIBLE);
            if (addressAttributeModel.isPhoneRequired()) {
                txtInputPhoneNumber.setHint(Html.fromHtml("Phone Number <font color='#EE0000'>*</font>"));
            }
        }

        //Fax Number
        if (addressAttributeModel.isFaxEnabled()) {
            txtInputFax.setVisibility(View.VISIBLE);
            if (addressAttributeModel.isFaxRequired()) {
                txtInputFax.setHint(Html.fromHtml("Fax Number <font color='#EE0000'>*</font>"));
            }
        }

        layoutLoading.setVisibility(View.GONE);
        layoutMain.setVisibility(View.VISIBLE);
        btnSave.setVisibility(View.VISIBLE);
    }

    void onClickSave() {
        boolean isError = false;
        txtInputFirstName.setErrorEnabled(false);
        txtInputLastName.setErrorEnabled(false);
        txtInputEmail.setErrorEnabled(false);
        txtInputCompany.setErrorEnabled(false);
        txtInputCounty.setErrorEnabled(false);
        txtInputCity.setErrorEnabled(false);
        txtInputAddress1.setErrorEnabled(false);
        txtInputAddress2.setErrorEnabled(false);
        txtInputZipCode.setErrorEnabled(false);
        txtInputPhoneNumber.setErrorEnabled(false);
        txtInputFax.setErrorEnabled(false);
        dropDownForCountry.setEnableErrorLabel(false);
        dropDownForState.setEnableErrorLabel(false);


        if (editFirstName.getText().toString().isEmpty()) {
            txtInputFirstName.setErrorEnabled(true);
            txtInputFirstName.setError("First Name Is Required");
            isError = true;
        }
        if (editLastName.getText().toString().isEmpty()) {
            txtInputLastName.setErrorEnabled(true);
            txtInputLastName.setError("Last Name Is Required");
            isError = true;
        }
        if (editEmail.getText().toString().isEmpty()) {
            txtInputEmail.setErrorEnabled(true);
            txtInputEmail.setError("Email Is Required");
            isError = true;
        }
        if (addressAttributeModel.isCompanyEnable() && addressAttributeModel.isCompanyRequired()) {
            if (editCompany.getText().toString().isEmpty()) {
                txtInputCompany.setErrorEnabled(true);
                txtInputCompany.setError("Company Name Is Required");
                isError = true;
            }
        }
        if (addressAttributeModel.isCountyEnabled() && addressAttributeModel.isCountyRequired()) {
            if (editCounty.getText().toString().isEmpty()) {
                txtInputCounty.setErrorEnabled(true);
                txtInputCounty.setError("County Is Required");
                isError = true;
            }
        }
        if (addressAttributeModel.isCityEnabled() && addressAttributeModel.isCityRequired()) {
            if (editCity.getText().toString().isEmpty()) {
                txtInputCity.setErrorEnabled(true);
                txtInputCity.setError("City Is Required");
                isError = true;
            }
        }
        if (addressAttributeModel.isAddressLineEnabled() && addressAttributeModel.isAddressLineRequired()) {
            if (editAddress1.getText().toString().isEmpty()) {
                txtInputAddress1.setErrorEnabled(true);
                txtInputAddress1.setError("Address 1 Is Required");
                isError = true;
            }
        }
        if (addressAttributeModel.isAddressLine2Enabled() && addressAttributeModel.isAddressLine2Required()) {
            if (editAddress2.getText().toString().isEmpty()) {
                txtInputAddress2.setErrorEnabled(true);
                txtInputAddress2.setError("Address 2 Is Required");
                isError = true;
            }
        }
        if (addressAttributeModel.isZipPostalCodeEnabled() && addressAttributeModel.isZipPostalCodeRequired()) {
            if (editZipCode.getText().toString().isEmpty()) {
                txtInputZipCode.setErrorEnabled(true);
                txtInputZipCode.setError("Zip Code Is Required");
                isError = true;
            }
        }
        if (addressAttributeModel.isPhoneEnabled() && addressAttributeModel.isPhoneRequired()) {
            if (editPhoneNumber.getText().toString().isEmpty()) {
                txtInputPhoneNumber.setErrorEnabled(true);
                txtInputPhoneNumber.setError("Phone Number Is Required");
                isError = true;
            }
        }
        if (addressAttributeModel.isFaxEnabled() && addressAttributeModel.isFaxRequired()) {
            if (editFax.getText().toString().isEmpty()) {
                txtInputFax.setErrorEnabled(true);
                txtInputFax.setError("Fax Number Is Required");
                isError = true;
            }
        }

        if (addressAttributeModel.isCountryEnabled() && addressAttributeModel.isCountryRequire()) {
            if (addressAttributeModel.getSelectedCountry() == null) {
                dropDownForCountry.setEnableErrorLabel(true);
                dropDownForCountry.setErrorText("Country Is Required");
                dropDownForCountry.setErrorTextColor(getResources().getColor(android.R.color.holo_red_light));
                isError = true;
            }
        }
        if (addressAttributeModel.isStateProvinceEnabled() && addressAttributeModel.isStateProvinceEnabled()) {
            if (addressAttributeModel.getSelectedState() == null) {
                dropDownForState.setEnableErrorLabel(true);
                dropDownForState.setErrorText("State Is Required");
                dropDownForState.setErrorTextColor(getResources().getColor(android.R.color.holo_red_light));
                isError = true;
            }
        }

        boolean isErrorInAttribute = conditionForAttribute();
        if (isErrorInAttribute) {
            attributeListAdapter.notifyDataSetChanged();
        }
        if (!isError && !isErrorInAttribute) {

            try {
                callApiToSaveAddress();

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    boolean conditionForAttribute() {
        ArrayList<Boolean> errorList = new ArrayList<>();
        for (int i = 0; i < addressAttributeModel.getAttributeModelList().size(); i++) {
            AttributeModel model = addressAttributeModel.getAttributeModelList().get(i);
            if (model.getAttributeType() == 1 || model.getAttributeType() == 2 || model.getAttributeType() == 40 || model.getAttributeType() == 45) {
                boolean isError = conditionForSingleValue(model);
                if (isError) {
                    errorList.add(true);
                }
            } else if (model.getAttributeType() == 3) {
                boolean isError = conditionForMultiValue(model);
                if (isError) {
                    errorList.add(true);
                }
            } else if (model.getAttributeType() == 4 || model.getAttributeType() == 10 || model.getAttributeType() == 20 || model.getAttributeType() == 30) {
                boolean isError = conditionForStringValue(model);
                if (isError) {
                    errorList.add(true);
                }
            }
        }
        if (errorList.size() > 0) {
            return true;
        }
        return false;
    }

    boolean conditionForSingleValue(AttributeModel model) {
        if (model.isRequired()) {
            if (model.getCurrentValueModel() == null) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel() + " Is Required");
                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    boolean conditionForMultiValue(AttributeModel model) {
        if (model.isRequired()) {
            if (model.getSelectedValueModelList() == null || model.getSelectedValueModelList().size() == 0) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel() + " Is Required");
                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    boolean conditionForStringValue(AttributeModel model) {
        if (model.isRequired()) {
            if (model.getCurrentValue() == null || model.getCurrentValue().isEmpty()) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel() + " Is Required");
                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    void callApiForGetStates(String countryId) {
        JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "customers/getstatesbycountryid?countryId=" + countryId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("StateList") && !jsonObject.isNull("StateList")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("StateList");
                        ArrayList<StateListModel> stateListModels = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            StateListModel state = new StateListModel();
                            state.parse(object);
                            stateListModels.add(state);
                        }
                        addressAttributeModel.setStateModelList(stateListModels);

                        ArrayList<String> stringArrayList = new ArrayList<>();
                        for (int i = 0; i < addressAttributeModel.getStateModelList().size(); i++) {
                            StateListModel model = addressAttributeModel.getStateModelList().get(i);
                            if (model.isSelected()) {
                                dropDownForCountry.setSelection(i, false);
                            }
                            if (model.getStrText() != null) {
                                stringArrayList.add(model.getStrText());
                            }
                        }
                        ArrayAdapter aa = new ArrayAdapter(context, android.R.layout.simple_spinner_item, stringArrayList);
                        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        dropDownForState.setAdapter(aa);

                    }
                }
            }
        }, true);
        helper.execute();
    }

    void callApiToSaveAddress() throws UnsupportedEncodingException, JSONException {
        userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);
        JSONArray attributeString = makeRequestStringForConditionalAttribute(addressAttributeModel.getAttributeModelList());

        JSONObject jsonObject = new JSONObject();

        if (getIntent().getStringExtra(Constants.INTENT_ADDRESS_MODEL) != null) {
            jsonObject.put("AddressId", addressId);
        }
        jsonObject.put("FirstName", editFirstName.getText().toString());
        jsonObject.put("LastName", editLastName.getText().toString());
        jsonObject.put("Email", editEmail.getText().toString());
        jsonObject.put("Company", editCompany.getText().toString());
        jsonObject.put("County", editCounty.getText().toString());
        jsonObject.put("City", editCity.getText().toString());
        jsonObject.put("Address1", editAddress1.getText().toString());
        jsonObject.put("Address2", editAddress2.getText().toString());
        jsonObject.put("ZipPostalCode", editZipCode.getText().toString());
        jsonObject.put("PhoneNumber", editPhoneNumber.getText().toString());
        jsonObject.put("FaxNumber", editFax.getText().toString());
        jsonObject.put("CountryId", addressAttributeModel.getSelectedCountry().getStrValue());
        jsonObject.put("StateProvinceId", addressAttributeModel.getSelectedState().getStrValue());
        jsonObject.put("customattrributeList", attributeString);
        jsonObject.put("customerId", userId);

        String url;
        if (getIntent().getStringExtra(Constants.INTENT_ADDRESS_MODEL) != null) {
            url = Config.BASE_URL + "customers/updatecustomeraddress1";

        } else {
            url = Config.BASE_URL + "customers/createcustomeraddress1";
        }

        JSONHelper helper = new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("errorcode") && !jsonObject.isNull("errorcode")) {
                        if (jsonObject.getString("errorcode").equals("0")) {
                            Constants.isLoadingForAddress = true;
                            finish();
                        }
                    }
                    if (jsonObject.has("message") && !jsonObject.isNull("message")) {
                        Toast.makeText(context, "" + jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, true, jsonObject);
        helper.execute();
    }

    void callApiToGetAddressFromAddressId(final String addressId) {
        userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);
        JSONHelper jsonHelper = new JSONHelper(context, Config.BASE_URL + "customers/getaddressbyid?addressId=" + addressId + "&CustomerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    Constants.isLoadingForAddress = false;
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Address") && !jsonObject.isNull("Address")) {
                        JSONObject obj = jsonObject.getJSONObject("Address");
                        addressAttributeModel = new AddressAttributeModel();
                        addressAttributeModel.parse(obj);
                    }
                } else {
                    Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
                }
                editAddress();
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);

            }
        }, false);
        jsonHelper.execute();
    }

    JSONArray makeRequestStringForConditionalAttribute(ArrayList<AttributeModel> attributeModelArrayList) {
        JSONArray value = new JSONArray();
        if (attributeModelArrayList.size() > 0) {
            for (int i = 0; i < attributeModelArrayList.size(); i++) {
                AttributeModel model = attributeModelArrayList.get(i);
                model.setChecked(0);
                if (model.getAttributeType() == 1 || model.getAttributeType() == 2 || model.getAttributeType() == 40 || model.getAttributeType() == 45) {
                    String currentValue = "0";

                    if (model.getCurrentValueModel() != null) {
                        currentValue = String.valueOf(model.getCurrentValueModel().getId());
                    }

                    value.put("address_attribute_" + model.getId() + "_" + currentValue);
                }
                if (model.getAttributeType() == 3 || model.getAttributeType() == 50) {
                    String currentValue = "0";
                    for (int j = 0; j < model.getSelectedValueModelList().size(); j++) {
                        if (j == model.getSelectedValueModelList().size() - 1) {
                            currentValue += String.valueOf(model.getSelectedValueModelList().get(j).getId());
                        } else {
                            currentValue += String.valueOf(model.getSelectedValueModelList().get(j).getId()) + ":";
                        }
                    }

                    value.put("address_attribute_" + model.getId() + "_" + currentValue);
                }

                if (model.getAttributeType() == 4 || model.getAttributeType() == 10 || model.getAttributeType() == 20) {
                    String currentValue = "";

                    if (model.getCurrentValue() != null) {
                        currentValue = model.getCurrentValue();
                    }

                    value.put("address_attribute_" + model.getId() + "_" + currentValue);
                }
            }
            Log.i(TAG, "makeRequestStringForConditionalAttribute: " + value);
        }
        return value;
    }

    void editAddress() {
        if (addressAttributeModel.getFirstName() != null) {
            editFirstName.setText(addressAttributeModel.getFirstName());
        }
        if (addressAttributeModel.getLastName() != null) {
            editLastName.setText(addressAttributeModel.getLastName());
        }
        if (addressAttributeModel.getFirstName() != null) {
            editFirstName.setText(addressAttributeModel.getFirstName());
        }
        if (addressAttributeModel.getEmail() != null) {
            editEmail.setText(addressAttributeModel.getEmail());
        }
        if (addressAttributeModel.getCompany() != null) {
            editCompany.setText(addressAttributeModel.getCompany());
        }
        if (addressAttributeModel.getCountyName() != null) {
            editCounty.setText(addressAttributeModel.getCountyName());
        }
        if (addressAttributeModel.getCity() != null) {
            editCity.setText(addressAttributeModel.getCity());
        }
        if (addressAttributeModel.getAddressLine1() != null) {
            editAddress1.setText(addressAttributeModel.getAddressLine1());
        }
        if (addressAttributeModel.getAddressLine2() != null) {
            editAddress2.setText(addressAttributeModel.getAddressLine2());
        }
        if (addressAttributeModel.getPhoneNumber() != null) {
            editPhoneNumber.setText(addressAttributeModel.getPhoneNumber());
        }

        setData();
    }
}

