package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.ProductListActivity;
import com.testDemo.global.Constants;
import com.testDemo.model.ManufacturerModel;

import java.util.ArrayList;

public class BrandListAdapter extends RecyclerView.Adapter<BrandListAdapter.ViewHolder> {
    Context context;
    ArrayList<ManufacturerModel> designerCollection;


    public BrandListAdapter(Context context, ArrayList<ManufacturerModel> designerCollection) {
        this.context = context;
        this.designerCollection = designerCollection;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.brand_list_layout_brand, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final ManufacturerModel myListData = designerCollection.get(position);
        if (myListData != null && myListData.getImage() != null && !myListData.getImage().isEmpty()) {
            Glide.with(holder.itemView)
                    .load(myListData.getImage())
                    .into(holder.iv_product_image);
        }

        holder.ll_brand_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ProductListActivity.class);
                try {
                    intent.putExtra(Constants.INTENT_FOR_ID,myListData.getId());
                    intent.putExtra(Constants.INTENT_FOR_TITLE,myListData.getName());
                    intent.putExtra(Constants.IF_FROM_BRAND_LIST,true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                context.startActivity(intent);
                // TODO: 18/10/2019 comment code for some time
//                context.startActivity(new Intent(context, ProductListActivity.class).putExtra("product_category", myListData.getName()).putExtra("product_id", myListData.getId()).putExtra(Constants.IF_FROM_BRAND_LIST, true));
            }
        });
    }


    @Override
    public int getItemCount() {
        return designerCollection.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_product_image;
        LinearLayout ll_brand_item;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            iv_product_image = (ImageView) itemView.findViewById(R.id.iv_product_image);
            ll_brand_item = (LinearLayout) itemView.findViewById(R.id.ll_brand_item);
        }
    }


}