package com.testDemo.activites;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.testDemo.R;
import com.testDemo.adapter.MyProductReviewAdapter;
import com.testDemo.adapter.SearchProductAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.PaginationScrollListener;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ReviewModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MyReviewListActivity extends AppCompatActivity implements View.OnClickListener {

    Activity context = MyReviewListActivity.this;
    String TAG = getClass().getSimpleName();

    Toolbar toolbar;

    RecyclerView rcv_product_review_list;

    ArrayList<ReviewModel> reviewModelArrayList = new ArrayList<>();

    MyProductReviewAdapter myProductReviewAdapter;

    LinearLayoutManager linearLayoutManager;

    LinearLayout layoutLoading;
    LinearLayout layoutMain;
    LinearLayout layoutEmptyData;
    LinearLayout layoutError;
    LinearLayout layoutNoInternet;
    Button btnReload;
    String userId;

    ProgressBar loader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_review_list);

        userId = SharedPrefsUtils.getStringPreference(MyReviewListActivity.this, Constants.PREF_USER_ID);

        Log.d(TAG,userId);

        findViewById();

        toolbarInit();

        callApi();

    }

    private void findViewById()
    {
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutMain = findViewById(R.id.layoutMain);
        layoutEmptyData = findViewById(R.id.layoutEmptyData);
        layoutError = findViewById(R.id.layoutError);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        btnReload = findViewById(R.id.btnReload);
        rcv_product_review_list = findViewById(R.id.rcv_product_review_list);

        btnReload.setOnClickListener(this);
    }

    private void toolbarInit() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.btnReload:
                callApi();
                break;

        }
    }

    private void callApi() {

        if (Constants.isCheckInternetCon(MyReviewListActivity.this))
        {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);

            callApiForReviewList();
        }
        else
        {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }

    }

    private void callApiForReviewList() {

        String url = Config.BASE_URL+"products/getcustomerproductreviews?customerId="+userId;

        JSONHelper jsonHelper=new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {

                reviewModelArrayList = new ArrayList<>();

                if (result != null && !result.isEmpty())
                {
                    JSONObject jsonObject = new JSONObject(result);

                    if (jsonObject.has("ProductReviews") && !jsonObject.isNull("ProductReviews"))
                    {
                        JSONObject productObject = jsonObject.getJSONObject("ProductReviews");
                        JSONArray jsonArray = productObject.getJSONArray("ProductReviews");

                        for (int i =0;i<jsonArray.length();i++)
                        {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            ReviewModel reviewModel=new ReviewModel();
                            reviewModel.reviewParsing(jsonObject1);
                            reviewModelArrayList.add(reviewModel);
                        }


                        setDataForRecyclerView(reviewModelArrayList);

                    }
                }
                else
                {
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }

            }
        },false);

        jsonHelper.execute();

    }

    private void setDataForRecyclerView(final ArrayList<ReviewModel> reviewModelArrayList) {

        if (reviewModelArrayList.size() == 0) {
            layoutMain.setVisibility(View.GONE);
        } else {

                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
                linearLayoutManager = new LinearLayoutManager(this);
                rcv_product_review_list.setLayoutManager(linearLayoutManager);
                myProductReviewAdapter = new MyProductReviewAdapter(this, this.reviewModelArrayList,MyReviewListActivity.this);
                rcv_product_review_list.setAdapter(myProductReviewAdapter);
            }
        }

    }


