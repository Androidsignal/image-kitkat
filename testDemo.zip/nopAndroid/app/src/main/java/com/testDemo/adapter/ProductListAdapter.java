package com.testDemo.adapter;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.activites.CartScreen;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.activites.ProductListScreen;
import com.testDemo.activites.SubCategoryRelatedActivity;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ProductListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Context context;
    ArrayList<ProductModel> designerCollection;
    ProductListScreen.OnClickProduct onClickProduct;
    SubCategoryRelatedActivity.OnClickProductSubCategory onClickProductSubCategory;
    private static final int ITEM = 0;
    private static final int LOADING = 1;
    private boolean isLoadingAdded = false;


    public ProductListAdapter(Context context, ArrayList<ProductModel> designerCollection, ProductListScreen.OnClickProduct onClickProduct, SubCategoryRelatedActivity.OnClickProductSubCategory onClickProductSubCategory) {
        this.context = context;
        this.designerCollection = designerCollection;
        this.onClickProduct = onClickProduct;
        this.onClickProductSubCategory = onClickProductSubCategory;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        switch (viewType) {
            case ITEM:
                viewHolder = getViewHolder(parent, inflater);
                break;
            case LOADING:
                View v2 = inflater.inflate(R.layout.item_progress, parent, false);
                viewHolder = new LoadingVH(v2);
                break;
        }
        return viewHolder;
    }

    @NonNull
    private RecyclerView.ViewHolder getViewHolder(ViewGroup parent, LayoutInflater inflater) {
        RecyclerView.ViewHolder viewHolder;
        View v1 = inflater.inflate(R.layout.designer_product_row_layout, parent, false);
        viewHolder = new ViewHolder(v1);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final ProductModel myListData = designerCollection.get(position);
        switch (getItemViewType(position)) {
            case ITEM:
                final ViewHolder viewHolder = (ViewHolder) holder;
                viewHolder.tv_product_price.setText(myListData.getProductPrice());
                viewHolder.tv_product_name.setText(myListData.getProductName());
                Glide.with(holder.itemView)
                        .load(myListData.getProductImage())
                        .into(viewHolder.iv_product_image);
                viewHolder.cardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        try {
                            if (onClickProduct != null) {
                                onClickProduct.OnClickProduct(position);
                            }
                            if (onClickProductSubCategory != null) {
                                onClickProductSubCategory.OnClickProductSubCategory(position);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });


                if (myListData.isGetProductInShoppingCart()) {
                    viewHolder.iv_cart_not_added.setVisibility(View.GONE);
                    viewHolder.iv_cart_added.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.iv_cart_not_added.setVisibility(View.VISIBLE);
                    viewHolder.iv_cart_added.setVisibility(View.GONE);
                }

                viewHolder.iv_cart_not_added.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (myListData.getAttributeModelArrayList() != null && myListData.getAttributeModelArrayList().size() > 0) {
                            Intent i = new Intent(context, ProductDetailActivity.class);
                            i.putExtra(Constants.INTENT_PRODUCT_ID, myListData.getProductId().toString());
                            context.startActivity(i);
                        } else {
                            callApiForAddToCart(myListData, viewHolder);
                        }
                    }
                });

                viewHolder.iv_cart_added.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        context.startActivity(new Intent(context, CartScreen.class));
                    }
                });

                break;

            case LOADING:
                LoadingVH loadingViewHolder = (LoadingVH) holder;
                loadingViewHolder.progressBar.setVisibility(View.VISIBLE);
                break;

        }


    }


    @Override
    public int getItemCount() {
//        return designerCollection.size();
        return designerCollection == null ? 0 : designerCollection.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (position == designerCollection.size() - 1 && isLoadingAdded) {
            return LOADING;
        } else {
            return ITEM;
        }

    }

    public void addItems(ArrayList<ProductModel> list) {
        designerCollection.addAll(list);
        notifyDataSetChanged();
    }

    public void addLoadingFooter() {
        isLoadingAdded = true;
        add(new ProductModel());
    }

    public void removeLoadingFooter() {
        isLoadingAdded = false;

        int position = designerCollection.size() - 1;
        ProductModel result = getItem(position);

        if (result != null) {
            designerCollection.remove(position);
            notifyItemRemoved(position);
            notifyDataSetChanged();
        }
    }

    public void add(ProductModel r) {
        designerCollection.add(r);
        notifyItemInserted(designerCollection.size() - 1);
    }

    public ProductModel getItem(int position) {
        return designerCollection.get(position);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iv_product_image;
        TextView tv_product_name, tv_product_price;
        LinearLayout cardView;
        ImageView iv_cart_not_added, iv_cart_added;

        public ViewHolder(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            iv_cart_not_added = (ImageView) itemView.findViewById(R.id.iv_cart_not_added);
            iv_cart_added = (ImageView) itemView.findViewById(R.id.iv_cart_added);
            iv_product_image = (ImageView) itemView.findViewById(R.id.iv_product_image);
            tv_product_name = (TextView) itemView.findViewById(R.id.tv_product_name);
            tv_product_price = (TextView) itemView.findViewById(R.id.tv_product_price);
            cardView =  itemView.findViewById(R.id.cardView);
        }
    }

    protected class LoadingVH extends RecyclerView.ViewHolder {

        ProgressBar progressBar;

        public LoadingVH(View itemView) {
            super(itemView);
            this.setIsRecyclable(false);
            progressBar = (ProgressBar) itemView.findViewById(R.id.loadmore_progress);
        }
    }

    void callApiForAddToCart(final ProductModel myListData, final ViewHolder viewHolder) {
        String userId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_USER_ID);
        String storeId = SharedPrefsUtils.getStringPreference(context, Constants.PREF_SELECTED_STORE);
        String url = Config.BASE_URL +
                "shopping_cart_items/addproducttoshoppingcart?customerId=" + userId +
                "&productId=" + myListData.getProductId() +
                "&shoppingCartTypeId=1&quantity=1&attributeControlIds=&rentalStartDate=null&rentalEndDate=null" + "&storeid=" + storeId;
        new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success")) {
                        if (jsonObject.getBoolean("Success")) {
                            if (jsonObject.has("Message") && !jsonObject.isNull("Message")) {
                                String message = jsonObject.getString("Message");
                                Toast.makeText(context, "" + Html.fromHtml(message), Toast.LENGTH_SHORT).show();
                                myListData.setProductInShoppingCart(true);
                                viewHolder.iv_cart_not_added.setVisibility(View.GONE);
                                viewHolder.iv_cart_added.setVisibility(View.VISIBLE);
                                notifyDataSetChanged();
                            }
                        } else {
                            if (jsonObject.has("message") && !jsonObject.isNull("message")) {
                                String message = jsonObject.getString("message");
                                Toast.makeText(context, "" + Html.fromHtml(message), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        }, true).execute();
    }
}