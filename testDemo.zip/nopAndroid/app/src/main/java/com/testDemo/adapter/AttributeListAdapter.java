package com.testDemo.adapter;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.text.Editable;
import android.text.Html;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.google.android.material.textfield.TextInputLayout;
import com.testDemo.R;
import com.testDemo.activites.ProductDetailActivity;
import com.testDemo.adapter.attributeAdapter.CheckBoxListAdapter;
import com.testDemo.adapter.attributeAdapter.ColorBoxListAdapter;
import com.testDemo.adapter.attributeAdapter.ImageBoxListAdapter;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.AttributeValueModel;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Calendar;

public class AttributeListAdapter extends RecyclerView.Adapter<AttributeListAdapter.ViewHolder> {
    Context context;
    ArrayList<AttributeModel> attributeModelArrayList;
    ArrayList<Integer> hideAttributes;
    ProductDetailActivity productDetailActivity;
    NestedScrollView ns_layout_main;


    public AttributeListAdapter(Context context, ArrayList<AttributeModel> attributeModelArrayList, ProductDetailActivity productDetailActivity, ArrayList<Integer> hideAttributes, NestedScrollView ns_layout_main) {
        this.context = context;
        this.attributeModelArrayList = attributeModelArrayList;
        this.productDetailActivity = productDetailActivity;
        this.hideAttributes = hideAttributes;
        this.ns_layout_main = ns_layout_main;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.attribute_list_card, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @SuppressLint("NewApi")
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final AttributeModel model = attributeModelArrayList.get(position);
        if (model != null && !hideAttributes.contains(model.getMapId())) {
            switch (model.getAttributeType()) {
                case 1://drop down
                    if (model.getError() != null && !model.getError().isEmpty()) {
//                        holder.errorText.setVisibility(View.VISIBLE);
                        holder.dropDown.setErrorText(model.getError());
                        if (ns_layout_main != null)
                            ns_layout_main.smoothScrollTo(0, holder.dropDown.getTop());
                        holder.dropDown.setErrorTextColor(context.getResources().getColor(android.R.color.holo_red_light));

                    }
                    if (model.getAttributeName() != null) {
                        holder.txtAttributeName.setVisibility(View.GONE);
                        holder.dropDown.setHint(model.getAttributeName());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.dropDown.setHint(Html.fromHtml(model.getAttributeName() + " " + next));
                        }

                    }
                    if (model.getValues().size() > 0) {
                        holder.dropDown.setVisibility(View.VISIBLE);
                        ArrayAdapter aa = new ArrayAdapter(context, android.R.layout.simple_spinner_item, model.getValuesInString());
                        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        holder.dropDown.setAdapter(aa);
                        holder.dropDown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                model.setError(null);
                                model.setChecked(model.getChecked() + 1);
                                if (model.getChecked() > 1) {
                                    model.setDropDownPosition(String.valueOf(position));
                                    model.setCurrentValueModel(model.getValues().get(position));
                                    model.setError(null);
                                    holder.errorText.setVisibility(View.GONE);
                                    model.setChecked(0);
                                    if (productDetailActivity != null) {
                                        productDetailActivity.callApiForHideAttributeIds(true);
                                    }
                                }
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {

                            }
                        });
                        if (model.getDropDownPosition() != null) {
                            holder.dropDown.setSelection(Integer.parseInt(model.getDropDownPosition()), false);
                        } else {
                            model.setChecked(1);
                        }
                    }

                    break;
                case 2://radio group
                    if (model.getError() != null && !model.getError().isEmpty()) {
                        holder.errorText.setVisibility(View.VISIBLE);
                        if (ns_layout_main != null)
                            ns_layout_main.smoothScrollTo(0, holder.errorText.getTop());
                        holder.errorText.setText(model.getError());
                    }
                    if (model.getAttributeName() != null) {
                        holder.txtAttributeName.setVisibility(View.VISIBLE);
                        holder.txtAttributeName.setText(model.getAttributeName());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeName() + " " + next));
                        }
                    }

                    if (model.getValues().size() > 0) {
                        for (int i = 0; i < model.getValues().size(); i++) {
                            AttributeValueModel valueModel = model.getValues().get(i);

                            RadioButton radioButton = new RadioButton(context);
                            radioButton.setText(valueModel.getName());
                            radioButton.setId(valueModel.getId());
                            radioButton.setActivated(valueModel.isPreSelected());
                            if (model.getCurrentValueModel() != null && valueModel.getId() == model.getCurrentValueModel().getId()) {
                                radioButton.setChecked(true);
                            }
                            RadioGroup.LayoutParams layoutParam = new RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                            holder.radioGroup.addView(radioButton, layoutParam);
                        }
                        holder.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                            @Override
                            public void onCheckedChanged(RadioGroup group, int checkedId) {
                                for (AttributeValueModel model1 : model.getValues()) {
                                    if (model1.getId() == checkedId) {
                                        model.setCurrentValueModel(model1);
                                        model.setError(null);
                                        holder.errorText.setVisibility(View.GONE);
                                        if (productDetailActivity != null) {
                                            productDetailActivity.callApiForHideAttributeIds(true);
                                        }/*else{
                                            notifyDataSetChanged();
                                        }*/
                                    }
                                }
                            }
                        });
                    }
                    break;
                case 3://checkbox
                    if (model.getError() != null && !model.getError().isEmpty()) {
                        holder.errorText.setVisibility(View.VISIBLE);
                        holder.errorText.setText(model.getError());
                        if (ns_layout_main != null)
                            ns_layout_main.smoothScrollTo(0, holder.errorText.getTop());
                    }
                    if (model.getAttributeName() != null) {
                        holder.txtAttributeName.setVisibility(View.VISIBLE);
                        holder.txtAttributeName.setText(model.getAttributeName());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeName() + " " + next));
                        }
                    }
                    holder.recyclerView.setVisibility(View.VISIBLE);
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
                    linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
                    holder.recyclerView.setLayoutManager(linearLayoutManager);
                    CheckBoxListAdapter attributeListAdapter = new CheckBoxListAdapter(context, model.getValues(), model, false, this, productDetailActivity);
                    holder.recyclerView.setAdapter(attributeListAdapter);
                    break;
                case 50:// read only checkbox
                    if (model.getAttributeName() != null) {
                        holder.txtAttributeName.setVisibility(View.VISIBLE);
                        holder.txtAttributeName.setText(model.getAttributeName());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeName() + " " + next));
                        }
                    }
                    holder.recyclerView.setVisibility(View.VISIBLE);
                    linearLayoutManager = new LinearLayoutManager(context);
                    linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
                    holder.recyclerView.setLayoutManager(linearLayoutManager);
                    attributeListAdapter = new CheckBoxListAdapter(context, model.getValues(), model, true, this, productDetailActivity);
                    holder.recyclerView.setAdapter(attributeListAdapter);
                    break;
                case 4://textInput
                    EditText editText;
                    if (productDetailActivity == null) {
                        holder.textInputLayoutForAddressAttribute.setVisibility(View.VISIBLE);
                        if (model.getError() != null && !model.getError().isEmpty()) {
                            holder.textInputLayoutForAddressAttribute.setErrorEnabled(true);
                            if (ns_layout_main != null)
                                ns_layout_main.smoothScrollTo(0, holder.textInputLayoutForAddressAttribute.getTop());
                            holder.textInputLayoutForAddressAttribute.setError(model.getError());
                        }
                        if (model.getAttributeName() != null) {
                            holder.textInputLayoutForAddressAttribute.setHint(model.getAttributeName());
                            if (model.isRequired()) {
                                String next = "<font color='#EE0000'>*</font>";
                                holder.textInputLayoutForAddressAttribute.setHint((Html.fromHtml(model.getAttributeName() + " " + next)));
                            }
                        }
                        editText = holder.editTextForAddressAttribute;
                    } else {
                        editText = holder.editText;
                        if (model.getError() != null && !model.getError().isEmpty()) {
                            if (ns_layout_main != null)
                                ns_layout_main.smoothScrollTo(0, holder.editText.getTop());
                            editText.setError(model.getError());
                        }
                        if (model.getAttributeName() != null) {
                            holder.txtAttributeName.setVisibility(View.VISIBLE);
                            holder.txtAttributeName.setText(model.getAttributeName());
                            if (model.isRequired()) {
                                String next = "<font color='#EE0000'>*</font>";
                                holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeName() + " " + next));
                            }
                        }
                    }

                    editText.setVisibility(View.VISIBLE);

                    /*if (model.getAttributeLabel() != null) {
                        holder.editText.setHint(model.getAttributeLabel());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.editText.setHint(Html.fromHtml(model.getAttributeLabel() + " " + next));
                        }
                    }*/

                    if (model.getCurrentValue() != null) {
                        editText.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
                        editText.setMaxLines(1);
                        editText.setText(model.getCurrentValue());
                    }
                    editText.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                            model.setCurrentValue(String.valueOf(s));
                            Log.i("After", "beforeTextChanged: " + s);
                            if (!s.toString().isEmpty()) {
                                model.setError(null);
//                                holder.textInputLayout.setErrorEnabled(false);
                            }
                        }
                    });
                    break;
                case 10://multiline textInput
                    holder.editText.setVisibility(View.VISIBLE);
                    if (model.getError() != null && !model.getError().isEmpty()) {
//                        holder.textInputLayout.setErrorEnabled(true);
                        holder.editText.setError(model.getError());
                        if (ns_layout_main != null)
                            ns_layout_main.smoothScrollTo(0, holder.editText.getTop());
                    }
                    if (model.getAttributeLabel() != null) {
                        holder.txtAttributeName.setVisibility(View.VISIBLE);
                        holder.txtAttributeName.setText(model.getAttributeLabel());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeLabel() + " " + next));
                        }
                    }
                    if (model.getAttributeLabel() != null) {
                        holder.editText.setHint(model.getAttributeLabel());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.editText.setHint(Html.fromHtml(model.getAttributeLabel() + " " + next));
                        }
                    }
                    holder.editText.setLines(2);
                    holder.editText.setSingleLine(false);
                    if (model.getCurrentValue() != null) {
//                        holder.editText.setInputType(InputType.TYPE_CLASS_TEXT);
                        holder.editText.setText(model.getCurrentValue());
                    }
                    holder.editText.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                            model.setCurrentValue(String.valueOf(s));
                            Log.i("After", "beforeTextChanged: " + s);
                            if (!s.toString().isEmpty()) {
                                model.setError(null);
//                                holder.textInputLayout.setErrorEnabled(false);
                            }
                        }
                    });
                    break;
                case 40://color
                    if (model.getError() != null && !model.getError().isEmpty()) {
                        holder.errorText.setVisibility(View.VISIBLE);
                        holder.errorText.setText(model.getError());
                        if (ns_layout_main != null)
                            ns_layout_main.smoothScrollTo(0, holder.errorText.getTop());
                    }
                    if (model.getAttributeName() != null) {
                        holder.txtAttributeName.setVisibility(View.VISIBLE);
                        holder.txtAttributeName.setText(model.getAttributeName());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeName() + " " + next));
                        }
                    }
                    if (model.getValues().size() > 0) {
                        holder.recyclerView.setVisibility(View.VISIBLE);
                        linearLayoutManager = new LinearLayoutManager(context);
                        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
                        holder.recyclerView.setLayoutManager(linearLayoutManager);
                        ColorBoxListAdapter colorBoxListAdapter = new ColorBoxListAdapter(context, model, this, productDetailActivity);
                        holder.recyclerView.setAdapter(colorBoxListAdapter);
                    }
                    break;
                case 45:// image square
                    if (model.getError() != null && !model.getError().isEmpty()) {
                        holder.errorText.setVisibility(View.VISIBLE);
                        holder.errorText.setText(model.getError());
                        if (ns_layout_main != null)
                            ns_layout_main.smoothScrollTo(0, holder.errorText.getTop());
                    }
                    if (model.getAttributeName() != null) {
                        holder.txtAttributeName.setVisibility(View.VISIBLE);
                        holder.txtAttributeName.setText(model.getAttributeName());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeName() + " " + next));
                        }
                    }
                    if (model.getValues().size() > 0) {
                        holder.recyclerView.setVisibility(View.VISIBLE);
                        linearLayoutManager = new LinearLayoutManager(context);
                        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
                        holder.recyclerView.setLayoutManager(linearLayoutManager);
                        ImageBoxListAdapter imageBoxListAdapter = new ImageBoxListAdapter(context, model, this, productDetailActivity);
                        holder.recyclerView.setAdapter(imageBoxListAdapter);
                    }
                    break;
                case 20: // date picker
                    if (model.getError() != null && !model.getError().isEmpty()) {
                        holder.errorText.setVisibility(View.VISIBLE);
                        holder.errorText.setText(model.getError());
                        if (ns_layout_main != null)
                            ns_layout_main.smoothScrollTo(0, holder.errorText.getTop());
                    }
                    if (model.getAttributeLabel() != null) {
                        holder.txtAttributeName.setVisibility(View.VISIBLE);
                        holder.txtAttributeName.setText(model.getAttributeLabel());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeLabel() + " " + next));
                        }
                    }
                    holder.cardViewForDate.setVisibility(View.VISIBLE);
                    if (model.getCurrentValue() != null) {
                        holder.txtDate.setText(model.getCurrentValue());
                    }
                    holder.cardViewForDate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // Get Current Date
                            final Calendar c = Calendar.getInstance();
                            int mYear = c.get(Calendar.YEAR);
                            int mMonth = c.get(Calendar.MONTH);
                            int mDay = c.get(Calendar.DAY_OF_MONTH);

                            DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                                    new DatePickerDialog.OnDateSetListener() {
                                        @Override
                                        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                            model.setCurrentValue((monthOfYear + 1) + "/" + dayOfMonth + "/" + year);
                                            model.setError(null);
                                            notifyDataSetChanged();
                                        }
                                    }, mYear, mMonth, mDay);
                            datePickerDialog.show();
                        }
                    });
                    break;
                case 30: // file chooser
                    if (model.getError() != null && !model.getError().isEmpty()) {
                        holder.errorText.setVisibility(View.VISIBLE);
                        holder.errorText.setText(model.getError());
                        if (ns_layout_main != null)
                            ns_layout_main.smoothScrollTo(0, holder.errorText.getTop());
                    }
                    if (model.getAttributeLabel() != null) {
                        holder.txtAttributeName.setVisibility(View.VISIBLE);
                        holder.txtAttributeName.setText(model.getAttributeLabel());
                        if (model.isRequired()) {
                            String next = "<font color='#EE0000'>*</font>";
                            holder.txtAttributeName.setText(Html.fromHtml(model.getAttributeLabel() + " " + next));
                        }
                    }
                    holder.cardViewForUploadFile.setVisibility(View.VISIBLE);
                    if (model.getCurrentValue() != null) {
                        holder.txtFileName.setText(model.getCurrentValue());
                    }
                    holder.cardViewForUploadFile.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (productDetailActivity != null) {
                                productDetailActivity.chooseFile(position);
                            }
                        }
                    });
                    break;

            }
        }
    }

    @Override
    public int getItemCount() {
        return attributeModelArrayList.size();
    }

    public void updateHideAttributeList(ArrayList<Integer> hideAttributes) {
        this.hideAttributes = hideAttributes;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        CardView cardView;
        CardView cardViewForDate;
        CardView cardViewForUploadFile;
        TextInputLayout textInputLayoutForAddressAttribute;
        EditText editText;
        EditText editTextForAddressAttribute;
        TextView txtAttributeName;
        TextView txtFileName;
        SmartMaterialSpinner dropDown;
        RadioGroup radioGroup;
        RecyclerView recyclerView;
        TextView txtDate;
        TextView errorText;


        public ViewHolder(View itemView) {
            super(itemView);

            this.setIsRecyclable(false);

            cardView = itemView.findViewById(R.id.cardView);
            textInputLayoutForAddressAttribute = itemView.findViewById(R.id.textInputLayoutForAddressAttribute);
            editTextForAddressAttribute = itemView.findViewById(R.id.editTextForAddressAttribute);
            editText = itemView.findViewById(R.id.editText);
            txtAttributeName = itemView.findViewById(R.id.txtAttributeName);
            txtFileName = itemView.findViewById(R.id.txtFileName);
            dropDown = itemView.findViewById(R.id.dropDown);
            radioGroup = itemView.findViewById(R.id.radioGroup);
            recyclerView = itemView.findViewById(R.id.recyclerView);
            txtDate = itemView.findViewById(R.id.txtDate);
            errorText = itemView.findViewById(R.id.errorText);
            cardViewForDate = itemView.findViewById(R.id.cardViewForDate);
            cardViewForUploadFile = itemView.findViewById(R.id.cardViewForUploadFile);
        }
    }
}