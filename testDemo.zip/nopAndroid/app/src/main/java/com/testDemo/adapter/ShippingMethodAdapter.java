package com.testDemo.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.testDemo.R;
import com.testDemo.model.AddressModel;
import com.testDemo.model.ShippingMethodModel;

import java.util.ArrayList;

public class ShippingMethodAdapter extends RecyclerView.Adapter<ShippingMethodAdapter.ViewHolder> {

    Context context;
    ArrayList<ShippingMethodModel> arrayList;

    String selectedItem = "0";

    public ShippingMethodAdapter(Context context, ArrayList<ShippingMethodModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.shipping_method_list_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        ShippingMethodModel model = arrayList.get(position);
        if (model != null) {
            if (model.getName() != null) {
                holder.txtName.setText(Html.fromHtml(model.getName()));
            } else {
                holder.txtName.setVisibility(View.GONE);
            }
            if (model.getDescription() != null) {
                holder.txtDescription.setText(Html.fromHtml(model.getDescription()));
            } else {
                holder.txtDescription.setVisibility(View.GONE);
            }

            if (selectedItem == null && model.isSelected()) {
                selectedItem = String.valueOf(position);
                holder.cardView.setBackgroundColor(context.getResources().getColor(R.color.icon_color));
                holder.radioButton.setSelected(true);
            } else if (selectedItem != null &&selectedItem.equals(String.valueOf(position))) {
                holder.cardView.setBackgroundColor(context.getResources().getColor(R.color.icon_color));
                holder.radioButton.setSelected(true);
            } else {
                holder.radioButton.setSelected(false);
                holder.cardView.setBackgroundColor(context.getResources().getColor(android.R.color.transparent));
            }

            holder.cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedItem = String.valueOf(position);
                    notifyDataSetChanged();
                }
            });
        } else {
            holder.cardView.setVisibility(View.GONE);
        }
    }

    public String getSelectedItem() {
        return selectedItem;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        CardView cardView;
        RadioButton radioButton;
        TextView txtName;
        TextView txtDescription;

        public ViewHolder(View itemView) {
            super(itemView);

            this.setIsRecyclable(false);

            cardView = itemView.findViewById(R.id.cardView);
            radioButton = itemView.findViewById(R.id.radioButton);
            txtName = itemView.findViewById(R.id.txtName);
            txtDescription = itemView.findViewById(R.id.txtDescription);

        }
    }
}