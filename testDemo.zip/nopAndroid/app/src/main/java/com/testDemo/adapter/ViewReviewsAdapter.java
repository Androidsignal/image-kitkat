package com.testDemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.testDemo.R;
import com.testDemo.model.ViewReviewsModel;

import java.util.ArrayList;

public class ViewReviewsAdapter extends RecyclerView.Adapter<ViewReviewsAdapter.ViewHolder>
{
    Context context;
    ArrayList<ViewReviewsModel> reviewsModelslist;

    public ViewReviewsAdapter(Context context, ArrayList<ViewReviewsModel> reviewsModelslist) {
        this.context = context;
        this.reviewsModelslist = reviewsModelslist;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View listreview = layoutInflater.inflate(R.layout.design_view_reviews, parent, false);
        ViewReviewsAdapter.ViewHolder viewHolder = new ViewReviewsAdapter.ViewHolder(listreview);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ViewReviewsModel reviewsModel=reviewsModelslist.get(position);
        holder.title.setText(reviewsModel.getTitle());
        holder.reviewtext.setText(reviewsModel.getReviewsText());
        holder.ratingBar.setRating(reviewsModel.getRating());
        holder.like.setText(reviewsModel.getLike());
        holder.dislike.setText(reviewsModel.getDislike());
        holder.username.setText(reviewsModel.getUsername());


    }

    @Override
    public int getItemCount() {
        return reviewsModelslist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView title, reviewtext,like, dislike, username;
        RatingBar ratingBar;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.tv_title);
            reviewtext=itemView.findViewById(R.id.tv_reviewstext);
            like=itemView.findViewById(R.id.tv_like);
            dislike=itemView.findViewById(R.id.tv_dislike);
            ratingBar=itemView.findViewById(R.id.rb_ratings);
            username=itemView.findViewById(R.id.tv_username) ;
        }
    }
}
