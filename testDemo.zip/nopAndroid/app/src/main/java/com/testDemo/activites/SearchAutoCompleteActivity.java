package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.testDemo.R;
import com.testDemo.adapter.SearchProductAdapter;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.ProductModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SearchAutoCompleteActivity extends AppCompatActivity {

    String TAG = getClass().getSimpleName();
    Activity context = SearchAutoCompleteActivity.this;

    Toolbar toolbar;

    EditText searchEditText;

    LinearLayout layoutMain;
    LinearLayout layoutNoInternet;
    LinearLayout layoutError;

    RecyclerView searchProductsView;

    LinearLayoutManager searchLayoutManager;

    SearchProductAdapter searchProductAdapter;

    ArrayList<ProductModel> searchList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_auto_complete);

        findViewById();

        toolbarInit();

        applySearchFilter();

    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.back_rounded);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void findViewById() {
        toolbar = findViewById(R.id.toolbar);
        searchProductsView = findViewById(R.id.searchProducts);
        searchEditText = findViewById(R.id.searchEditText);
        layoutMain = findViewById(R.id.layoutMain);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutError = findViewById(R.id.layoutError);


        searchLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        searchProductsView.setLayoutManager(searchLayoutManager);
    }

    private void setDataForRecyclerView() {

        if (searchList.size() == 0) {
            layoutMain.setVisibility(View.GONE);
        } else {
            layoutMain.setVisibility(View.VISIBLE);
            searchProductAdapter = new SearchProductAdapter(this, searchList,SearchAutoCompleteActivity.this);
            searchProductsView.setAdapter(searchProductAdapter);
        }

    }

    private void applySearchFilter() {
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {


                if (s.length() >= 3) {
                    Log.d(TAG, s.toString());
                    callApiToGetSearchProducts(s.toString());
                    searchProductsView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

                if (searchEditText.getText().toString().equals("")) {
                    searchProductsView.setVisibility(View.GONE);
                }

            }
        });

        searchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                    Intent intent = new Intent(SearchAutoCompleteActivity.this, SearchResultActivity.class);
                    intent.putExtra("keyword",searchEditText.getText().toString());
                    startActivity(intent);
                    finish();

                    return true;
                }
                return false;
            }
        });
    }

    private void callApiToGetSearchProducts(String keyword) {
        Log.d(TAG, "key word " + keyword);

        String url = Config.BASE_URL + "products/search?parameters=" + keyword;

        JSONHelper jsonHelper = new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {

                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);

                    if (jsonObject.has("SearchProducts") && !jsonObject.isNull("SearchProducts")) {
                        JSONArray searchArrayObj = jsonObject.getJSONArray("SearchProducts");

                        searchList = new ArrayList<>();

                        for (int i = 0; i < searchArrayObj.length(); i++) {
                            JSONObject jsonObject1 = searchArrayObj.getJSONObject(i);
                            ProductModel productModel = new ProductModel();
                            productModel.parseForNewArrival(jsonObject1);
                            searchList.add(productModel);
                        }

                        setDataForRecyclerView();

                    } else {
                        layoutError.setVisibility(View.VISIBLE);
                        layoutMain.setVisibility(View.GONE);
                    }
                } else {
                    layoutError.setVisibility(View.VISIBLE);
                    layoutMain.setVisibility(View.GONE);
                }
            }
        }, false);

        jsonHelper.execute();
    }

    public void onClickProduct(String id) {
        Intent i = new Intent(context, ProductDetailActivity.class);

        i.putExtra(Constants.INTENT_PRODUCT_ID, id);
        startActivity(i);
    }
}
