package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ImageSliderModel {
    private ArrayList<String> sliderImageUrl = new ArrayList<>();

    public ArrayList<String> getSliderImageUrl() {
        return sliderImageUrl;
    }

    public void setSliderImageUrl(ArrayList<String> sliderImageUrl) {
        this.sliderImageUrl = sliderImageUrl;
    }

    @Override
    public String toString() {
        return "ImageSliderModel{" +
                "sliderImageUrl=" + sliderImageUrl +
                '}';
    }

    public void parse(JSONObject jsonObject) throws JSONException {
        if (jsonObject.has("Picture1Url") && !jsonObject.isNull("Picture1Url") && !jsonObject.getString("Picture1Url").toString().isEmpty()) {
            sliderImageUrl.add(jsonObject.getString("Picture1Url"));
        }
        if (jsonObject.has("Picture2Url") && !jsonObject.isNull("Picture2Url") && !jsonObject.getString("Picture2Url").toString().isEmpty()) {
            sliderImageUrl.add(jsonObject.getString("Picture2Url"));
        }
        if (jsonObject.has("Picture3Url") && !jsonObject.isNull("Picture3Url") && !jsonObject.getString("Picture3Url").toString().isEmpty()) {
            sliderImageUrl.add(jsonObject.getString("Picture3Url"));
        }
        if (jsonObject.has("Picture4Url") && !jsonObject.isNull("Picture4Url") && !jsonObject.getString("Picture4Url").toString().isEmpty()) {
            sliderImageUrl.add(jsonObject.getString("Picture4Url"));
        }
        if (jsonObject.has("Picture5Url") && !jsonObject.isNull("Picture5Url") && !jsonObject.getString("Picture5Url").toString().isEmpty()) {
            sliderImageUrl.add(jsonObject.getString("Picture5Url"));
        }
    }
}
