package com.testDemo.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.testDemo.R;
import com.testDemo.activites.SplashActivity;
import com.testDemo.activites.SubCategoryRelatedActivityExample;
import com.testDemo.adapter.AdapterSubcat;
import com.testDemo.adapter.FragmentClick;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.CategoryModel;
import com.testDemo.model.FilterDataModel;
import com.testDemo.model.ManufacturerModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.SpecificationForFilterModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.testDemo.activites.SubCategoryRelatedActivityExample.subDisplayCategory;


public class DynamicFragment extends Fragment implements FragmentClick {

    public RecyclerView rvProduct;
    public TextView textView;
    public List<ProductModel> list = new ArrayList<>();
    public List<String> listImg = new ArrayList<>();
    public int val;
    public LinearLayout layoutLoading, ll_main_layout;
    public String currencyId, storeId;

    public SubCategoryRelatedActivityExample subCategoryRelatedActivityExample;
    public boolean isFilterApplied = false;
    public boolean isLoading = false;


    View view;
    LinearLayout layoutNoDataFound;

    FilterDataModel model;
    String userId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_dynamic, container, false);
        layoutLoading = (LinearLayout) view.findViewById(R.id.layoutLoading);
        userId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_USER_ID);
        layoutNoDataFound = (LinearLayout) view.findViewById(R.id.layoutNoDataFound);
        ll_main_layout = (LinearLayout) view.findViewById(R.id.ll_main_layout);
        if (Constants.isCheckInternetCon(getActivity())) {
            layoutLoading.setVisibility(View.VISIBLE);
            ll_main_layout.setVisibility(View.GONE);
        } else {
            layoutLoading.setVisibility(View.GONE);
        }
        initUI(view);
        return view;
    }

    void findViewById(View view) {
        layoutLoading = (LinearLayout) view.findViewById(R.id.layoutLoading);
        ll_main_layout = (LinearLayout) view.findViewById(R.id.ll_main_layout);
        layoutNoDataFound = (LinearLayout) view.findViewById(R.id.layoutNoDataFound);
        rvProduct = (RecyclerView) view.findViewById(R.id.rvProduct);
        textView = (TextView) view.findViewById(R.id.textView);
    }

    private void initUI(View view) {
        rvProduct = (RecyclerView) view.findViewById(R.id.rvProduct);
        textView = (TextView) view.findViewById(R.id.textView);
        Bundle args = new Bundle();
        val = getArguments().getInt("someInt", 0);
        args.putInt("someInt", val);
        currencyId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_SELECTED_CURRENCY);
        storeId = SharedPrefsUtils.getStringPreference(getActivity(), Constants.PREF_SELECTED_STORE);
        textView.setText(subDisplayCategory.get(val).getId());
        callApiForProductList();

    }

    private void callApiForProductList() {
        String selectedSpecificationAttributeString = "";
        String selectedManufactures = "";
        String selectedProductAttributeString = "";
        String selectedMinimumValue = "";
        String selectedMaximumValue = "";

        isLoading = true;

        if(model != null) {
            if (model.getSelectedSpecificationAttributeString().length() > 1) {
                selectedSpecificationAttributeString = model.getSelectedSpecificationAttributeString().substring(0, model.getSelectedSpecificationAttributeString().length() - 1);
            }


            if (model.getSelectedManufactures().length() > 1) {
                selectedManufactures = model.getSelectedManufactures().substring(0, model.getSelectedManufactures().length() - 1);
            }

            if (model.getSelectedProductAttributeString().length() > 1) {
                selectedProductAttributeString = model.getSelectedProductAttributeString().substring(0, model.getSelectedProductAttributeString().length() - 1);
            }
            if(model.getSelectedMinimumValue() != null){
                selectedMinimumValue = model.getSelectedMinimumValue();
            }
            if(model.getSelectedMaximumValue() != null){
                selectedMaximumValue = model.getSelectedMaximumValue();
            }
        }

        if (subCategoryRelatedActivityExample != null) {
            val = subCategoryRelatedActivityExample.viewPager.getCurrentItem();
        }
        if (selectedSpecificationAttributeString.isEmpty()) {
            selectedSpecificationAttributeString = "0";
        }

        SubCategoryRelatedActivityExample.viewList.set(val,view);
        final String url = Config.BASE_URL + "categories/IncludeProductsFromSubcategories1?" +
                "CategoryId=" + subDisplayCategory.get(val).getId() +
                "&orderBy=0" +
                "&manufectureIds=" + selectedManufactures +
                "&page=1" +
                "&pageSize=25" +
                "&MinPrice=" + selectedMinimumValue +
                "&MaxPrice=" + selectedMaximumValue +
                "&spec=" + selectedSpecificationAttributeString +
                "&productValueid=" + selectedProductAttributeString +
                "&Cid=" + currencyId + "&customerId=" + userId;
        Log.i("TAG", "callApiForCategoriesProduct: " + url);

        JSONHelper jsonHelper = new JSONHelper(getActivity(), url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                try {
                    Log.i("", "OnResult: " + url);
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.has("ProductsFromParentcategory") && !jsonObject.isNull("ProductsFromParentcategory")) {
                            JSONArray jsonArray = jsonObject.getJSONArray("ProductsFromParentcategory");
                            list = new ArrayList<ProductModel>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject obj = jsonArray.getJSONObject(i);
                                ProductModel productModel = new ProductModel();
                                productModel.parseForRelatedProduct(obj);
                                list.add(productModel);
                            }
                        }

                    } else {
                        Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                isLoading = false;
                if (!isFilterApplied) {
                    callApiToGetFilterAttributes();
                } else {
                    initAdapter(view);
                }

            }
        }, false);
        jsonHelper.execute();
    }

    public static DynamicFragment newInstance(int val) {
        DynamicFragment fragment = new DynamicFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", val);
        fragment.setArguments(args);
        return fragment;
    }

    private void initAdapter(View view) {
        layoutLoading.setVisibility(View.GONE);

        if (list != null && list.size() > 0) {
            ll_main_layout.setVisibility(View.VISIBLE);
            layoutNoDataFound.setVisibility(View.GONE);
        } else {
            ll_main_layout.setVisibility(View.GONE);
            layoutNoDataFound.setVisibility(View.VISIBLE);
        }

        AdapterSubcat adapter = new AdapterSubcat(getActivity(), list);
        rvProduct.setAdapter(adapter);
        GridLayoutManager manager = new GridLayoutManager(getActivity(), 2, RecyclerView.VERTICAL, false);
        rvProduct.setLayoutManager(manager);
    }


    void callApiToGetFilterAttributes() {

        String url = Config.BASE_URL + "categories/categoryfilter?categoryId=" + subDisplayCategory.get(val).getId();

        JSONHelper helper = new JSONHelper(getActivity(), url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    FilterDataModel model = new FilterDataModel();

                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Maximumprice") && !jsonObject.isNull("Maximumprice")) {
                        model.setMaximumValue(jsonObject.getString("Maximumprice"));
                    }
                    if (jsonObject.has("MiniMumPrice") && !jsonObject.isNull("MiniMumPrice")) {
                        model.setMinimumValue(jsonObject.getString("MiniMumPrice"));
                    }
                    if (jsonObject.has("Categories") && !jsonObject.isNull("Categories")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("Categories");
                        ArrayList<CategoryModel> categoryModelList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            CategoryModel categoryModel = new CategoryModel();
                            categoryModel.parse(object);
                            categoryModelList.add(categoryModel);
                        }
                        model.setCategoryModelList(categoryModelList);
                    }
                    if (jsonObject.has("Manufacturers") && !jsonObject.isNull("Manufacturers")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("Manufacturers");
                        ArrayList<ManufacturerModel> manufacturerModelList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            ManufacturerModel manufacture = new ManufacturerModel();
                            manufacture.parse(object);
                            manufacturerModelList.add(manufacture);
                        }
                        model.setManufacturerModelList(manufacturerModelList);
                    }
                    if (jsonObject.has("productAttribute") && !jsonObject.isNull("productAttribute")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("productAttribute");
                        ArrayList<SpecificationForFilterModel> specificationModelList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            SpecificationForFilterModel specification = new SpecificationForFilterModel();
                            specification.parse(object);
                            specificationModelList.add(specification);
                        }
                        model.setSpecificationModelList(specificationModelList);
                    }
                    if (jsonObject.has("customProductAttribute") && !jsonObject.isNull("customProductAttribute")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("customProductAttribute");
                        ArrayList<AttributeModel> attributeModelList = new ArrayList<>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            AttributeModel attribute = new AttributeModel();
                            attribute.parse(object);
                            if (attribute.getAttributeType() == 1 || attribute.getAttributeType() == 2 || attribute.getAttributeType() == 40 || attribute.getAttributeType() == 45 || attribute.getAttributeType() == 3) {
                                attributeModelList.add(attribute);
                            }
                        }
                        model.setAttributeModelList(attributeModelList);
                    }
                    if(SubCategoryRelatedActivityExample.filterDataModelList.size() > val) {
                        SubCategoryRelatedActivityExample.filterDataModelList.set(val, model);
                    }

                }
                initAdapter(view);
            }
        }, false);
        helper.execute();
    }




    @Override
    public void onClickApplyButton(SubCategoryRelatedActivityExample subCategoryRelatedActivityExample, FilterDataModel filter) {
        try {
            view = SubCategoryRelatedActivityExample.viewList.get(subCategoryRelatedActivityExample.viewPager.getCurrentItem());
            findViewById(view);


            isFilterApplied = true;
            this.subCategoryRelatedActivityExample = subCategoryRelatedActivityExample;

            this.model = filter;

            ll_main_layout.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            callApiForProductList();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClickClear(SubCategoryRelatedActivityExample subCategoryRelatedActivityExample) {
        view = SubCategoryRelatedActivityExample.viewList.get(subCategoryRelatedActivityExample.viewPager.getCurrentItem());
        findViewById(view);
        isFilterApplied = false;
        this.model = SubCategoryRelatedActivityExample.filterDataModelList.get(subCategoryRelatedActivityExample.viewPager.getCurrentItem());

        /*selectedSpecificationAttributeString = "";
        selectedProductAttributeString = "";
        selectedCategories = "";
        selectedManufactures = "";
        selectedMinimumValue = "";
        selectedMaximumValue = "";
*/
        ll_main_layout.setVisibility(View.GONE);
        layoutLoading.setVisibility(View.VISIBLE);
        callApiForProductList();
    }
}
