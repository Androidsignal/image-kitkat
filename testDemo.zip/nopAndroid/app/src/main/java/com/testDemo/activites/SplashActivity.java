package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.global.SharedPrefsUtils;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

public class SplashActivity extends AppCompatActivity {

    Button btn_start_shopping;
    ImageView iv_up, iv_down;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        findViewById();

        String baseUrl = SharedPrefsUtils.getStringPreference(SplashActivity.this, Constants.PREF_STORE_URL);
        if (baseUrl != null && !baseUrl.isEmpty()) {
            Config.BASE_URL = baseUrl;
        }
        if (SharedPrefsUtils.getBooleanPreference(SplashActivity.this, Constants.START_SHOPPING, false)) {
            String userId = SharedPrefsUtils.getStringPreference(SplashActivity.this, Constants.PREF_USER_ID);
            SharedPrefsUtils.setBooleanPreference(SplashActivity.this, Constants.IN_APP_ONLY_ONE_TIME, true);
            if (userId != null && !userId.isEmpty()) {
                startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                finish();
            } else {
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                finish();
            }
        }else{

            new Handler().postDelayed(new Runnable(){
                @Override
                public void run() {
                    SharedPrefsUtils.setBooleanPreference(SplashActivity.this, Constants.START_SHOPPING, true);
                    SharedPrefsUtils.setBooleanPreference(SplashActivity.this, Constants.IN_APP_ONLY_ONE_TIME, true);
                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    finish();
                }
            }, 2000);

        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (btn_start_shopping != null) {
            btn_start_shopping.setEnabled(true);
        }
    }

    private void findViewById() {
        btn_start_shopping = findViewById(R.id.btn_start_shopping);
        iv_up = findViewById(R.id.iv_up);
        iv_down = findViewById(R.id.iv_down);


        Glide.with(this)
                .load(R.drawable.jewellery)
                .transition(withCrossFade())
                .centerInside().into(iv_up);

        Glide.with(this)
                .load(R.drawable.fashion)
                .centerInside().into(iv_down);

        btn_start_shopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btn_start_shopping.setEnabled(false);
                SharedPrefsUtils.setBooleanPreference(SplashActivity.this, Constants.START_SHOPPING, true);
                SharedPrefsUtils.setBooleanPreference(SplashActivity.this, Constants.IN_APP_ONLY_ONE_TIME, true);
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                finish();
            }
        });
    }
}
