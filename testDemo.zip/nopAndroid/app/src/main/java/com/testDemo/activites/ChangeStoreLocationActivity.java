package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.CustomSpinner;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.CurrencyModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ChangeStoreLocationActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Activity context = ChangeStoreLocationActivity.this;
    Toolbar toolbar;
    CustomSpinner spinner_location;
    ArrayList<CurrencyModel> storeList = new ArrayList<>();
    ArrayAdapter locationAdapter;
    Button btn_store,btnReload;
    LinearLayout layoutNoInternet, layoutError, layoutMain, layoutLoading;
    CurrencyModel currencyModel;
    String position,iteamPosition,selectedStoreId;
    String baseUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_store_location);
        findViewById();
        callApi();
        toolbarInit();
    }

    private void findViewById() {
        spinner_location=findViewById(R.id.spinner_location);
        btnReload=findViewById(R.id.btnReload);
        btn_store=findViewById(R.id.btn_forgot_password);
        layoutMain = findViewById(R.id.layoutMain);
        layoutError = findViewById(R.id.layoutError);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        layoutLoading = findViewById(R.id.layoutLoading);
        btn_store.setOnClickListener(this);
        btnReload.setOnClickListener(this);
        spinner_location.setOnItemSelectedListener(this);
    }

    private void toolbarInit() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    public void callApi(){
        if (Constants.isCheckInternetCon(ChangeStoreLocationActivity.this)) {
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
            position = SharedPrefsUtils.getStringPreference(ChangeStoreLocationActivity.this, Constants.PREF_SELECTED_STORE_POSITION);
            callApiForStore();
        } else {
            layoutNoInternet.setVisibility(View.VISIBLE);
            layoutMain.setVisibility(View.GONE);
            layoutLoading.setVisibility(View.GONE);
        }
    }

    public void callApiForStore(){
        JSONHelper jsonHelper = new JSONHelper(ChangeStoreLocationActivity.this, Config.BASE_URL + "stores", null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("stores") && !jsonObject.isNull("stores")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("stores");
                        storeList = new ArrayList<CurrencyModel>();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            currencyModel = new CurrencyModel(obj.getString("id"), obj.getString("name"),obj.getString("url"));
                            storeList.add(currencyModel);
                        }
                    }

                } else {
                    Toast.makeText(ChangeStoreLocationActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
                layoutLoading.setVisibility(View.GONE);
                layoutMain.setVisibility(View.VISIBLE);
                populateSpinner();
            }
        }, false);
        jsonHelper.execute();
    }

    private void populateSpinner() {
        ArrayList<String> lables = new ArrayList<String>();

        for (int i = 0; i < storeList.size(); i++) {
            lables.add(storeList.get(i).getName());
        }

        locationAdapter = new ArrayAdapter<String>(ChangeStoreLocationActivity.this, R.layout.spinner_item_selected_for_shipping, lables);
        locationAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner_location.setAdapter(locationAdapter);
        spinner_location.setSelection(getIndex(spinner_location, position));
    }

    private int getIndex(CustomSpinner spinner, String myString) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)) {
                return i;
            }
        }

        return 0;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_forgot_password:
                SharedPrefsUtils.setStringPreference(context, Constants.PREF_SELECTED_STORE_POSITION, iteamPosition);
                SharedPrefsUtils.setStringPreference(context, Constants.PREF_SELECTED_STORE, selectedStoreId);
                if(baseUrl != null && !baseUrl.isEmpty()) {
                    SharedPrefsUtils.setStringPreference(context, Constants.PREF_STORE_URL, baseUrl+"api/");
                }
                startActivity(new Intent(context, HomeActivity.class));
                finish();
                break;
            case R.id.btnReload:
                callApi();
                break;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        iteamPosition = parent.getItemAtPosition(position).toString();
        selectedStoreId = storeList.get(position).getId();
        baseUrl = storeList.get(position).getBaseUrl();
        Config.BASE_URL = baseUrl+"api/";
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
