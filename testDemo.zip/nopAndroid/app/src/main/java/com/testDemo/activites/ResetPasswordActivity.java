package com.testDemo.activites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.testDemo.R;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.scottyab.showhidepasswordedittext.ShowHidePasswordEditText;

import org.json.JSONException;
import org.json.JSONObject;

public class ResetPasswordActivity extends AppCompatActivity implements View.OnClickListener {

    Activity context = ResetPasswordActivity.this;
    Toolbar toolbar;
    Button btn_reset_now;
    ShowHidePasswordEditText et_re_enter_password, et_password;
    String userId;
    LinearLayout layoutMain,layoutNoInternet,layoutError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
        findViewById();
        toolbarInit();
        if (!Constants.isCheckInternetCon(context)) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            layoutMain.setVisibility(View.VISIBLE);
            layoutNoInternet.setVisibility(View.GONE);
        }
        userId = SharedPrefsUtils.getStringPreference(ResetPasswordActivity.this, Constants.PREF_USER_ID);
    }

    private void findViewById() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        et_re_enter_password = findViewById(R.id.et_re_enter_password);
        et_password = findViewById(R.id.et_password);
        btn_reset_now = (Button) findViewById(R.id.btn_reset_now);
        layoutMain =  findViewById(R.id.layoutMain);
        layoutNoInternet =  findViewById(R.id.layoutNoInternet);
        layoutError =  findViewById(R.id.layoutError);
        btn_reset_now.setOnClickListener(this);
    }

    private void toolbarInit() {
        toolbar.setBackground(null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setBackgroundColor(getResources().getColor(R.color.white));
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_reset_now:
                if (resetButton()) {
                    callAPiForResetPassword();
                }
                break;
        }
    }

    boolean resetButton() {
        if (et_password.getText().toString().length() > 0) {
            if (et_re_enter_password.getText().toString().length() > 0) {
                if (et_password.getText().toString().equals(et_re_enter_password.getText().toString())) {
                    return true;
                } else {
                    et_re_enter_password.setError(getResources().getString(R.string.not_match_re_enter_password));
                }
            } else {
                et_re_enter_password.setError(getResources().getString(R.string.empty_re_enter_password));
            }
        } else {
            et_password.setError(getResources().getString(R.string.empty_password));
        }
        return false;
    }

    public void callAPiForResetPassword() {
        JSONHelper jsonHelper = new JSONHelper(ResetPasswordActivity.this, Config.BASE_URL + "customers/changepassword?NewPassword=" + et_password.getText().toString() + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success") && jsonObject.getString("Success").equals("0")) {

                        startActivity(new Intent(ResetPasswordActivity.this, ResetPasswordDoneActivity.class));
                        finish();

                    } else {
                        String msg = jsonObject.getString("Message");
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                        /*layoutMain.setVisibility(View.GONE);
                        layoutError.setVisibility(View.VISIBLE);*/
                    }
                } else {
                    Toast.makeText(context, "Update Failed", Toast.LENGTH_SHORT).show();
                    /*layoutMain.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);*/
                }
            }
        }, true);
        jsonHelper.execute();
    }
}


