package com.testDemo.model;

import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class OrderModel {

    String orderId;
    String orderStatus;
    String orderDate;
    String orderTotal;
    String orderShippingTotal;
    String orderTex;
    String orderSubTotal;
    String paymentStatus;
    String shippingStatus;
    String paymentMethod;
    String shippingMethod;
    String currency;
    SimpleDateFormat form = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
    java.util.Date date = null;

    public ArrayList<ProductModel> productModelList;


    String billingName;
    String billingEmail;
    String billingPhoneNumber;
    String billingFax;
    String billingAddress1;
    String billingCity;
    String billingZipCode;
    String billingCountry;

    String shippingName;
    String shippingEmail;
    String shippingPhoneNumber;
    String shippingFax;
    String shippingAddress1;
    String shippingCity;
    String shippingZipCode;
    String shippingCountry;
    String pdfInvoiceLink;

    JSONObject jsonObjectForBilling;
    JSONObject jsonObjectForShipping;


    public String getPdfInvoiceLink() {
        return pdfInvoiceLink;
    }

    public void setPdfInvoiceLink(String pdfInvoiceLink) {
        this.pdfInvoiceLink = pdfInvoiceLink;
    }

    public String getShippingName() {
        return shippingName;
    }

    public void setShippingName(String shippingName) {
        this.shippingName = shippingName;
    }

    public String getShippingEmail() {
        return shippingEmail;
    }

    public void setShippingEmail(String shippingEmail) {
        this.shippingEmail = shippingEmail;
    }

    public String getShippingPhoneNumber() {
        return shippingPhoneNumber;
    }

    public void setShippingPhoneNumber(String shippingPhoneNumber) {
        this.shippingPhoneNumber = shippingPhoneNumber;
    }

    public String getShippingFax() {
        return shippingFax;
    }

    public void setShippingFax(String shippingFax) {
        this.shippingFax = shippingFax;
    }

    public String getShippingAddress1() {
        return shippingAddress1;
    }

    public void setShippingAddress1(String shippingAddress1) {
        this.shippingAddress1 = shippingAddress1;
    }

    public String getShippingCity() {
        return shippingCity;
    }

    public void setShippingCity(String shippingCity) {
        this.shippingCity = shippingCity;
    }

    public String getShippingZipCode() {
        return shippingZipCode;
    }

    public void setShippingZipCode(String shippingZipCode) {
        this.shippingZipCode = shippingZipCode;
    }

    public String getShippingCountry() {
        return shippingCountry;
    }

    public void setShippingCountry(String shippingCountry) {
        this.shippingCountry = shippingCountry;
    }

    public String getBillingPhoneNumber() {
        return billingPhoneNumber;
    }

    public void setBillingPhoneNumber(String billingPhoneNumber) {
        this.billingPhoneNumber = billingPhoneNumber;
    }

    public String getBillingName() {
        return billingName;
    }

    public void setBillingName(String billingName) {
        this.billingName = billingName;
    }

    public String getBillingEmail() {
        return billingEmail;
    }

    public void setBillingEmail(String billingEmail) {
        this.billingEmail = billingEmail;
    }

    public String getBillingFax() {
        return billingFax;
    }

    public void setBillingFax(String billingFax) {
        this.billingFax = billingFax;
    }

    public String getBillingAddress1() {
        return billingAddress1;
    }

    public void setBillingAddress1(String billingAddress1) {
        this.billingAddress1 = billingAddress1;
    }

    public String getBillingCity() {
        return billingCity;
    }

    public void setBillingCity(String billingCity) {
        this.billingCity = billingCity;
    }

    public String getBillingZipCode() {
        return billingZipCode;
    }

    public void setBillingZipCode(String billingZipCode) {
        this.billingZipCode = billingZipCode;
    }

    public String getBillingCountry() {
        return billingCountry;
    }

    public void setBillingCountry(String billingCountry) {
        this.billingCountry = billingCountry;
    }

    @Override
    public String toString() {
        return "OrderModel{" +
                "orderId='" + orderId + '\'' +
                ", orderStatus='" + orderStatus + '\'' +
                ", orderDate='" + orderDate + '\'' +
                ", orderTotal='" + orderTotal + '\'' +
                '}';
    }


    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderShippingTotal() {
        return orderShippingTotal;
    }

    public void setOrderShippingTotal(String orderShippingTotal) {
        this.orderShippingTotal = orderShippingTotal;
    }

    public String getOrderTex() {
        return orderTex;
    }

    public void setOrderTex(String orderTex) {
        this.orderTex = orderTex;
    }

    public String getOrderSubTotal() {
        return orderSubTotal;
    }

    public void setOrderSubTotal(String orderSubTotal) {
        this.orderSubTotal = orderSubTotal;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getShippingStatus() {
        return shippingStatus;
    }

    public void setShippingStatus(String shippingStatus) {
        this.shippingStatus = shippingStatus;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getShippingMethod() {
        return shippingMethod;
    }

    public void setShippingMethod(String shippingMethod) {
        this.shippingMethod = shippingMethod;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public SimpleDateFormat getForm() {
        return form;
    }

    public void setForm(SimpleDateFormat form) {
        this.form = form;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(String orderTotal) {
        this.orderTotal = orderTotal;
    }


    public void parseForOrderList(JSONObject jsonObject) throws JSONException {

        if (jsonObject.has("id") && !jsonObject.isNull("id")) {
            orderId = jsonObject.getString("id");
        }
        if (jsonObject.has("created_on_utc") && !jsonObject.isNull("created_on_utc")) {
            try {
                date = form.parse(jsonObject.getString("created_on_utc"));
            } catch (ParseException e) {

                e.printStackTrace();
            }
            SimpleDateFormat postFormater = new SimpleDateFormat("MMMM dd, yyyy");
            orderDate = postFormater.format(date);
        }
        if (jsonObject.has("order_status") && !jsonObject.isNull("order_status")) {
            orderStatus = jsonObject.getString("order_status");
        }
        if (jsonObject.has("ordertotal") && !jsonObject.isNull("ordertotal")) {
            orderTotal = jsonObject.getString("ordertotal");
        }

    }

    public void parseForOrderInfo(JSONObject jsonObject) throws JSONException {

        if (jsonObject.has("id") && !jsonObject.isNull("id")) {
            orderId = jsonObject.getString("id");
        }
        if (jsonObject.has("pdfinvoicelink") && !jsonObject.isNull("pdfinvoicelink")) {
            pdfInvoiceLink = jsonObject.getString("pdfinvoicelink");
        }
        if (jsonObject.has("created_on_utc") && !jsonObject.isNull("created_on_utc")) {
            try {
                date = form.parse(jsonObject.getString("created_on_utc"));
            } catch (ParseException e) {

                e.printStackTrace();
            }
            SimpleDateFormat postFormater = new SimpleDateFormat("MMMM dd, yyyy");
            orderDate = postFormater.format(date);
        }
        if (jsonObject.has("order_status") && !jsonObject.isNull("order_status")) {
            orderStatus = jsonObject.getString("order_status");
        }
        if (jsonObject.has("ordertotal") && !jsonObject.isNull("ordertotal")) {
            orderTotal = jsonObject.getString("ordertotal");
        }

        if (jsonObject.has("payment_status") && !jsonObject.isNull("payment_status")) {
            paymentStatus = jsonObject.getString("payment_status");
        }

        if (jsonObject.has("payment_method_system_name") && !jsonObject.isNull("payment_method_system_name")) {
            paymentMethod = jsonObject.getString("payment_method_system_name");
        }

        if (jsonObject.has("shipping_status") && !jsonObject.isNull("shipping_status")) {
            shippingStatus = jsonObject.getString("shipping_status");
        }

        if (jsonObject.has("shipping_method") && !jsonObject.isNull("shipping_method")) {
            shippingMethod = jsonObject.getString("shipping_method");
        }

        if (jsonObject.has("order_shipping_incl_tax") && !jsonObject.isNull("order_shipping_incl_tax")) {
            orderShippingTotal = jsonObject.getString("order_shipping_incl_tax");
        }

        if (jsonObject.has("order_tax") && !jsonObject.isNull("order_tax")) {
            orderTex = jsonObject.getString("order_tax");
        }

        if (jsonObject.has("order_subtotal_incl_tax") && !jsonObject.isNull("order_subtotal_incl_tax")) {
            orderSubTotal = jsonObject.getString("order_subtotal_incl_tax");
        }

        if (jsonObject.has("CurrencyType") && !jsonObject.isNull("CurrencyType")) {
            currency = jsonObject.getString("CurrencyType");
        }

        if (jsonObject.has("billing_address") && !jsonObject.isNull("billing_address")) {
            jsonObjectForBilling = jsonObject.getJSONObject("billing_address");

            if (jsonObjectForBilling.has("first_name") && !jsonObjectForBilling.isNull("first_name")) {
                billingName = jsonObjectForBilling.getString("first_name") + " " + jsonObjectForBilling.getString("last_name");
            }

            if (jsonObjectForBilling.has("email") && !jsonObjectForBilling.isNull("email")) {
                billingEmail = jsonObjectForBilling.getString("email");
            }

            if (jsonObjectForBilling.has("phone_number") && !jsonObjectForBilling.isNull("phone_number")) {
                billingPhoneNumber = jsonObjectForBilling.getString("phone_number");
            }

            if (jsonObjectForBilling.has("fax_number") && !jsonObjectForBilling.isNull("fax_number")) {
                billingFax = jsonObjectForBilling.getString("fax_number");
            }

            if (jsonObjectForBilling.has("address1") && !jsonObjectForBilling.isNull("address1")) {
                billingAddress1 = jsonObjectForBilling.getString("address1");
            }

            if (jsonObjectForBilling.has("city") && !jsonObjectForBilling.isNull("city")) {
                billingCity = jsonObjectForBilling.getString("city");
            }

            if (jsonObjectForBilling.has("zip_postal_code") && !jsonObjectForBilling.isNull("zip_postal_code")) {
                billingZipCode = jsonObjectForBilling.getString("zip_postal_code");
            }

            if (jsonObjectForBilling.has("country") && !jsonObjectForBilling.isNull("country")) {
                billingCountry = jsonObjectForBilling.getString("country");
            }

        }

        if (jsonObject.has("shipping_address") && !jsonObject.isNull("shipping_address")) {
            jsonObjectForShipping = jsonObject.getJSONObject("shipping_address");

            if (jsonObjectForShipping.has("first_name") && !jsonObjectForShipping.isNull("first_name")) {
                shippingName = jsonObjectForShipping.getString("first_name") + " " + jsonObjectForShipping.getString("last_name");
            }

            if (jsonObjectForShipping.has("email") && !jsonObjectForShipping.isNull("email")) {
                shippingEmail = jsonObjectForShipping.getString("email");
            }

            if (jsonObjectForShipping.has("phone_number") && !jsonObjectForShipping.isNull("phone_number")) {
                shippingPhoneNumber = jsonObjectForShipping.getString("phone_number");
            }

            if (jsonObjectForShipping.has("fax_number") && !jsonObjectForShipping.isNull("fax_number")) {
                shippingFax = jsonObjectForShipping.getString("fax_number");
            }

            if (jsonObjectForShipping.has("address1") && !jsonObjectForShipping.isNull("address1")) {
                shippingAddress1 = jsonObjectForShipping.getString("address1");
            }

            if (jsonObjectForShipping.has("city") && !jsonObjectForShipping.isNull("city")) {
                shippingCity = jsonObjectForShipping.getString("city");
            }

            if (jsonObjectForShipping.has("zip_postal_code") && !jsonObjectForShipping.isNull("zip_postal_code")) {
                shippingZipCode = jsonObjectForShipping.getString("zip_postal_code");
            }

            if (jsonObjectForShipping.has("country") && !jsonObjectForShipping.isNull("country")) {
                shippingCountry = jsonObjectForShipping.getString("country");
            }

        }


        JSONArray jsonArray = jsonObject.getJSONArray("order_items");
        productModelList = new ArrayList<ProductModel>();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            ProductModel orderModel = new ProductModel();
            orderModel.parseForCartItem(obj);
            productModelList.add(orderModel);
        }


    }

}
