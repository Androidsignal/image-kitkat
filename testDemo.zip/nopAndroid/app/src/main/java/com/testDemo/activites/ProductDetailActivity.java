package com.testDemo.activites;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.material.appbar.AppBarLayout;
import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;
import com.testDemo.R;
import com.testDemo.adapter.AssociatedProductListAdapter;
import com.testDemo.adapter.AttributeListAdapter;
import com.testDemo.adapter.ProductDetailAdapter;
import com.testDemo.adapter.ProductSpecificationAdapter;
import com.testDemo.adapter.SliderAdapterExample;
import com.testDemo.config.Config;
import com.testDemo.global.Constants;
import com.testDemo.global.SharedPrefsUtils;
import com.testDemo.helper.JSONHelper;
import com.testDemo.helper.OnAsyncLoader;
import com.testDemo.model.AttributeModel;
import com.testDemo.model.ImageListModel;
import com.testDemo.model.ProductDetailModel;
import com.testDemo.model.ProductModel;
import com.testDemo.model.UserModel;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;

import static com.smarteist.autoimageslider.IndicatorView.utils.DensityUtils.pxToDp;

public class ProductDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int FILE_SELECT_CODE = 111;
    Activity context = ProductDetailActivity.this;
    String TAG = getClass().getSimpleName();

    CoordinatorLayout layoutMain;
    AppBarLayout app_bar;
    LinearLayout layoutLoading;
    LinearLayout layoutNoInternet;
    LinearLayout layoutError;
    LinearLayout specificationLayout;
    LinearLayout giftCardLayout;
    LinearLayout ll_customer_who_also_buy, ll_related_product;
    LinearLayout addReview;
    ProductModel productModel;
    ArrayList<ProductModel> customerWhoAlsoBuy;
    ArrayList<ProductModel> relatedProductList;


    Button btnRetry;
    Button btnAddReview;
    Toolbar toolbar;

    SliderView sliderView;

    RecyclerView recyclerView, rcv_customer_who_also_buy, rcv_related_product;
    RecyclerView recyclerViewForProductSpecification;
    RecyclerView recyclerViewAssociatedProducts;

    AttributeListAdapter attributeListAdapter;
    ProductSpecificationAdapter productSpecificationAdapter;
    AssociatedProductListAdapter associatedProductListAdapter;
    ProductDetailAdapter productListAdapter;
    String productId = "";
    CardView btnAddToCart;

    ProductDetailModel productDetailModel;

    TextView txtTitle;
    TextView txtOldPrice;
    TextView txtNewPrice;
    TextView txtShortDescription;
    FloatingActionButton fab;
    String userId, storeId;


    TextView txtRaring;
    TextView txtReview;

    int selectedIndexForFileChooser = -1;

    ArrayList<Integer> hideAttributeIds = new ArrayList<>();
    private ArrayList<ImageListModel> imageList = new ArrayList<>();


    TextInputLayout txtInputLayoutRecipientName;
    TextInputLayout txtInputLayoutRecipientEmail;
    TextInputLayout txtInputLayoutYourName;
    TextInputLayout txtInputLayoutYourEmail;
    TextInputLayout txtInputLayoutMessage;

    EditText editRecipientName;
    EditText editRecipientEmail;
    EditText editYourName;
    EditText editYourEmail;
    EditText editMessage;

    boolean isLoadingForAssociatedProduct = false;
    boolean isLoading = false;
    String currencyId;
    String customerId;

    NestedScrollView ns_layout_main;
   // UserModel userModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_product_detail);
        findViewById();
        getIntentData();

       /* btnAddReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(ProductDetailActivity.this,AddReview.class);
                    i.putExtra("image", imageList.get(0).getUrl());
                    i.putExtra("prodname", productDetailModel.getName());
                  //  i.putExtra("username", userModel.getName());


                startActivity(i);

            }
        });*/

        if (!Constants.isCheckInternetCon(context)) {
            layoutMain.setVisibility(View.GONE);
            layoutNoInternet.setVisibility(View.VISIBLE);
        } else {
            callApi();
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnAddToCart) {
            boolean isError = conditionForAttribute();
            if (!isError) {
                makeRequestStringForConditionalAttribute(productDetailModel.getAttributeModelArrayList());
                callApiForAddToCart();
            } else {
                attributeListAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (requestCode == FILE_SELECT_CODE) {
                if (resultCode == RESULT_OK) {
                    // Get the Uri of the selected file
                    Uri uri = data.getData();
                    if (uri != null) {
                        File file = new File(getPath(context, uri));
                        if (selectedIndexForFileChooser != -1) {
                            productDetailModel.getAttributeModelArrayList().get(selectedIndexForFileChooser).setError(null);
                            productDetailModel.getAttributeModelArrayList().get(selectedIndexForFileChooser).setCurrentFile(file);
                            productDetailModel.getAttributeModelArrayList().get(selectedIndexForFileChooser).setCurrentValue(file.getName());
                            attributeListAdapter.notifyDataSetChanged();
                        }
                    }
                }
            }
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    void getIntentData() {
        try {
            currencyId = SharedPrefsUtils.getStringPreference(ProductDetailActivity.this, Constants.PREF_SELECTED_CURRENCY);
            customerId = SharedPrefsUtils.getStringPreference(ProductDetailActivity.this, Constants.PREF_USER_ID);
            storeId = SharedPrefsUtils.getStringPreference(ProductDetailActivity.this, Constants.PREF_SELECTED_STORE);
            if (getIntent() != null && getIntent().getStringExtra(Constants.INTENT_PRODUCT_ID) != null) {
                productId = getIntent().getStringExtra(Constants.INTENT_PRODUCT_ID);
            } else if (getIntent() != null && getIntent().getIntArrayExtra(Constants.INTENT_PRODUCT_ID) != null) {
                productId = String.valueOf(getIntent().getIntExtra(Constants.INTENT_PRODUCT_ID, 0));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void findViewById() {


        btnAddReview=findViewById(R.id.btn_addReview);
        addReview=findViewById(R.id.btn_addReviews);
        layoutMain = findViewById(R.id.layoutMain);
        ns_layout_main = findViewById(R.id.ns_layout_main);
        app_bar = findViewById(R.id.app_bar);
        btnAddToCart = findViewById(R.id.btnAddToCart);
        btnAddToCart.setOnClickListener(this);
        layoutLoading = findViewById(R.id.layoutLoading);
        layoutNoInternet = findViewById(R.id.layoutNoInternet);
        ll_related_product = findViewById(R.id.ll_related_product);
        layoutError = findViewById(R.id.layoutError);
        specificationLayout = findViewById(R.id.specificationLayout);
        giftCardLayout = findViewById(R.id.giftCardLayout);
        btnRetry = findViewById(R.id.btnReload);
        txtOldPrice = findViewById(R.id.txtOldPrice);
        ll_customer_who_also_buy = findViewById(R.id.ll_customer_who_also_buy);

        txtInputLayoutRecipientName = findViewById(R.id.txtInputLayoutRecipientName);
        txtInputLayoutRecipientEmail = findViewById(R.id.txtInputLayoutRecipientEmail);
        txtInputLayoutYourName = findViewById(R.id.txtInputLayoutYourName);
        txtInputLayoutYourEmail = findViewById(R.id.txtInputLayoutYourEmail);
        txtInputLayoutMessage = findViewById(R.id.txtInputLayoutMessage);

        editRecipientName = findViewById(R.id.editRecipientName);
        editRecipientEmail = findViewById(R.id.editRecipientEmail);
        editYourName = findViewById(R.id.editYourName);
        editYourEmail = findViewById(R.id.editYourEmail);
        editMessage = findViewById(R.id.editMessage);

        toolbar = findViewById(R.id.toolbar);
        sliderView = findViewById(R.id.imageSlider);

        recyclerView = findViewById(R.id.recyclerView);

        recyclerViewForProductSpecification = findViewById(R.id.recyclerViewForProductSpecification);
        recyclerViewAssociatedProducts = findViewById(R.id.recyclerViewAssociatedProducts);
        rcv_customer_who_also_buy = findViewById(R.id.rcv_customer_who_also_buy);
        rcv_related_product = findViewById(R.id.rcv_related_product);

        txtTitle = findViewById(R.id.txtTitle);
        txtOldPrice = findViewById(R.id.txtOldPrice);
        txtNewPrice = findViewById(R.id.txtNewPrice);
        txtShortDescription = findViewById(R.id.txtShortDescription);
        userId = SharedPrefsUtils.getStringPreference(ProductDetailActivity.this, Constants.PREF_USER_ID);


        txtRaring = findViewById(R.id.txt_rating);
        txtReview = findViewById(R.id.txt_reviews);

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnAddToCart.performClick();
            }
        });

        toolbar.setTitle("");
        toolbar.setNavigationIcon(R.drawable.ic_back);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Constants.isCheckInternetCon(context)) {
                    layoutLoading.setVisibility(View.VISIBLE);
                    layoutMain.setVisibility(View.GONE);
                    layoutNoInternet.setVisibility(View.GONE);
                    callApi();
                }
            }
        });
    }

    private void showOfferDialog(String url) {
        final Dialog dialog = new Dialog(ProductDetailActivity.this);
        dialog.setContentView(R.layout.check_out_dialog);
        Button btn_dialog_checkout = dialog.findViewById(R.id.btn_dialog_checkout);
        Button btn_dialog_continue_shopping = dialog.findViewById(R.id.btn_dialog_continue_shopping);
        ImageView img_offer = dialog.findViewById(R.id.img_offer);
        Glide.with(this).load(url).into(img_offer);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();



        btn_dialog_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
                dialog.dismiss();
                startActivity(new Intent(ProductDetailActivity.this, CartScreen.class));
//                addToCart(true);

            }
        });
        btn_dialog_continue_shopping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
                dialog.dismiss();
                finish();
//                addToCart(false);
            }
        });
    }

    void callApi() {
        layoutMain.setVisibility(View.GONE);
        layoutLoading.setVisibility(View.VISIBLE);
        getProductDetail();

    }

    void getProductDetail() {
        isLoading = true;

        JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "products/" + productId + "?Cid=" + currencyId, null, new OnAsyncLoader() {
            @SuppressLint("RestrictedApi")
            @Override
            public void OnResult(String result) {
                try {
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.has("products") && !jsonObject.isNull("products")) {
                            JSONArray products = jsonObject.getJSONArray("products");
                            if (products.length() > 0) {
                                JSONObject object = products.getJSONObject(0);
                                productDetailModel = new ProductDetailModel();
                                productDetailModel.parse(object);

                            }
                        }

                    }
                    if (productDetailModel != null && productDetailModel.getProductType() != null && productDetailModel.getProductType().equals("GroupedProduct")) {
                        txtOldPrice.setVisibility(View.GONE);
                        txtNewPrice.setVisibility(View.GONE);
                        fab.setVisibility(View.GONE);
                        btnAddToCart.setVisibility(View.GONE);
                        if (productDetailModel.getAssociatedProductIdList().size() > 0) {
                            callApiForGetAssociatedProducts();
                        }
                    }
                    callApiForCustomerWhoAlsoBuy();
                } catch (JSONException e) {
                    e.printStackTrace();
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }

            }
        }, false);
        helper.execute();
    }

    void callApiForCustomerWhoAlsoBuy() {
        JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "products/productsalsopurchasedlist?productId=" + productId + "&Cid=" + currencyId + "&storeid=" + storeId + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) {
                try {
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.has("ProductAlsoPurchasedList") && !jsonObject.isNull("ProductAlsoPurchasedList")) {
                            JSONArray products = jsonObject.getJSONArray("ProductAlsoPurchasedList");
                            customerWhoAlsoBuy = new ArrayList<>();
                            for (int i = 0; i < products.length(); i++) {
                                JSONObject obj = products.getJSONObject(i);
                                productModel = new ProductModel();
                                productModel.parseForWhoAlsoBuy(obj);
                                customerWhoAlsoBuy.add(productModel);
                            }

                            setCustomerWhoAlsoBuyData();

                        }
                    }
                    callApiForRelatedProduct();
                } catch (JSONException e) {
                    e.printStackTrace();
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }


            }
        }, false);
        helper.execute();
    }

    void callApiForRelatedProduct() {
        JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "products/relatedproductslist?productId=" + productId + "&Cid=" + currencyId + "&storeid=" + storeId + "&customerId=" + userId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) {
                try {
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.has("RelatedProductList") && !jsonObject.isNull("RelatedProductList")) {
                            JSONArray products = jsonObject.getJSONArray("RelatedProductList");
                            relatedProductList = new ArrayList<>();
                            for (int i = 0; i < products.length(); i++) {
                                JSONObject obj = products.getJSONObject(i);
                                productModel = new ProductModel();
                                productModel.parseForRelatedProduct(obj);
                                relatedProductList.add(productModel);
                            }
                            setRelatedData();

                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }
                callApiForHideAttributeIds(false);

            }
        }, false);
        helper.execute();
    }

    void addToCart(int productId) {
        layoutLoading.setVisibility(View.VISIBLE);
        layoutMain.setVisibility(View.GONE);

        JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "shopping_cart_items/addproducttoshoppingcart?customerId=" + userId + "&productId=" + productId + "&shoppingCartTypeId=1&quantity=1" + "&storeid=" + storeId, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) {
                try {
                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        boolean isBuyDone = jsonObject.getBoolean("Success");
                        if (isBuyDone) {
//                            Toast.makeText(context, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                            showOfferDialog(productDetailModel.getImageList().get(0).getUrl());
                        } else {
                            Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    layoutLoading.setVisibility(View.GONE);
                    layoutError.setVisibility(View.VISIBLE);
                }
            }
        }, false);
        helper.execute();

        layoutLoading.setVisibility(View.GONE);
        layoutMain.setVisibility(View.VISIBLE);
    }

    void setDataForSlider() {

        Glide.with(ProductDetailActivity.this)
                .asBitmap()
                .load(productDetailModel.getImageList().get(0))
                .into(new CustomTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        Log.w("TAGIMAGE", "Width -- >" + pxToDp(resource.getWidth()) + " Hight -- >" + pxToDp(resource.getHeight()));
                        sliderView.getLayoutParams().height = resource.getHeight();
                        sliderView.requestLayout();
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
        SliderAdapterExample adapter = new SliderAdapterExample(ProductDetailActivity.this, null, productDetailModel.getImageList());
        sliderView.setSliderAdapter(adapter);
        sliderView.setIndicatorAnimation(IndicatorAnimations.WORM);
        sliderView.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderView.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        sliderView.setScrollTimeInSec(4); //set scroll delay in seconds :
        sliderView.startAutoCycle();

        imageList=productDetailModel.getImageList();



        if (productDetailModel != null && productDetailModel.getName() != null) {
            txtTitle.setVisibility(View.VISIBLE);
            txtTitle.setText(productDetailModel.getName());
        }
        if (productDetailModel != null && productDetailModel.getOldPrice() != null && !productDetailModel.getProductType().equals("GroupedProduct")) {
            txtOldPrice.setVisibility(View.VISIBLE);
            txtOldPrice.setText(productDetailModel.getOldPrice());
        }
        if (productDetailModel != null && productDetailModel.getPrice() != null && !productDetailModel.getProductType().equals("GroupedProduct")) {
            txtNewPrice.setVisibility(View.VISIBLE);
            txtNewPrice.setText(productDetailModel.getPrice());
        }
        if (productDetailModel != null && productDetailModel.getShortDescription() != null) {
            txtShortDescription.setVisibility(View.VISIBLE);
            txtShortDescription.setText(productDetailModel.getShortDescription());
        }
        if (productDetailModel != null && String.valueOf(productDetailModel.getRating()) != null) {

            txtRaring.setText(String.valueOf(productDetailModel.getRating()));
        }
        if (productDetailModel != null && String.valueOf(productDetailModel.getReviews()) != null) {

            txtReview.setText(String.valueOf(productDetailModel.getReviews()));
        }


        setDataForAttribute();
        setDataForSpecificationAttribute();

        if (productDetailModel.isGiftCard()) {
            giftCardLayout.setVisibility(View.VISIBLE);
            if (!productDetailModel.getGiftCardType().equals("Virtual")) {
                txtInputLayoutRecipientEmail.setVisibility(View.GONE);
                txtInputLayoutYourEmail.setVisibility(View.GONE);
            }
        }

        isLoading = false;
        if (!isLoadingForAssociatedProduct) {
            setDataForAssociatedProductList();
            layoutLoading.setVisibility(View.GONE);
            layoutMain.setVisibility(View.VISIBLE);
        }
    }

    void setDataForAttribute() {
        if (productDetailModel.getAttributeModelArrayList().size() > 0) {
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
            recyclerView.setLayoutManager(linearLayoutManager);
            attributeListAdapter = new AttributeListAdapter(context, productDetailModel.getAttributeModelArrayList(), ProductDetailActivity.this, hideAttributeIds, ns_layout_main);
            recyclerView.setAdapter(attributeListAdapter);
        } else {
            recyclerView.setVisibility(View.GONE);
        }
    }

    void setDataForSpecificationAttribute() {
        if (productDetailModel.getSpecificationModelArrayList().size() > 0) {
            specificationLayout.setVisibility(View.VISIBLE);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
            recyclerViewForProductSpecification.setLayoutManager(linearLayoutManager);
            productSpecificationAdapter = new ProductSpecificationAdapter(context, productDetailModel.getSpecificationModelArrayList());
            recyclerViewForProductSpecification.setAdapter(productSpecificationAdapter);
        } else {
            specificationLayout.setVisibility(View.GONE);
        }
    }

    void setDataForAssociatedProductList() {
        if (productDetailModel.getAssociatedProductList().size() > 0) {
            recyclerViewAssociatedProducts.setVisibility(View.VISIBLE);
            GridLayoutManager gridLayout = new GridLayoutManager(context, 2, RecyclerView.VERTICAL, false);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
            recyclerViewAssociatedProducts.setLayoutManager(gridLayout);
            associatedProductListAdapter = new AssociatedProductListAdapter(context, productDetailModel.getAssociatedProductList(), this);
            recyclerViewAssociatedProducts.setAdapter(associatedProductListAdapter);
        } else {
            specificationLayout.setVisibility(View.GONE);
        }
    }

    private void setCustomerWhoAlsoBuyData() {

        if (customerWhoAlsoBuy.size() > 0) {
            ll_customer_who_also_buy.setVisibility(View.VISIBLE);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
            rcv_customer_who_also_buy.setLayoutManager(linearLayoutManager);
            productListAdapter = new ProductDetailAdapter(context, customerWhoAlsoBuy);
            rcv_customer_who_also_buy.setAdapter(productListAdapter);
        } else {
            ll_customer_who_also_buy.setVisibility(View.GONE);
        }
    }

    private void setRelatedData() {

        if (relatedProductList.size() > 0) {
            layoutLoading.setVisibility(View.GONE);
            ll_related_product.setVisibility(View.VISIBLE);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
            linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
            rcv_related_product.setLayoutManager(linearLayoutManager);
            productListAdapter = new ProductDetailAdapter(context, relatedProductList);
            rcv_related_product.setAdapter(productListAdapter);
        } else {
            layoutLoading.setVisibility(View.GONE);
            ll_related_product.setVisibility(View.GONE);
        }
    }

    public void chooseFile(int index) {
        selectedIndexForFileChooser = index;
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(Intent.createChooser(intent, "Choose File"), FILE_SELECT_CODE);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "Please install a File Manager.", Toast.LENGTH_SHORT).show();
        }
    }

    public String getPath(Context context, Uri uri) throws URISyntaxException {
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            String[] projection = {"_data"};
            Cursor cursor = null;

            try {
                cursor = context.getContentResolver().query(uri, projection, null, null, null);
                int column_index = cursor.getColumnIndexOrThrow("_data");
                if (cursor.moveToFirst()) {
                    return cursor.getString(column_index);
                }
            } catch (Exception e) {
                // Eat it
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    boolean conditionForAttribute() {
        ArrayList<Boolean> errorList = new ArrayList<>();
        for (int i = 0; i < productDetailModel.getAttributeModelArrayList().size(); i++) {
            AttributeModel model = productDetailModel.getAttributeModelArrayList().get(i);
            if (model.getAttributeType() == 1 || model.getAttributeType() == 2 || model.getAttributeType() == 40 || model.getAttributeType() == 45) {
                boolean isError = conditionForSingleValue(model);
                if (isError) {
                    errorList.add(true);
                }
            } else if (model.getAttributeType() == 3) {
                boolean isError = conditionForMultiValue(model);
                if (isError) {
                    errorList.add(true);
                }
            } else if (model.getAttributeType() == 4 || model.getAttributeType() == 10 || model.getAttributeType() == 20 || model.getAttributeType() == 30) {
                boolean isError = conditionForStringValue(model);
                if (isError) {
                    errorList.add(true);
                }
            }
        }
        return errorList.size() > 0;
    }

    boolean conditionForSingleValue(AttributeModel model) {
        if (hideAttributeIds.contains(model.getMapId())) {
            return false;
        }
        if (model.isRequired()) {
            if (model.getCurrentValueModel() == null) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel());

                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    boolean conditionForMultiValue(AttributeModel model) {
        if (hideAttributeIds.contains(model.getMapId())) {
            return false;
        }
        if (model.isRequired()) {
            if (model.getSelectedValueModelList() == null || model.getSelectedValueModelList().size() == 0) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel());
                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    boolean conditionForStringValue(AttributeModel model) {
        if (hideAttributeIds.contains(model.getMapId())) {
            return false;
        }
        if (model.isRequired()) {
            if (model.getCurrentValue() == null || model.getCurrentValue().isEmpty()) {
                if (model.getAttributeLabel() != null) {
                    model.setError(model.getAttributeLabel());
                } else {
                    model.setError("Select " + model.getAttributeName());
                }
                return true;
            }
        }
        return false;
    }

    String makeRequestStringForConditionalAttribute(ArrayList<AttributeModel> attributeModelArrayList) {
        String value = "";
        if (productDetailModel.getAttributeModelArrayList().size() > 0) {
            for (int i = 0; i < productDetailModel.getAttributeModelArrayList().size(); i++) {
                AttributeModel model = productDetailModel.getAttributeModelArrayList().get(i);
                model.setChecked(0);
                if (model.getAttributeType() == 1 || model.getAttributeType() == 2 || model.getAttributeType() == 40 || model.getAttributeType() == 45) {
                    String currentValue = "0";
                    if (!hideAttributeIds.contains(model.getMapId())) {
                        if (model.getCurrentValueModel() != null) {
                            currentValue = String.valueOf(model.getCurrentValueModel().getId());
                        }
                    }
                    value += "product_attribute_" + productDetailModel.getId() +
                            "_" + model.getId() +
                            "_" + model.getMapId() +
                            "_" + currentValue +
                            ",";
                }
                if (model.getAttributeType() == 3 || model.getAttributeType() == 50) {
                    String currentValue = "0";
                    if (!hideAttributeIds.contains(model.getMapId())) {
                        for (int j = 0; j < model.getSelectedValueModelList().size(); j++) {
                            if (j == model.getSelectedValueModelList().size() - 1) {
                                currentValue += String.valueOf(model.getSelectedValueModelList().get(j).getId());
                            } else {
                                currentValue += String.valueOf(model.getSelectedValueModelList().get(j).getId()) + ":";
                            }
                        }
                    }
                    value += "product_attribute_" + productDetailModel.getId() + "_" + model.getId() + "_" + model.getMapId() + "_" + currentValue + ",";
                }

                if (model.getAttributeType() == 4 || model.getAttributeType() == 10 || model.getAttributeType() == 20) {
                    String currentValue = "";
                    if (!hideAttributeIds.contains(model.getMapId())) {
                        if (model.getCurrentValue() != null) {
                            currentValue = model.getCurrentValue();
                        }
                    }
                    value += "product_attribute_" + productDetailModel.getId() + "_" + model.getId() + "_" + model.getMapId() + "_" + currentValue + ",";
                }
            }
            Log.i(TAG, "makeRequestStringForConditionalAttribute: " + value);
        }
        return value;
    }

    public void callApiForHideAttributeIds(final boolean haveToShowProgressDialog) {

        String value = null;
        if (productDetailModel != null && productDetailModel.getAttributeModelArrayList() != null) {
            value = makeRequestStringForConditionalAttribute(productDetailModel.getAttributeModelArrayList());
        }
        String url = Config.BASE_URL + "shopping_cart_items/productdetailsattributechange?customerId=" + userId + "&productId=" + productDetailModel.getId() + "&validateAttributeConditions=true&loadPicture=true&attributeControlIds=" + value + "&storeid=" + storeId;
        JSONHelper helper = new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) {
                try {
                    if (!result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.has("disabledattributemappingids") && !jsonObject.isNull("disabledattributemappingids")) {
                            JSONArray jsonArray = jsonObject.getJSONArray("disabledattributemappingids");
                            hideAttributeIds = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                int value = jsonArray.getInt(i);
                                hideAttributeIds.add(value);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (!haveToShowProgressDialog) {
                    try {
                        setDataForSlider();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    attributeListAdapter.updateHideAttributeList(hideAttributeIds);
                }
            }
        }, haveToShowProgressDialog);
        helper.execute();

    }

    void callApiForGetAssociatedProducts() {
        isLoadingForAssociatedProduct = true;
        for (int i = 0; i < productDetailModel.getAssociatedProductIdList().size(); i++) {
            final int finalI = i;
            JSONHelper helper = new JSONHelper(context, Config.BASE_URL + "products/" + productDetailModel.getAssociatedProductIdList().get(i) + "?Cid=" + currencyId, null, new OnAsyncLoader() {
                @Override
                public void OnResult(String result) throws JSONException {

                    if (finalI == productDetailModel.getAssociatedProductIdList().size() - 1) {
                        isLoadingForAssociatedProduct = false;
                        if (!isLoading) {
                           setDataForAssociatedProductList();
                            layoutLoading.setVisibility(View.GONE);
                            layoutMain.setVisibility(View.VISIBLE);
                        }
                    }

                    if (result != null && !result.isEmpty()) {
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.has("products") && !jsonObject.isNull("products")) {
                            JSONArray products = jsonObject.getJSONArray("products");
                            if (products.length() > 0) {
                                JSONObject object = products.getJSONObject(0);
                                ProductDetailModel model = new ProductDetailModel();
                                model.parse(object);
                                productDetailModel.getAssociatedProductList().add(model);
                            }
                        }

                    }

                }
            }, false);
            helper.execute();
        }
    }

    void callApiForAddToCart() {
        String valueString = makeRequestStringForConditionalAttribute(productDetailModel.getAttributeModelArrayList());
        String url = Config.BASE_URL +
                "shopping_cart_items/addproducttoshoppingcart?customerId=" + userId +
                "&productId=" + productDetailModel.getId() +
                "&shoppingCartTypeId=1&quantity=" + productDetailModel.getSelectedQuantity() +
                "&attributeControlIds=" + valueString +
                "&rentalStartDate=null&rentalEndDate=null" + "&storeid=" + storeId;
        new JSONHelper(context, url, null, new OnAsyncLoader() {
            @Override
            public void OnResult(String result) throws JSONException {
                Log.e(TAG, "OnResult: " + result);
                if (result != null && !result.isEmpty()) {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("Success") && !jsonObject.isNull("Success")) {
                        if (jsonObject.getBoolean("Success")) {
                            if (jsonObject.has("Message") && !jsonObject.isNull("Message")) {
                                String message = jsonObject.getString("Message");
//                                Toast.makeText(context, "" + Html.fromHtml(message), Toast.LENGTH_SHORT).show();
                            }
                            showOfferDialog(productDetailModel.getImageList().get(0).getUrl());
                        }
                    }
                }
            }
        }, true).execute();
    }

    public void onClickProduct(int productId) {
        Intent i = new Intent(context, ProductDetailActivity.class);
        i.putExtra(Constants.INTENT_PRODUCT_ID, String.valueOf(productId));
        startActivity(i);
    }

    public void onClickAddToCartInProductList(int productId) {
        addToCart(productId);
    }


    public void btn_addReview(View view)
    {
                Intent i=new Intent(ProductDetailActivity.this,AddReview.class);
                i.putExtra("image", imageList.get(0).getUrl());
                i.putExtra("prodname", productDetailModel.getName());
                startActivity(i);
    }

    public void btn_addReviews(View view)
    {
        Intent viewReviews=new Intent(ProductDetailActivity.this,ViewReviews.class);
        viewReviews.putExtra("PRODUCT_ID",productId);
        viewReviews.putExtra("CUSTOMER_ID",customerId);
        startActivity(viewReviews);
    }
}
