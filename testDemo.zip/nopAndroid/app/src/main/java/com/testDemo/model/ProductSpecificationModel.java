package com.testDemo.model;

import org.json.JSONException;
import org.json.JSONObject;

public class ProductSpecificationModel {
    private int id;
    private String name;
    private String value;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "ProductSpecificationModel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", value='" + value + '\'' +
                '}';
    }

    public void parse(JSONObject object) throws JSONException {
        if(object != null){
            if(checkForNull("SpecificationAttributeId",object)){
                id = object.getInt("SpecificationAttributeId");
            }
            if(checkForNull("SpecificationAttributeName",object)){
                name = object.getString("SpecificationAttributeName");
            }
            if(checkForNull("ValueRaw",object)){
                value = object.getString("ValueRaw");
            }
        }
    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }
}
