package com.testDemo.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SpecificationForFilterModel {
    String id;
    String name;
    ArrayList<SpecificationValueModel> specificationValueModelList = new ArrayList<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<SpecificationValueModel> getSpecificationValueModelList() {
        return specificationValueModelList;
    }

    public void setSpecificationValueModelList(ArrayList<SpecificationValueModel> specificationValueModelList) {
        this.specificationValueModelList = specificationValueModelList;
    }

    public void parse(JSONObject object) throws JSONException {
        if (object != null) {


            if (checkForNull("SpecificationAttributeName", object)) {
                name = object.getString("SpecificationAttributeName");
            }
            if (checkForNull("SpecificationAttributeId", object)) {
                id = object.getString("SpecificationAttributeId");
            }

            SpecificationValueModel model = new SpecificationValueModel();

            if (checkForNull("specificationAttributeOptions", object)) {
                JSONArray jsonArray = object.getJSONArray("specificationAttributeOptions");
                JSONArray jsonArrayForColorValue = object.getJSONArray("SpecificationAttributeOptionColorRgbs");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if (checkForNull("SpecificationAttributeOptionNames", jsonObject)) {
                        model.setName(jsonObject.getString("SpecificationAttributeOptionNames"));
                    }
                    if (checkForNull("SpecificationAttributeOptionId", jsonObject)) {
                        model.setId(jsonObject.getString("SpecificationAttributeOptionId"));
                    }
                    if (jsonArray.length() == jsonArrayForColorValue.length()) {
                        String colorCode = jsonArrayForColorValue.getString(i);
                        model.setColorCode(colorCode);
                    }
                }
            }

            specificationValueModelList.add(model);
        }
    }

    private boolean checkForNull(String key, JSONObject object) {
        return object != null && object.has(key) && !object.isNull(key);
    }
}
