package com.testDemo.adapter;

import com.testDemo.activites.SubCategoryRelatedActivityExample;

public interface ActivityListItemClickListener {
    void onItemClick(SubCategoryRelatedActivityExample subCategoryRelatedActivityExample);
}

