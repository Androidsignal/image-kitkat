package com.ieltshelth.Transformations;

import android.view.View;
import android.view.View;
import androidx.viewpager.widget.ViewPager;
public class SimpleTransformation implements ViewPager.PageTransformer {
    @Override
    public void transformPage(View page, float position) {

    }
}