package com.ieltshelth.utils;

public class Config {
    public static final String BASE_URL = "https://www.ieltsmedicalapp.com/webservice/";
}
